# Heaviside — Circuit & Filter Analyzer (Android)

Šema preko celog ekrana (zum sa dva prsta, + meni sa Vin/Vout/GND/R/L/C, okretanje, brisanje, poništi),
grafik sa Bode, Ω, Nyquist, spektar (Furije) i Smith prikazom, 20 primera kola i izvođenje formule korak po korak sa PDF izveštajem.
Jezici: English (podrazumevano), Srpski, Español, Français, Deutsch, 中文.

## Najlakše: APK preko GitHuba (bez Android Studija)

1. Napravi repozitorijum na github.com i okači sve fajlove iz ovog foldera
   (bitno je da uđe i skriveni folder `.github/workflows`).
2. GitHub sam pokrene „Napravi APK" (kartica **Actions**). Traje 3–5 minuta.
3. Kad završi, otvori **Releases → najnovije** i preuzmi `Heaviside.apk` na telefon.
4. Otvori fajl i dozvoli instalaciju iz nepoznatih izvora kad telefon pita.

Svaka nova izmena koda pravi novi APK automatski. Svi buildovi koriste isti ključ
(`app/rlc-debug.keystore`), pa nova verzija može da se instalira preko stare.

## Android Studio

Otvori ovaj folder (File → Open), sačekaj Gradle sync, pa Build → Build APK(s).

## Gde je šta

- `app/src/main/assets/index.html` — cela aplikacija (HTML + JavaScript)
- `app/src/main/java/.../MainActivity.java` — WebView omotač i most za PDF
- `.github/workflows/build-apk.yml` — automatski build na GitHubu

Formule se prikazuju preko MathJax-a sa interneta. Bez interneta sve ostalo radi,
a formule se prikazuju kao TeX tekst.

## Ikonica

- Adaptivna ikonica (Android 8+): pozadina `#14171C` + prednji sloj `mipmap-*/ic_launcher_foreground.png`,
  plus jednobojni sloj za „temirane" ikonice (Android 13+).
- Klasične ikonice za starije telefone: `mipmap-*/ic_launcher.png` i `ic_launcher_round.png`.
- Ikonica za Google Play (512×512): `store/play_store_512.png`.
