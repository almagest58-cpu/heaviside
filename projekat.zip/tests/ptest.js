// verifies the chips (cutoff, resonance, min/max) and the Smith readout against the high-precision oracle
const { chromium } = require('playwright');const {hpSolve}=require('./hp.js');
let seed=+(process.env.SEED||777);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const parOf=k=>k==='C'?{esr:logU(1e-3,1),esl:logU(1e-10,1e-8),rp:rnd()<0.5?1e12:logU(1e5,1e9)}:k==='R'?{ls:logU(1e-10,1e-7),cp:logU(1e-14,1e-11)}:{rdc:logU(1e-2,10),cp:logU(1e-13,1e-10)};
const val=k=>k==='R'?logU(1,1e5):k==='L'?logU(1e-7,1e-1):logU(1e-11,1e-4);const el=(a,b,k)=>({a,b,k,v:val(k),par:parOf(k)});
function gen(E){const zmode=rnd()<0.25;const nInt=Math.max(0,Math.round(E*0.5)-(zmode?2:3));const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:nInt},(_,j)=>'n'+j)];
  const order=nodes.slice().sort(()=>rnd()-0.5);const edges=[];for(let j=1;j<order.length;j++)edges.push(el(order[j],pick(order.slice(0,j)),pick(['R','L','C'])));while(edges.length<E){const a=pick(nodes),b=pick(nodes);if(a!==b)edges.push(el(a,b,pick(['R','L','C'])))}return{zmode,edges}}
function expand(edges,real){if(!real)return edges;const out=[];let c=0;for(const e of edges){const m=()=>'x_'+(c++);const p=e.par;
  if(e.k==='C'){const m1=m(),m2=m();out.push({a:e.a,b:m1,k:'R',v:p.esr},{a:m1,b:m2,k:'L',v:p.esl},{a:m2,b:e.b,k:'C',v:e.v});if(p.rp<1e12)out.push({a:m2,b:e.b,k:'R',v:p.rp})}
  else{const q=m();if(e.k==='R')out.push({a:e.a,b:q,k:'R',v:e.v},{a:q,b:e.b,k:'L',v:p.ls});else out.push({a:e.a,b:q,k:'R',v:p.rdc},{a:q,b:e.b,k:'L',v:e.v});out.push({a:e.a,b:e.b,k:'C',v:p.cp})}}return out}
const abs=z=>Math.hypot(z[0],z[1]);
(async()=>{const b=await chromium.launch();const p=await (await b.newContext()).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html')+'',{waitUntil:'domcontentloaded'});await p.waitForTimeout(400);
const st={circuits:0,chips:0,db3:0,res:0,ext:0,worstDb3:0,worstRes:0,worstExt:0,worstSmith:0,maxMissPeakDb:0};const bad=[];
const N=+process.argv[2]||80;
for(let it=0;it<N;it++){const E=[3,4,5,6,8,10,15][it%7];const cir=gen(E);const real=it%3===2;
  const r=await p.evaluate(({cir,real})=>{uid=1;const parts=[],wires=[];const term={};const add=(n,q,e)=>{(term[n]=term[n]||[]).push([q,e])};
    cir.edges.forEach((e,j)=>{const q=mkP(e.k,(j%8)*200,Math.floor(j/8)*200,0,e.v);q.par=Object.assign({},e.par);parts.push(q);add(e.a,q,0);add(e.b,q,1)});
    const vin=mkP('VIN',0,-400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
    for(const k in term){const L=term[k];for(let m=1;m<L.length;m++)wires.push(W_(L[m-1][0],L[m-1][1],L[m][0],L[m][1]))}
    state.parts=parts;state.wires=wires;state.realMode=real;state.fmin=1;state.fmax=1e9;state.z0=50;assignNames();NET=netlist();if(!NET.ok)return null;update();
    const cur=2.345e5;state.cursor=cur;const z=solve(cur,'zin');const G=cx.div(cx.sub(z,[50,0]),cx.add(z,[50,0]));
    return{pts:(data.allPoints||data.points).map(q=>({f:q.f,type:q.type,label:q.label})),fs:data.fs,mode:NET.mode,cur,G}},{cir,real});
  if(!r)continue;st.circuits++;const ex=expand(cir.edges,real);const zm=r.mode==='Z';
  const H=f=>hpSolve(ex,f,zm);const mag=f=>zm?abs(H(f)):20*Math.log10(abs(H(f)));
  // true maximum over the sampled grid refined by oracle (for -3 dB reference)
  let mx=-Infinity;for(const f of r.fs){const v=mag(f);if(isFinite(v))mx=Math.max(mx,v)}
  for(const q of r.pts.filter(q=>q.type==='ext'&&q.label==='pt_max')){const v=mag(q.f);if(v>mx)mx=v}
  {let bi=0,bv=-Infinity;r.fs.forEach((f,i)=>{const v=mag(f);if(v>bv){bv=v;bi=i}});if(bi>0&&bi<r.fs.length-1){let a=Math.log(r.fs[bi-1]),b2=Math.log(r.fs[bi+1]);const g=(Math.sqrt(5)-1)/2;for(let k=0;k<80;k++){const c=b2-g*(b2-a),d=a+g*(b2-a);if(mag(Math.exp(c))>mag(Math.exp(d)))b2=d;else a=c}const v=mag(Math.exp((a+b2)/2));if(v>mx)mx=v}}
  for(const q of r.pts){if(q.type==='db3')continue;const v=mag(q.f);if(isFinite(v)&&v>mx)mx=v}
  const db3s=r.pts.filter(q=>q.type==='db3');if(!zm&&mx>=120&&db3s.length)bad.push(['db3-on-infinite-peak',it]);
  for(const q of r.pts){st.chips++;
    if(q.type==='db3'){st.db3++;const e=Math.abs(mag(q.f)-(mx-10*Math.log10(2)));st.worstDb3=Math.max(st.worstDb3,e);if(e>1e-3)bad.push(['db3',it,q.f,e])}
    else if(q.type==='res'){st.res++;const h=H(q.f);let e=Math.abs(h[1])/abs(h);if(zm&&(q.label==='pt_sres'||q.label==='pt_pres')){const n1=abs(H(q.f*1.001)),n2=abs(H(q.f/1.001)),m0=abs(h);if((q.label==='pt_sres'&&m0<n1&&m0<n2)||(q.label==='pt_pres'&&m0>n1&&m0>n2))e=0}st.worstRes=Math.max(st.worstRes,e);if(e>1e-6)bad.push(['res',it,q.f,e])}
    else if(q.type==='ext'){st.ext++;const v=mag(q.f),v1=mag(q.f*1.0001),v2=mag(q.f/1.0001);const isMax=q.label==='pt_max';
      const e=isMax?Math.max(0,v1-v,v2-v):Math.max(0,v-v1,v-v2);st.worstExt=Math.max(st.worstExt,e);if(e>1e-6)bad.push(['ext',it,q.f,e])}}
  const zr=hpSolve(ex,r.cur,true);const Gr=[((zr[0]-50)*(zr[0]+50)+zr[1]*zr[1])/((zr[0]+50)**2+zr[1]**2),(zr[1]*(zr[0]+50)-(zr[0]-50)*zr[1])/((zr[0]+50)**2+zr[1]**2)];
  const eS=Math.hypot(r.G[0]-Gr[0],r.G[1]-Gr[1]);st.worstSmith=Math.max(st.worstSmith,eS);if(eS>1e-9)bad.push(['smith',it,eS])}
console.log(JSON.stringify(st));console.log('problems',JSON.stringify(bad.slice(0,15)));console.log('pageerrors',errs);await b.close()})();
