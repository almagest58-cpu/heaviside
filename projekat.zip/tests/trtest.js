// transient engine (tran.js) vs ngspice .tran on random circuits: diodes (all kinds, with charges), BJT, MOSFET, op-amps with rails,
// transformers, R/L/C, generators with the six waveforms. Compares every node voltage on a fine time grid.
const T=require('./tran.js');const S=require('./semi.js');const fs=require('fs'),cp=require('child_process');
const NGS=process.env.NGSPICE||'/tmp/claude-0/-home-claude/3126b669-5ac5-5936-b9ef-b8aba5bf071a/scratchpad/ngs/inst/bin/ngspice';
const WD=fs.mkdtempSync(require('os').tmpdir()+'/tr-');
let seed=+(process.env.SEED||5);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const VT=S.VT,TC=VT*1.6021918e-19/1.3806226e-23-273.15;
const OA_IDEAL={a0:1e6,gbw:1e9};
/* real MOSFET C_gd(V) emulated in ngspice exactly: charge Q = C0·f(V_GD) with f = depletion form below 0 and V above; a B source makes
   f(V) on node yq, a capacitor C0 from yq through a 0 V sense source, and an F source copies its current from gate to drain */
function cgdNet(j,g,d,pol,c0,vj,m){const a=pol>0?g:d,b=pol>0?d:g;const V=x=>x==='0'?'0':`v(${x})`;const v=`(${V(a)}-${V(b)})`;
  return[`BQ${j} yq${j} 0 V=(${v}<0)?(${vj}*(1-pow(1-${v}/${vj},${1-m}))/${1-m}):(${v})`,`CQ${j} yq${j} zq${j} ${c0}`,`VQ${j} zq${j} 0 0`,`FQ${j} ${a} ${b} VQ${j} 1`]}
function gen(){const G={nodes:new Set(),R:[],C:[],L:[],V:[],I:[],xf:[],oa:[],dev:[],f0:1e3};const nd=x=>{if(x!=='g')G.nodes.add(x);return x};
  const R=(a,b,v)=>G.R.push({a:nd(a),b:nd(b),v:v||logU(100,1e5)}),Cc=(a,b,v)=>G.C.push({a:nd(a),b:nd(b),v:v||logU(1e-9,1e-5)}),Ll=(a,b,v)=>G.L.push({a:nd(a),b:nd(b),v:v||logU(1e-5,1e-1)});
  const f0=logU(10,1e5);G.f0=f0;const wf=(type)=>{type=type||pick(['sin','sq','tri','saw','pul']);return{type,amp:logU(0.1,10),f:f0*pick([1,1,1,2,0.5,3]),off:pick([0,0,(rnd()*2-1)*2]),ph:type==='sin'?pick([0,0,90,rnd()*360]):0,duty:pick([0.5,0.5,0.2,0.7,0.1]),tr:pick([1e-3,1e-2,0.05])/f0}};
  const VS=(a,b,w)=>G.V.push({a:nd(a),b:nd(b),w:w||wf()});const DC=(a,b,v)=>G.V.push({a:nd(a),b:nd(b),w:{type:'dc',amp:v}});
  const dsc=(dt)=>{dt=dt||pick(['std','std','zen','sch','led','var']);const b={dt,is:dt==='sch'?logU(1e-8,1e-6):dt==='led'?pick([1e-18,2e-20,6e-28]):pick([1e-14,1e-8,2.5e-9]),n:dt==='led'?2:pick([1,1,1.9]),
    cj:dt==='var'?logU(1e-11,1e-10):pick([0,logU(1e-12,1e-10)]),vj:0.3+rnd()*1.5,m:0.25+rnd()*0.65,tt:pick([0,0,logU(1e-9,1e-7)])};if(dt==='zen'){b.bv=logU(2,15);b.ibv=logU(1e-5,2e-2)}return b};
  const D=(a,k,dt)=>G.dev.push({t:'D',a:nd(a),k:nd(k),sc:dsc(dt)});
  /* QREAL: real BJT / MOSFET — series resistances as explicit resistors to inner nodes, voltage-dependent charges, MOSFET body diode */
  const QR=!!process.env.QREAL;let nin=0;const inner=(x,r)=>{if(!(r>0))return x;const m=x+'_'+(nin++);R(x,m,r);return m};
  const Q=(b,c,e,pol)=>{nd(b);nd(c);nd(e);if(QR){b=inner(b,pick([0,logU(1,300)]));c=inner(c,pick([0,logU(0.1,30)]));e=inner(e,pick([0,logU(0.05,10)]))}
    G.dev.push({t:'Q',b,c,e,pol,par:{is:pick([1e-15,1e-14,1e-16]),bf:logU(50,400),br:pick([1,2,5]),va:pick([Infinity,50,100]),ikf:QR?pick([0,logU(1e-3,1)]):0},cbe:QR?0:pick([0,logU(1e-12,3e-11)]),cbc:QR?0:pick([0,logU(5e-13,5e-12)]),
      qr:QR?{cje:pick([0,logU(1e-12,3e-11)]),vje:0.4+rnd()*0.6,mje:0.2+rnd()*0.6,cjc:pick([0,logU(5e-13,1e-11)]),vjc:0.4+rnd()*0.6,mjc:0.2+rnd()*0.6,tf:pick([0,logU(1e-11,1e-9)]),tr:pick([0,logU(1e-9,1e-6)])}:null})};
  const M=(g,d,s,pol)=>{nd(g);nd(d);nd(s);if(QR){g=inner(g,pick([0,logU(0.1,50)]));d=inner(d,pick([0,logU(0.01,10)]));s=inner(s,pick([0,logU(0.01,10)]))}
    G.dev.push({t:'M',g,d,s,pol,par:{vth:pol*logU(0.4,2),k:logU(2e-4,2e-2),lam:pick([0,0.01,0.05])},cgs:pick([0,logU(1e-13,1e-11)]),cgd:QR?0:pick([0,logU(1e-14,2e-12)]),qgd:QR?{c0:pick([0,logU(1e-13,1e-10)]),vj:0.3+rnd(),m:0.2+rnd()*0.6}:null});
    if(QR){const sc={dt:'std',is:logU(1e-15,1e-11),n:pick([1,1.2]),cj:pick([0,logU(1e-12,1e-10)]),vj:0.4+rnd()*0.6,m:0.2+rnd()*0.6,tt:pick([0,logU(1e-9,1e-7)])};G.dev.push(pol>0?{t:'D',a:s,k:d,sc}:{t:'D',a:d,k:s,sc})}};
  const OA=(p,n,o,real,rail)=>G.oa.push({p:nd(p),n:nd(n),o:nd(o),real,vs:rail||pick([5,12,15]),a0:real?logU(1e4,1e6):OA_IDEAL.a0,gbw:real?logU(1e5,1e7):OA_IDEAL.gbw});
  const XF=(p1,n1,p2,n2,n)=>G.xf.push({p1:nd(p1),n1:nd(n1),p2:nd(p2),n2:nd(n2),n:n||logU(0.2,10)});
  const typ=+(process.env.TYP||Math.floor(rnd()*14));G.typ=typ;
  switch(typ){
  case 0:/* RC / RL / RLC driven by any waveform */VS('i','g');R('i','a');pick([()=>Cc('a','g'),()=>Ll('a','g'),()=>{Ll('a','b');Cc('b','g');R('b','g',logU(1e3,1e5))}])();break;
  case 1:/* half-wave rectifier with smoothing capacitor and load */VS('i','g',wf('sin'));G.V[0].w.amp=logU(2,20);R('i','a',logU(1,100));D('a','o','std');Cc('o','g',logU(1e-7,1e-4));R('o','g',logU(100,1e4));break;
  case 2:/* Zener / LED clipper */VS('i','g',wf(pick(['sin','tri','sq'])));G.V[0].w.amp=logU(3,15);R('i','o',logU(100,5e3));D('g','o','zen');if(rnd()<0.5)D('o','g',pick(['led','std']));break;
  case 3:/* common emitter with sine input, coupling caps */{const vcc=logU(5,15);DC('vc','g',vcc);R('vc','b',logU(2e4,2e5));R('b','g',logU(5e3,5e4));R('vc','c',logU(1e3,1e4));R('e','g',logU(100,2e3));Cc('e','g',logU(1e-6,1e-4));VS('s','g',wf('sin'));G.V[1].w.amp=logU(1e-3,0.5);G.V[1].w.off=0;Cc('s','b',logU(1e-7,1e-5));Cc('c','o',logU(1e-7,1e-5));R('o','g',logU(1e3,1e5));Q('b','c','e',1)}break;
  case 4:/* MOSFET switch with square gate drive, RL or RC load */{const vdd=logU(3,15);DC('vd','g',vdd);VS('gs','g',wf('sq'));G.V[1].w.amp=logU(1,5);G.V[1].w.off=G.V[1].w.amp;R('gs','gg',logU(10,1e3));R('vd','d',logU(100,5e3));if(rnd()<0.5)Ll('vd','d',logU(1e-4,1e-2));else Cc('d','g',logU(1e-10,1e-8));D('d','vd','std');M('gg','d','g',1)}break;
  case 5:/* comparator (open-loop op-amp) with rails, LED on the output */VS('i','g',wf(pick(['sin','tri'])));R('i','p',1e3);DC('r','g',(rnd()*2-1));OA('p','r','o',rnd()<0.5);R('o','a',logU(330,2e3));D('a','g','led');break;
  case 6:/* inverting amplifier driven into the rails */{VS('i','g',wf());R('i','m',logU(1e3,1e4));R('m','o',logU(1e4,1e5));OA('g','m','o',rnd()<0.5);R('o','g',logU(1e3,1e5));if(rnd()<0.5)Cc('m','o',logU(1e-11,1e-9))}break;
  case 7:/* Schmitt trigger (positive feedback) */VS('i','g',wf(pick(['sin','tri'])));G.V[0].w.amp=logU(5,12);R('o','p',logU(1e4,1e5));R('p','g',logU(1e3,1e4));R('i','m',1e3);OA('p','m','o',true,pick([5,12]));R('o','g',1e4);break;
  case 8:/* transformer + bridge rectifier */VS('i','g',wf('sin'));G.V[0].w.amp=logU(5,50);R('i','a',logU(0.5,10));XF('a','g','s1','s2',logU(1,10));R('s2','sx',1e6);R('sx','g',1e6);D('s1','p','std');D('s2','p','std');D('m','s1','std');D('m','s2','std');R('m','g',1e-2);Cc('p','m',logU(1e-6,1e-4));R('p','m',logU(100,1e4));break;
  case 9:/* diode clamp / voltage doubler */VS('i','g',wf(pick(['sin','sq'])));Cc('i','a',logU(1e-7,1e-5));D('a','g','std');D('a','o','std');Cc('o','g',logU(1e-7,1e-5));R('o','g',logU(1e3,1e5));break;
  case 10:/* non-inverting op-amp with real model + RC load, square input */VS('i','g',wf('sq'));OA('i','m','o',true);R('o','m',logU(1e3,1e5));R('m','g',logU(1e3,1e5));R('o','x',logU(100,1e4));Cc('x','g',logU(1e-9,1e-6));break;
  case 11:/* PNP / NMOS mixture with varicap, pulse input */{DC('vc','g',logU(5,12));VS('i','g',wf('pul'));R('i','b',logU(1e3,1e5));Q('b','c','vc',-1);R('c','g',logU(1e3,1e4));Cc('c','g',logU(1e-10,1e-8));D('g','c','var')}break;
  case 12:/* LC tank with transformer coupling (sine) */VS('i','g',wf('sin'));R('i','a',logU(10,1e3));XF('a','g','s','g',logU(0.3,3));Ll('s','g',logU(1e-4,1e-2));Cc('s','g',logU(1e-9,1e-6));R('s','g',logU(1e2,1e4));break;
  default:/* random mixture */{const nn=['g','i','n1','n2','n3','n4'];VS('i','g');for(const x of nn.slice(2))R(x,pick(nn.filter(y=>y!==x)));
    for(let k=0;k<3;k++){const a=pick(nn),b=pick(nn);if(a!==b)pick([R,Cc,Ll])(a,b)}const nd2=1+Math.floor(rnd()*3);
    for(let k=0;k<nd2;k++){const s=new Set();while(s.size<3)s.add(pick(nn));const[a,b,c]=[...s];const t=pick(['D','Q','M']);if(t==='D')D(a,b);else if(t==='Q')Q(a,b,c,pick([1,-1]));else M(a,b,c,pick([1,-1]))}}}
  return G}
function toEngine(G){const names=[...G.nodes];const ix={};names.forEach((x,i)=>ix[x]=i);const I=x=>x==='g'?-1:ix[x];
  const C={n:names.length,R:G.R.map(e=>({a:I(e.a),b:I(e.b),g:1/e.v})),C:G.C.map(e=>({a:I(e.a),b:I(e.b),c:e.v})),L:G.L.map(e=>({a:I(e.a),b:I(e.b),l:e.v})),V:G.V.map(e=>({a:I(e.a),b:I(e.b),w:e.w})),I:[],
    xf:G.xf.map(e=>({p1:I(e.p1),n1:I(e.n1),p2:I(e.p2),n2:I(e.n2),n:e.n})),oa:G.oa.map(o=>({p:I(o.p),n:I(o.n),o:I(o.o),a0:o.a0,wp:2*Math.PI*o.gbw/o.a0,vp:o.vs,vn:-o.vs})),
    dev:G.dev.map(d=>{if(d.t==='D'){const s=d.sc;const par={is:s.is,n:s.n,cj:s.cj,vj:s.vj,m:s.m,tt:s.tt};if(s.dt==='zen'){par.bv=s.bv;par.ibv=s.ibv;par.xbv=S.diodeBrk(par)}return{t:'D',a:I(d.a),k:I(d.k),par}}
      if(d.t==='Q')return{t:'Q',b:I(d.b),c:I(d.c),e:I(d.e),pol:d.pol,par:d.par,cbe:d.cbe,cbc:d.cbc,qr:d.qr};return{t:'M',g:I(d.g),d:I(d.d),s:I(d.s),pol:d.pol,par:d.par,cgs:d.cgs,cgd:d.cgd,qgd:d.qgd}})};return{C,names}}
const p17=v=>(+v).toPrecision(17);
let PERMAX=1;function wSpice(w){const A=w.amp,off=w.off||0;if(w.type==='dc')return`DC ${p17(A)}`;const Tp=1/w.f;
  if(w.type==='sin')return`DC ${p17(off)} SIN(${p17(off)} ${p17(A)} ${p17(w.f)} 0 0 ${p17(w.ph||0)})`;
  const e=Math.min(Math.max(w.tr*w.f,1e-9),w.type==='saw'?0.5:0.5*Math.min(w.duty,1-w.duty));
  if(w.type==='sq')return`PULSE(${p17(off-A)} ${p17(off+A)} 0 ${p17(e*Tp)} ${p17(e*Tp)} ${p17((w.duty-e)*Tp)} ${p17(Tp)})`;
  if(w.type==='pul')return`PULSE(${p17(off)} ${p17(off+A)} 0 ${p17(e*Tp)} ${p17(e*Tp)} ${p17((w.duty-e)*Tp)} ${p17(Tp)})`;
  /* PWL written out over the whole run: ngspice drops the corners of a repeated PWL */const pts=[];const np=Math.ceil((+process.env.NPER||3)*w.f*Math.max(1,1/(w.f*PERMAX))+2);
  for(let k=0;k<np;k++){if(w.type==='tri')pts.push([k*Tp,off],[(k+0.25)*Tp,off+A],[(k+0.75)*Tp,off-A]);else pts.push([k*Tp,off-A],[(k+1-e)*Tp,off+A])}
  return`PWL(${pts.map(q=>p17(q[0])+' '+p17(q[1])).join(' ')})`}
function spice(G,tag,tEnd,hmax){const nn=x=>x==='g'?'0':'n_'+x;const L=['* '+tag,`.options reltol=1e-6 abstol=1e-15 vntol=1e-9 chgtol=1e-20 method=gear maxord=2 trtol=1 itl4=200 itl1=500 temp=${TC.toPrecision(15)} tnom=${TC.toPrecision(15)}`];
  G.R.forEach((e,j)=>L.push(`R${j} ${nn(e.a)} ${nn(e.b)} ${p17(e.v)}`));G.C.forEach((e,j)=>L.push(`C${j} ${nn(e.a)} ${nn(e.b)} ${p17(e.v)}`));G.L.forEach((e,j)=>L.push(`L${j} ${nn(e.a)} ${nn(e.b)} ${p17(e.v)}`));
  G.V.forEach((e,j)=>{if(e.w.type==='sin'&&e.w.ph)L.push(`BV${j} ${nn(e.a)} ${nn(e.b)} V=${p17(e.w.off||0)}+${p17(e.w.amp)}*sin(${p17(2*Math.PI*e.w.f)}*time+${p17(e.w.ph*Math.PI/180)})`);else L.push(`V${j} ${nn(e.a)} ${nn(e.b)} ${wSpice(e.w)}`)});
  G.xf.forEach((x,j)=>L.push(`VX${j} ${nn(x.p1)} xa${j} 0`,`EX${j} xa${j} ${nn(x.n1)} ${nn(x.p2)} ${nn(x.n2)} ${p17(x.n)}`,`FX${j} ${nn(x.n2)} ${nn(x.p2)} VX${j} ${p17(x.n)}`));
  G.oa.forEach((o,j)=>{const w=Math.min(0.01,0.25*2*o.vs),vp=o.vs,vn=-o.vs,a0=o.a0,wp=2*Math.PI*o.gbw/a0,Kp=10;const y=`y${j}`;
    /* state node y: C·dy/dt = (V+ − V−) − y/A0 − (Kp/A0)·ψ(y), C = 1/(ωp·A0) */
    L.push(`CY${j} ${y} 0 ${p17(1/(wp*a0))}`,`RY${j} ${y} 0 1e15`,
      `BY${j} 0 ${y} I=(v(${nn(o.p)})-v(${nn(o.n)}))-v(${y})/${p17(a0)}-${p17(Kp)}*((v(${y})>${p17(vp+w)})?(v(${y})-${p17(vp+w)})*(v(${y})-${p17(vp+w)}):((v(${y})<${p17(vn-w)})?-(${p17(vn-w)}-v(${y}))*(${p17(vn-w)}-v(${y})):0))`,
      `BO${j} ${nn(o.o)} 0 V=(v(${y})>=${p17(vp+w)})?${p17(vp)}:((v(${y})>${p17(vp-w)})?v(${y})-(v(${y})-${p17(vp-w)})*(v(${y})-${p17(vp-w)})/${p17(4*w)}:((v(${y})<=${p17(vn-w)})?${p17(vn)}:((v(${y})<${p17(vn+w)})?v(${y})+(${p17(vn+w)}-v(${y}))*(${p17(vn+w)}-v(${y}))/${p17(4*w)}:v(${y}))))`)});
  G.dev.forEach((d,j)=>{if(d.t==='D'){const s=d.sc;L.push(`D${j} ${nn(d.a)} ${nn(d.k)} DM${j}`,`.model DM${j} D(IS=${s.is} N=${s.n} CJO=${s.cj} VJ=${s.vj} M=${s.m} TT=${s.tt}${s.dt==='zen'?` BV=${s.bv} IBV=${s.ibv}`:''})`)}
    else if(d.t==='Q'&&d.qr){const q=d.qr;L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${d.par.is} BF=${p17(d.par.bf)} BR=${d.par.br}${isFinite(d.par.va)?' VAF='+d.par.va:''}${d.par.ikf>0?' IKF='+d.par.ikf:''} CJE=${q.cje} VJE=${q.vje} MJE=${q.mje} CJC=${q.cjc} VJC=${q.vjc} MJC=${q.mjc} TF=${q.tf} TR=${q.tr})`)}
    else if(d.t==='Q')L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${d.par.is} BF=${p17(d.par.bf)} BR=${d.par.br}${isFinite(d.par.va)?' VAF='+d.par.va:''} CJE=${d.cbe} MJE=0 CJC=${d.cbc} MJC=0)`);
    else if(d.qgd){L.push(`M${j} ${nn(d.d)} ${nn(d.g)} ${nn(d.s)} ${nn(d.s)} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${p17(d.par.vth)} KP=${p17(d.par.k)} LAMBDA=${d.par.lam} IS=0 GAMMA=0 CGSO=${d.cgs} CGDO=0)`);
      if(d.qgd.c0>0)L.push(...cgdNet(j,nn(d.g),nn(d.d),d.pol,d.qgd.c0,d.qgd.vj,d.qgd.m))}
    else L.push(`M${j} ${nn(d.d)} ${nn(d.g)} ${nn(d.s)} ${nn(d.s)} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${p17(d.par.vth)} KP=${p17(d.par.k)} LAMBDA=${d.par.lam} IS=0 GAMMA=0 CGSO=${d.cgs} CGDO=${d.cgd})`)});
  const names=[...G.nodes];
  L.push('.control','set filetype=ascii',`tran ${p17(hmax/4)} ${p17(tEnd)} 0 ${p17(hmax)}`,`write ${WD}/${tag}.raw ${names.map(x=>'v('+nn(x)+')').join(' ')}`,'quit','.endc','.end');
  fs.writeFileSync(`${WD}/${tag}.cir`,L.join('\n'));try{cp.execFileSync(NGS,['-b',`${WD}/${tag}.cir`],{stdio:'ignore',timeout:300000})}catch(e){return null}
  const file=`${WD}/${tag}.raw`;if(!fs.existsSync(file)||fs.statSync(file).size>4e8)return null;const txt=fs.readFileSync(file,'utf8');if(!txt.includes('Values:'))return null;const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];
  const vals=txt.split('Values:')[1].trim().split(/\s+/);const rows=[];for(let i=0;i<vals.length;){i++;const r=[];for(let v=0;v<nv;v++)r.push(+vals[i++]);rows.push(r)}return rows}
function interp(ts,ys,t){let lo=0,hi=ts.length-1;if(t<=ts[0])return ys[0];if(t>=ts[hi])return ys[hi];while(hi-lo>1){const m=(lo+hi)>>1;if(ts[m]<=t)lo=m;else hi=m}const a=ts[lo],b=ts[hi];return ys[lo]+(ys[hi]-ys[lo])*(t-a)/(b-a)}
const N=+(process.env.N||40);let nOK=0,nBoth=0,nApp=0,nSp=0,worst=0,res=[];const RT=+(process.env.RT||1e-6);
for(let ci=0;ci<N;ci++){const G=gen();if(process.env.ONLY&&+process.env.ONLY!==ci)continue;const per=Math.max(...G.V.filter(v=>v.w.type!=='dc').map(v=>1/v.w.f),1/G.f0);const tEnd=(+process.env.NPER||3)*per;const hmax=per/400;PERMAX=per;
  const{C,names}=toEngine(G);const t0=Date.now();const r=T.trRun(C,tEnd,hmax,{rtol:RT});const ms=Date.now()-t0;const sp=spice(G,'c'+ci,tEnd,hmax);
  if(!sp&&!r.ok){nBoth++;continue}if(!sp){nSp++;console.log('SPFAIL',ci,'typ',G.typ);continue}if(!r.ok){nApp++;console.log('APPFAIL',ci,'typ',G.typ,r.msg||'run',r.S&&r.S.stats);continue}
  if(sp[sp.length-1][0]<tEnd*0.999){nSp++;console.log('SPSTOP',ci,'typ',G.typ,'at',(sp[sp.length-1][0]/per).toFixed(3));continue}
  const st=sp.map(q=>q[0]);let e=0,eAt=null;names.forEach((nm,k)=>{const ya=r.X.map(x=>x[k]),ys=sp.map(q=>q[k+1]);let mx=0,mn=0;ys.forEach(v=>{mx=Math.max(mx,v);mn=Math.min(mn,v)});const rng=Math.max(mx-mn,Math.abs(mx),Math.abs(mn),1e-3);
    /* steep edges: a time shift of up to 1e-3 of the period is forgiven (edge timing), values are compared exactly elsewhere */
    const tw=1e-3*per;for(let i=0;i<=1000;i++){const t=tEnd*i/1000;const b=interp(st,ys,t);let d=Infinity;for(let k=-4;k<=4;k++)d=Math.min(d,Math.abs(interp(r.T,ya,t+k*tw/4)-b));d/=rng;if(d>e){e=d;eAt=[nm,t/per]}}});
  nOK++;worst=Math.max(worst,e);res.push({ci,typ:G.typ,e,steps:r.S.stats.steps,ms});if(e>(+process.env.TH||1e-3))console.log('DIFF',ci,'typ',G.typ,'err',e.toExponential(2),'at',JSON.stringify(eAt),'steps',JSON.stringify(r.S.stats),ms+'ms')}
console.log('circuits',N,'compared',nOK,'appFail',nApp,'spiceFail',nSp,'bothFail',nBoth,'worst',worst.toExponential(2),'median steps',res.map(q=>q.steps).sort((a,b)=>a-b)[res.length>>1],'max ms',Math.max(...res.map(q=>q.ms)));
fs.writeFileSync(__dirname+'/trtest.json',JSON.stringify(res));
