// switch (SW) in the time-domain engine: analytic RC / RL checks, and the bounce pattern of the app (o_deb example)
const {trCreate}=require('./tran.js');let bad=0;
function rc(ron,evs){const C={n:3,V:[{a:0,b:-1,w:{type:'dc',amp:5}}],R:[{a:1,b:2,g:1e-3}],C:[{a:2,b:-1,c:1e-6}],sw:[{a:0,b:1,ron,on:false,ev:evs}]};
  const S=trCreate(C,{rtol:1e-4});if(!S.dcop(false)){bad++;return console.log('dc fail')}let w=0;const tau=(1e3+ron)*1e-6;
  const ex=t=>{let v=0,tl=0,on=false;for(const e of evs.concat([{t:Infinity}])){const te=Math.min(e.t,t);if(on)v=5+(v-5)*Math.exp(-(te-tl)/tau);tl=te;if(e.t>=t)break;on=e.on}return v};
  S.run(5e-3,1e-5,(t,x)=>{w=Math.max(w,Math.abs(x[2]-ex(t)))});console.log('RC ron',ron,'events',evs.length,'worst |err| V',w.toExponential(2));if(w>5e-4)bad++}
rc(0,[{t:1e-3,on:true}]);rc(100,[{t:1e-3,on:true}]);rc(0,[{t:1e-3,on:true},{t:2e-3,on:false},{t:2.2e-3,on:true},{t:2.25e-3,on:false},{t:3e-3,on:true}]);
{const C={n:3,V:[{a:0,b:-1,w:{type:'dc',amp:5}}],R:[{a:2,b:-1,g:1e-2}],L:[{a:1,b:2,l:1e-2}],sw:[{a:0,b:1,ron:0,on:true,ev:[{t:1e-3,on:false},{t:1.5e-3,on:true}]}]};
  const S=trCreate(C,{rtol:1e-4});S.dcop(false);let w=0;const ok=S.run(3e-3,1e-5,(t,x)=>{const I=x[S.iL];const e=t<=1e-3?0.05:t<=1.5e-3?0:0.05*(1-Math.exp(-(t-1.5e-3)/1e-4));if(t>1.5e-3+1e-9||t<=1e-3)w=Math.max(w,Math.abs(I-e))});
  console.log('RL opening (inductive kick), ok',ok,'worst |err| A',w.toExponential(2));if(!ok||w>5e-5)bad++}
console.log(bad?'FAIL '+bad:'all ok')
