# Automatski test tačnosti

`rtest.js` pravi nasumična R/L/C kola (idealna i realna) i za svako upoređuje:
- numeričke grafike aplikacije,
- simboličke formule (izvođenje),

sa nezavisnim proračunom u tačnoj aritmetici (`exact.js`, razlomci bez zaokruživanja).

Pokretanje (potreban Node.js i Playwright):

    npm i playwright && npx playwright install chromium
    node tests/rtest.js 150            # 150 kola
    SEED=987654 node tests/rtest.js 150 # drugi skup kola

## Test velikih kola (10–30 komponenti, idealno i realno)

`btest.js` pravi 68 kola (nasumična od 10 do 30 komponenti, LC lestvica, RC lanac,
10 blokadnih kondenzatora, gusta mreža), svako u idealnom i realnom modu, i upoređuje
grafike sa proračunom od ~72 cifre (`hp.js`). Meri i vreme preračunavanja.

    node tests/btest.js     # rezultat u btest.json

## Test oznaka na grafiku (čipovi) i Smitovog očitavanja

`ptest.js` proverava za nasumična kola da li su −3 dB tačke (polovina snage, −3,0103 dB od vrha),
rezonanse (faza 0°), maksimumi/minimumi i Γ na Smitovom dijagramu tačni prema proračunu od ~72 cifre.

    node tests/ptest.js 100
    SEED=31337 node tests/ptest.js 100

## Poređenje sa ngspice (nezavisan SPICE simulator)

`spicetest.js` (nasumična kola 3–30 komponenti, idealno i realno) i `spiceex.js` (svi primeri iz aplikacije)
pišu SPICE netlistu, puštaju je kroz ngspice (`.ac` analiza) i upoređuju grafike, Zin, formule i oznake.
Gde se aplikacija i ngspice razilaze, sudi proračun od ~72 cifre (`hp.js`).

    NGSPICE=/putanja/do/ngspice node tests/spicetest.js
    NGSPICE=/putanja/do/ngspice node tests/spiceex.js

## Operacioni pojačavač i potenciometar

`otest.js` pravi kola sa op. pojačavačima (idealnim i realnim) i potenciometrima i upoređuje
grafike (H i Zin) i formule sa proračunom od ~72 cifre (`hpx.js`, modifikovana nodalna analiza
sa jednačinama pojačavača). `GEN=2` daje tipična aktivna kola (invertujući/neinvertujući,
integrator, diferencijator, Sallen-Key, MFB, dva stepena, potenciometar u povratnoj sprezi...),
bez toga nasumične spojeve (uključujući kola bez rešenja, koja aplikacija mora da prijavi).

    node tests/otest.js                       # 150 nasumičnih kola
    GEN=2 N=200 node tests/otest.js           # 200 tipičnih aktivnih kola -> otest2.json
    GEN=2 PASSIDEAL=1 node tests/otest.js     # realni pojačavači, idealni pasivni elementi

`ospice.js` ista tipična kola (iz `otest2.json`) proverava i u ngspice-u (nezavisan simulator):
idealan pojačavač je E izvor pojačanja 1e10, realan je G izvor u R‖C (pol) plus jedinični bafer.

    NGSPICE=/putanja/do/ngspice node tests/ospice.js

## Odziv u vremenu i polovi/nule (`tdtest.js`)

Za sve primere (idealno i realno), nasumična pasivna i tipična aktivna kola upoređuje:
- odziv na skok i impuls sa nezavisnim rešenjem (`tref.py`: Radau IIA 5. reda na vrlo finoj mreži) i sa ngspice `.tran`,
- polove i nule sa nezavisnim proračunom (`pzoracle.py`: MNA pencil, LAPACK QZ),
- AC krive (H i Zin) sa ngspice `.ac` (uključujući kola sa op. pojačavačima),
- τ, vreme uspona, prebačaj i vreme smirivanja.

    NGSPICE=/putanja/do/ngspice node tests/tdtest.js   # rezultat u tdtest.json, sažetak: python3 tests/tdsum.py

## Formule (`ftest.js`, `texcheck.js`)

Svaka jednačina iz izvođenja (H, Zin, Nyquist, spektar, Smith) se parsira iz LaTeX-a i numerički računa sa vrednostima
elemenata na više frekvencija: sve strane jednakosti moraju da se slažu, a konačni H(s), Z(s), |H(jω)| i φ(ω) i sa
numeričkim rešenjem kola.

    node tests/ftest.js

## Crtanje grafika (`gtest.js`)

Grafici se crtaju na instrumentisanom canvasu; iz ispisanih oznaka na osama rekonstruiše se razmera, i nacrtana kriva
(temena i duži između njih) se poredi piksel po piksel sa tačnim odzivom (Bode, Ω, Nyquist, Smith, polovi/nule, vreme).

    node tests/gtest.js

## Diode, tranzistori i MOSFET-ovi (`stest.js`)

Nasumična kola sa diodama, NPN/PNP i N/P MOSFET-ovima, DC naponskim i strujnim izvorima: tipične topologije
(zajednički emitor/sors/baza, sledioci, diferencijalni par, kaskoda, strujno ogledalo, dvostepeni, CMOS, Darlington,
dioda kao promenljivi otpornik) i potpuno nasumični spojevi. Za svako kolo upoređuje sa ngspice-om (`.op` + `.ac`,
isti modeli: dioda IS/N/CJO/TT, BJT Gummel–Poon IS/BF/BR/VAF/CJE/CJC, MOSFET level 1 VTO/KP/LAMBDA/CGSO/CGDO,
temperatura podešena da V_T bude isti):
- jednosmerne napone svih čvorova (radna tačka),
- odziv H(f) ili Zin(f) u modelu za male signale,
- simboličku formulu iz izvođenja prema numerici aplikacije.

    NGSPICE=/putanja/do/ngspice SEED=21 N=300 node tests/stest.js
    REAL=1 ...     # samo tipične topologije
    SSALL=1 ...    # zadrži i provodnosti < 1e-6 glavne (r_μ, r_o od GMIN-a) -> model identičan SPICE-ovom

DC rešavač (`semi.js`, isti kod je ugrađen u aplikaciju) ima i svoje testove bez pregledača:
`devtest.js` (struje pojedinačnih elemenata prema ngspice-u) i `optest.js` (hiljade nasumičnih DC kola, uključujući
kola bez rešenja, plivajuće čvorove i kola sa više radnih tačaka, koje ngspice potvrđuje preko `.nodeset`).

    NGSPICE=/putanja/do/ngspice SEED=7 N=500 node tests/optest.js
