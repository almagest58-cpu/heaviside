# Automatski test tačnosti

`rtest.js` pravi nasumična R/L/C kola (idealna i realna) i za svako upoređuje:
- numeričke grafike aplikacije,
- simboličke formule (izvođenje),

sa nezavisnim proračunom u tačnoj aritmetici (`exact.js`, razlomci bez zaokruživanja).

Pokretanje (potreban Node.js i Playwright):

    npm i playwright && npx playwright install chromium
    node tests/rtest.js 150            # 150 kola
    SEED=987654 node tests/rtest.js 150 # drugi skup kola

## Test velikih kola (10–30 komponenti, idealno i realno)

`btest.js` pravi 68 kola (nasumična od 10 do 30 komponenti, LC lestvica, RC lanac,
10 blokadnih kondenzatora, gusta mreža), svako u idealnom i realnom modu, i upoređuje
grafike sa proračunom od ~72 cifre (`hp.js`). Meri i vreme preračunavanja.

    node tests/btest.js     # rezultat u btest.json

## Test oznaka na grafiku (čipovi) i Smitovog očitavanja

`ptest.js` proverava za nasumična kola da li su −3 dB tačke (polovina snage, −3,0103 dB od vrha),
rezonanse (faza 0°), maksimumi/minimumi i Γ na Smitovom dijagramu tačni prema proračunu od ~72 cifre.

    node tests/ptest.js 100
    SEED=31337 node tests/ptest.js 100

## Poređenje sa ngspice (nezavisan SPICE simulator)

`spicetest.js` (nasumična kola 3–30 komponenti, idealno i realno) i `spiceex.js` (svi primeri iz aplikacije)
pišu SPICE netlistu, puštaju je kroz ngspice (`.ac` analiza) i upoređuju grafike, Zin, formule i oznake.
Gde se aplikacija i ngspice razilaze, sudi proračun od ~72 cifre (`hp.js`).

    NGSPICE=/putanja/do/ngspice node tests/spicetest.js
    NGSPICE=/putanja/do/ngspice node tests/spiceex.js

## Operacioni pojačavač i potenciometar

`otest.js` pravi kola sa op. pojačavačima (idealnim i realnim) i potenciometrima i upoređuje
grafike (H i Zin) i formule sa proračunom od ~72 cifre (`hpx.js`, modifikovana nodalna analiza
sa jednačinama pojačavača). `GEN=2` daje tipična aktivna kola (invertujući/neinvertujući,
integrator, diferencijator, Sallen-Key, MFB, dva stepena, potenciometar u povratnoj sprezi...),
bez toga nasumične spojeve (uključujući kola bez rešenja, koja aplikacija mora da prijavi).

    node tests/otest.js                       # 150 nasumičnih kola
    GEN=2 N=200 node tests/otest.js           # 200 tipičnih aktivnih kola -> otest2.json
    GEN=2 PASSIDEAL=1 node tests/otest.js     # realni pojačavači, idealni pasivni elementi

`ospice.js` ista tipična kola (iz `otest2.json`) proverava i u ngspice-u (nezavisan simulator):
idealan pojačavač je E izvor pojačanja 1e10, realan je G izvor u R‖C (pol) plus jedinični bafer.

    NGSPICE=/putanja/do/ngspice node tests/ospice.js
