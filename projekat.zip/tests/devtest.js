// single device, terminals driven by voltage sources: compare terminal currents with ngspice
const {evalBJT,evalMOS,evalDiode,VT}=require('./semi.js');const fs=require('fs'),cp=require('child_process');const NG=process.env.NGSPICE||'ngspice';
const TK=VT*1.6021918e-19/1.3806226e-23,TC=TK-273.15;let seed=3;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};
const cases=[];for(let i=0;i<60;i++){const t=['D','Q','M'][i%3];const pol=rnd()<0.5?1:-1;const v1=(rnd()*2-1)*(t==='D'?1:3),v2=(rnd()*2-1)*3;cases.push({t,pol,v1,v2,par:t==='D'?{is:1e-14,n:1}:t==='Q'?{is:1e-15,bf:100,br:2,va:80}:{vth:pol*0.8,k:2e-3,lam:0.03}})}
const L=['* dev','.options reltol=1e-10 vntol=1e-14 abstol=1e-22 temp='+TC.toPrecision(15)+' tnom='+TC.toPrecision(15)];const pr=[];
cases.forEach((c,j)=>{if(c.t==='D'){L.push(`VA${j} a${j} 0 DC ${c.v1}`,`D${j} a${j} 0 DM`);pr.push(`i(VA${j})`)}
  else if(c.t==='Q'){L.push(`VB${j} b${j} 0 DC ${c.v1}`,`VC${j} c${j} 0 DC ${c.v2}`,`Q${j} c${j} b${j} 0 ${c.pol>0?"c":"b"}${j} Q${c.pol>0?"N":"P"}`);pr.push(`i(VB${j})`,`i(VC${j})`)}
  else{L.push(`VG${j} g${j} 0 DC ${c.v1}`,`VD${j} d${j} 0 DC ${c.v2}`,`M${j} d${j} g${j} 0 0 M${c.pol>0?'N':'P'} W=1 L=1`);pr.push(`i(VD${j})`)}});
L.push('.model DM D(IS=1e-14 N=1)','.model QN NPN(IS=1e-15 BF=100 BR=2 VAF=80)','.model QP PNP(IS=1e-15 BF=100 BR=2 VAF=80)','.model MN NMOS(LEVEL=1 VTO=0.8 KP=2e-3 LAMBDA=0.03 IS=0 GAMMA=0)','.model MP PMOS(LEVEL=1 VTO=-0.8 KP=2e-3 LAMBDA=0.03 IS=0 GAMMA=0)');
L.push('.control','set numdgt=16','op','print '+pr.join(' '),'quit','.endc','.end');fs.writeFileSync('/tmp/dev.cir',L.join('\n'));
const out=cp.execFileSync(NG,['-b','/tmp/dev.cir'],{stdio:['ignore','pipe','ignore']}).toString();const get=k=>{const m=out.match(new RegExp(k.replace(/[()]/g,'\\$&').toLowerCase()+' = ([-+0-9.e]+)'));return m?+m[1]:NaN};
cases.forEach((c,j)=>{let a,b;if(c.t==='D'){a=[evalDiode(c.v1,c.par).i];b=[-get(`i(VA${j})`)]}
  else if(c.t==='Q'){const r=evalBJT(c.v1,c.v1-c.v2,c.par,c.pol);a=[r.ib,r.ic];b=[-get(`i(VB${j})`),-get(`i(VC${j})`)]}
  else{const r=evalMOS(c.v1,c.v2,c.par,c.pol);a=[r.id];b=[-get(`i(VD${j})`)]}
  const e=Math.max(...a.map((x,i)=>Math.abs(x-b[i])/Math.max(Math.abs(b[i]),1e-15)));if(e>1e-8)console.log(c.t,c.pol,c.v1.toFixed(3),c.v2.toFixed(3),'app',a.map(v=>v.toExponential(6)).join(','),'ng',b.map(v=>v.toExponential(6)).join(','),'rel',e.toExponential(1))});console.log('done')
