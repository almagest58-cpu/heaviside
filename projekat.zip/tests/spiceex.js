// built-in examples vs ngspice (netlist taken from the app's own interpretation of the drawn schematic)
const { chromium } = require('playwright');const {hpSolve}=require('./hp.js');const fs=require('fs');const cp=require('child_process');
const NGS=process.env.NGSPICE||'ngspice';const WD=fs.mkdtempSync(require('os').tmpdir()+'/rlc-');
const abs=z=>Math.hypot(z[0],z[1]);const div=(a,b)=>{const d=b[0]*b[0]+b[1]*b[1];return[(a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d]};
(async()=>{const b=await chromium.launch();const p=await (await b.newContext()).newPage();
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html')+'',{waitUntil:'domcontentloaded'});await p.waitForTimeout(400);
const keys=await p.evaluate(()=>Object.keys(EXAMPLES).filter(k=>!k.startsWith('o_')));const rows=[];
for(const real of[false,true])for(const k of keys){
  const a=await p.evaluate(({k,real})=>{const b=document.createElement('button');b.dataset.ex=k;document.getElementById('exList').appendChild(b);b.click();b.remove();closeAll();state.realMode=real;circuitChanged();
    return{mode:NET.mode,vin:NET.vin,gnd:NET.gnd,vout:NET.vout,edges:(NET.edges||[]).map(e=>({a:e.a,b:e.b,k:e.el.kind,v:e.el.val,name:e.el.name})),fmin:state.fmin,fmax:state.fmax,pts:data?data.allPoints.map(q=>q.f):[],nodata:!data,err:NET.err,act:(NET.ctrl||[]).length+(NET.vccs||[]).length,xf:(NET.xf||[]).map(x=>[x.p1,x.n1,x.p2,x.n2,x.N.val])}},{k,real});
  if(a.nodata){console.log("NODATA",k,real,a.err);continue}
  if(a.act)continue;/* active examples are checked by ospice.js (op-amps) and stest.js (transistors) */
  const nn=x=>x===a.gnd?'0':x===a.vin?'Nin':x===a.vout?'Nout':'N'+x;const zm=a.mode==='Z';
  const L=['* '+k,'V1 Nin 0 DC 0 AC 1'];a.edges.forEach((e,j)=>L.push(`${e.k}${j+1} ${nn(e.a)} ${nn(e.b)} ${e.v.toPrecision(17)}`));a.xf.forEach(([p1,n1,p2,n2,n],j)=>L.push(`VXS${j} ${nn(p1)} XA${j} 0`,`EXS${j} XA${j} ${nn(n1)} ${nn(p2)} ${nn(n2)} ${n.toPrecision(17)}`,`FXS${j} ${nn(n2)} ${nn(p2)} VXS${j} ${n.toPrecision(17)}`));
  L.push('.control','option noopac','set filetype=ascii',`ac dec 50 ${a.fmin} ${a.fmax}`,`write ${WD}/${k}${real?'R':''}.raw ${zm?'':'v(Nout) '}i(V1)`);
  a.pts.forEach((f,i)=>{L.push(`ac lin 1 ${f.toPrecision(17)} ${f.toPrecision(17)}`,`write ${WD}/${k}${real?'R':''}_p${i}.raw ${zm?'':'v(Nout) '}i(V1)`)});L.push('quit','.endc','.end');
  fs.writeFileSync(`${WD}/${k}${real?'R':''}.cir`,L.join('\n'));cp.execFileSync(NGS,['-b',`${WD}/${k}${real?'R':''}.cir`],{stdio:'ignore'});
  const parse=file=>{const txt=fs.readFileSync(file,'utf8');const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];const vals=txt.split('Values:')[1].trim().split(/\s+/);const out=[];for(let i=0;i<vals.length;){i++;const row=[];for(let v=0;v<nv;v++){row.push(vals[i++].split(',').map(Number))}out.push(row)}return out};
  const rowsS=parse(`${WD}/${k}${real?'R':''}.raw`).concat(a.pts.map((f,i)=>parse(`${WD}/${k}${real?'R':''}_p${i}.raw`)[0]));
  const fsq=rowsS.map(r=>r[0][0]);const av=await p.evaluate(fs_=>fs_.map(f=>[resp(f),solve(f,'zin')]),fsq);
  let wH=0,wZ=0,wdB=0,tbA=0,tbS=0,nTB=0;const hpE=a.edges.map(e=>({a:e.a===a.gnd?'g':e.a===a.vin?'i':e.a===a.vout?'o':'n'+e.a,b:e.b===a.gnd?'g':e.b===a.vin?'i':e.b===a.vout?'o':'n'+e.b,k:e.k,v:e.v}));const ref=rowsS.map(r=>zm?div([1,0],[-r[1][0],-r[1][1]]):r[1]);const refZ=rowsS.map(r=>div([1,0],[-r[zm?1:2][0],-r[zm?1:2][1]]));const mx=Math.max(...ref.map(abs).filter(isFinite)),mxZ=Math.max(...refZ.map(abs).filter(isFinite));
  rowsS.forEach((r,i)=>{const h=av[i][0],z=av[i][1];if(!isFinite(abs(ref[i]))||!isFinite(abs(refZ[i])))return;wH=Math.max(wH,Math.hypot(h[0]-ref[i][0],h[1]-ref[i][1])/Math.max(abs(ref[i]),1e-9*mx));wZ=Math.max(wZ,Math.hypot(z[0]-refZ[i][0],z[1]-refZ[i][1])/Math.max(abs(refZ[i]),1e-9*mxZ));const ez=Math.hypot(z[0]-refZ[i][0],z[1]-refZ[i][1])/Math.max(abs(refZ[i]),1e-9*mxZ);if(ez>1e-6&&abs(refZ[i])<1e12){const o=hpSolve(hpE,fsq[i],true);nTB++;tbA=Math.max(tbA,Math.hypot(z[0]-o[0],z[1]-o[1])/abs(o));tbS=Math.max(tbS,Math.hypot(refZ[i][0]-o[0],refZ[i][1]-o[1])/abs(o))}if(abs(ref[i])>mx*1e-10)wdB=Math.max(wdB,Math.abs(20*Math.log10(abs(h)/abs(ref[i]))))});
  rows.push([k+(real?' (real)':''),a.edges.length,rowsS.length,wH.toExponential(1),wdB.toExponential(1),wZ.toExponential(1),nTB?('disputed '+nTB+': app err '+tbA.toExponential(1)+' vs ngspice err '+tbS.toExponential(1)):''])}
console.log('example | elements | points | max rel H | max dB err | max rel Zin');rows.forEach(r=>console.log(r.join(' | ')));await b.close()})();
