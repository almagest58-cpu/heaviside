// Numerical check of every formula the app writes (derivation steps, as LaTeX):
// each displayed equation "A = B = C" is parsed and evaluated with the element values at several frequencies (s = jω);
// all sides must agree, quantities defined in earlier steps (Z_A, N_r, D_i, a_k, ...) are carried forward,
// and the final H(s) / Z(s) / |H(jω)| / φ(ω) are compared with the app's numeric solver.
const C={add:(a,b)=>[a[0]+b[0],a[1]+b[1]],sub:(a,b)=>[a[0]-b[0],a[1]-b[1]],mul:(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]],div:(a,b)=>{const d=b[0]*b[0]+b[1]*b[1];return[(a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d]},abs:a=>Math.hypot(a[0],a[1]),
  sqrt:a=>{const r=Math.hypot(a[0],a[1]);const x=Math.sqrt((r+a[0])/2),y=Math.sign(a[1]||1)*Math.sqrt(Math.max(0,(r-a[0])/2));return[x,y]},
  pow:(a,n)=>{if(Number.isInteger(n)&&Math.abs(n)<=64){let r=[1,0];for(let i=0;i<Math.abs(n);i++)r=C.mul(r,a);return n<0?C.div([1,0],r):r}const r=Math.hypot(a[0],a[1]),t=Math.atan2(a[1],a[0]);const m=Math.pow(r,n);return[m*Math.cos(n*t),m*Math.sin(n*t)]}};
class Unk extends Error{constructor(n){super('unknown '+n);this.name_=n}}
function tokenize(s){const T=[];let i=0;while(i<s.length){const c=s[i];
  if(/\s/.test(c)){i++;continue}
  if(c==='\\'){let j=i+1;if(/[a-zA-Z]/.test(s[j])){while(j<s.length&&/[a-zA-Z]/.test(s[j]))j++}else j++;const cmd=s.slice(i,j);i=j;
    if([',',';','!',':',' '].includes(cmd.slice(1))||cmd==='\\quad'&&false){T.push({t:'sp',v:cmd});continue}
    if(cmd==='\\{'||cmd==='\\}'){T.push({t:cmd==='\\{'?'(':')',v:cmd});continue}
    T.push({t:'cmd',v:cmd});continue}
  if(/[0-9.]/.test(c)){let j=i;while(j<s.length&&/[0-9.]/.test(s[j]))j++;T.push({t:'num',v:+s.slice(i,j)});i=j;continue}
  if(/[a-zA-Z]/.test(c)){T.push({t:'id',v:c});i++;continue}
  T.push({t:c,v:c});i++}
  const U=T.filter(x=>x.t!=='sp');
  /* |NAME| (a magnitude written as one symbol, e.g. \left|H(j\omega)\right|) becomes a single name */
  const out=[];for(let k=0;k<U.length;k++){const x=U[k];if(x.t==='cmd'&&x.v==='\\left'&&U[k+1]&&U[k+1].t==='|'){let j=k+2;while(j<U.length&&!(U[j].t==='cmd'&&U[j].v==='\\right'))j++;
      const inner=U.slice(k+2,j);const rs=inner.map(q=>q.t==='num'?String(q.v):q.v).join('');if(U[j+1]&&U[j+1].t==='|'&&/^\\?[A-Za-z]+(_\{[^{}]*\})?(\((s|j\\omega|\\omega)\))?$/.test(rs)&&inner.length<=8){out.push({t:'id',v:'|'+rs+'|',whole:true});k=j+1;continue}}
    out.push(x)}return out}
const GREEK=new Set(['\\omega','\\pi','\\varphi','\\phi','\\zeta','\\tau','\\alpha','\\beta','\\gamma','\\Gamma','\\theta','\\sigma','\\Delta','\\delta','\\mu','\\lambda','\\rho','\\epsilon','\\varepsilon','\\eta','\\kappa','\\psi','\\xi','\\chi','\\nu','\\Omega','\\Phi']);
const FUNCNAMES=new Set(['H','N','D','Z','Y','P','\\varphi','\\phi','G','A','\\Gamma','T','V','I','F','X','B','Q','M']);
const raw=(toks,a,b)=>toks.slice(a,b).map(x=>x.t==='num'?String(x.v):x.v).join('');
function parseExpr(toks,env){let i=0;const peek=()=>toks[i],eat=v=>{const x=toks[i];if(!x||(v&&x.v!==v&&x.t!==v))throw new Error('expected '+v+' got '+(x&&x.v));i++;return x};
  const group=()=>{const x=peek();if(x&&x.t==='{'){i++;const v=expr();eat('}');return v}return atom(true)};
  const groupRaw=()=>{const x=peek();if(x&&x.t==='{'){let d=0,j=i;for(;j<toks.length;j++){if(toks[j].t==='{')d++;else if(toks[j].t==='}'){d--;if(!d)break}}const r=raw(toks,i+1,j);i=j+1;return r}i++;return x.t==='num'?String(x.v):x.v};
  function name(base){let nm=base;if(peek()&&peek().t==='_'){i++;nm+='_{'+groupRaw()+'}'}
    /* function notation H(s), N(j\omega), \varphi(\omega) */
    if(FUNCNAMES.has(base)&&peek()&&peek().t==='('){let d=0,j=i;for(;j<toks.length;j++){if(toks[j].t==='(')d++;else if(toks[j].t===')'){d--;if(!d)break}}const inner=raw(toks,i+1,j);if(['s','j\\omega','\\omega','f','t'].includes(inner)){i=j+1;nm+='('+inner+')'}}
    return nm}
  function lookup(nm){if(nm in env)return env[nm];throw new Unk(nm)}
  function atom(single){const x=peek();if(!x)throw new Error('eof');
    if(x.t==='num'){i++;return[x.v,0]}
    if(x.t==='{'){i++;const v=par();eat('}');return v}
    if(x.t==='('){i++;const v=par();eat(')');return v}
    if(x.t==='|'){i++;const v=expr();eat('|');return[C.abs(v),0]}
    if(x.t==='-'&&single){i++;const v=atom(true);return[-v[0],-v[1]]}
    if(x.t==='id'&&x.whole){i++;return lookup(x.v)}
    if(x.t==='id'){i++;if(x.v==='j'&&!(peek()&&peek().t==='_'))return[0,1];
      const nm=name(x.v);if(nm==='s')return env.s;if(nm==='f')return[env.f,0];if(nm==='e')return[Math.E,0];return lookup(nm)}
    if(x.t==='cmd'){i++;const c=x.v;
      if(c==='\\frac'||c==='\\dfrac'||c==='\\tfrac'){const a=group(),b=group();return C.div(a,b)}
      if(c==='\\sqrt'){return C.sqrt(group())}
      if(c==='\\left'){const o=eat();if(o.v==='('||o.v==='['||o.v==='.'||o.v==='\\{'){const v=par();eat('\\right');eat();return v}if(o.v==='|'){const v=expr();eat('\\right');eat();return[C.abs(v),0]}throw new Error('left '+o.v)}
      if(c==='\\omega'&&!(peek()&&peek().t==='_'))return[env.w,0];if(c==='\\pi')return[Math.PI,0];
      if(c==='\\cdot'||c==='\\times')throw new Error('stray op');
      if(c==='\\operatorname'){const n=groupRaw();if(n==='atan2'){if(peek()&&peek().v==='\\left'){i++;eat()}else eat('(');const a=expr();eat(',');const b=expr();if(peek()&&peek().v==='\\right'){i++;eat()}else eat(')');
          if(Math.abs(a[1])>1e-9*Math.max(1e-300,C.abs(a))||Math.abs(b[1])>1e-9*Math.max(1e-300,C.abs(b)))throw new Error('complex atan2 arg');return[Math.atan2(a[0],b[0]),0]}
        if(n==='Re'||n==='Im'){if(!peek()||!(peek().t==='('||peek().t==='{'||(peek().t==='cmd'&&peek().v==='\\left')))throw new Unk(n);const v=atom(true);return[n==='Re'?v[0]:v[1],0]}throw new Error('opname '+n)}
      if(c==='\\arctan'){const v=atom(true);return[Math.atan(v[0]),0]}
      if(c==='\\log'){if(peek()&&peek().t==='_'){i++;groupRaw()}const v=atom(true);return[Math.log10(C.abs(v)),0]}
      if(c==='\\ln'){const v=atom(true);return[Math.log(C.abs(v)),0]}
      if(c==='\\mathrm'||c==='\\mathit'){const n=groupRaw();return lookup(n)}
      if(GREEK.has(c)){const nm=name(c);return lookup(nm)}
      throw new Error('cmd '+c)}
    throw new Error('tok '+x.t+' '+x.v)}
  function factor(){let v=atom(false);while(peek()&&peek().t==='^'){i++;const e=group();if(Math.abs(e[1])>0)throw new Error('cplx exp');v=C.pow(v,e[0])}
    while(peek()&&peek().t==="'")throw new Error('prime');return v}
  function term(){let v=factor();for(;;){const x=peek();if(!x)break;if(x.t==='+'||x.t==='-'||x.t===')'||x.t==='}'||x.t===','||x.t==='|'||x.t==='='||(x.t==='cmd'&&(x.v==='\\right'||x.v==='\\parallel')))break;
      if(x.t==='cmd'&&(x.v==='\\cdot'||x.v==='\\times')){i++;v=C.mul(v,factor());continue}if(x.t==='/'){i++;v=C.div(v,factor());continue}v=C.mul(v,factor())}return v}
  function expr(){let v;const x=peek();if(x&&(x.t==='-'||x.t==='+')){i++;v=term();if(x.t==='-')v=[-v[0],-v[1]]}else v=term();
    for(;;){const y=peek();if(!y||(y.t!=='+'&&y.t!=='-'))break;i++;const w=term();v=y.t==='+'?C.add(v,w):C.sub(v,w)}return v}
  function par(){let v=expr();while(peek()&&peek().t==='cmd'&&peek().v==='\\parallel'){i++;const w=expr();v=C.div(C.mul(v,w),C.add(v,w))}return v}
  const v=par();if(i<toks.length)throw new Error('trailing '+raw(toks,i,i+4));return v}
/* split a token list at top level on a predicate */
function splitTop(toks,isSep){const out=[[]];let d=0;for(const x of toks){if(x.t==='{'||x.t==='('||(x.t==='cmd'&&x.v==='\\left'))d++;else if(x.t==='}'||x.t===')'||(x.t==='cmd'&&x.v==='\\right'))d--;
    if(d===0&&isSep(x))out.push([]);else out[out.length-1].push(x)}return out}
const SKIP=['\\text','\\approx','\\to','\\in','<','>','\\le','\\ge','\\leq','\\geq','\\neq','\\ll','\\gg','\\infty','\\pm','\\mp','\\ldots','\\cdots','\\sum','\\prod','\\int','\\lim','\\propto','\\angle','\\circ','\\%','\\mathrm{dB}','\\mid','\\sim','\\equiv'];
/* returns list of findings for one derivation (array of LaTeX strings), evaluated at frequencies fs */
function checkDerivation(eqs,vals,fs,refs){const findings=[];const stats={eq:0,checked:0,defined:0,unk:new Set(),parseFail:[]};
  const envs=fs.map(f=>Object.assign({s:[0,2*Math.PI*f],w:2*Math.PI*f,f},vals));
  for(const tex of eqs){let body=tex.replace(/^\\\[|\\\]$/g,'');
    // \xrightarrow{...} acts like '=' (substitution s = jω), \Rightarrow separates statements
    body=body.replace(/\\xrightarrow\{[^{}]*\}/g,' = ');
    const toks=tokenize(body);
    const stmts=splitTop(toks,x=>(x.t==='cmd'&&(x.v==='\\qquad'||x.v==='\\quad'||x.v==='\\Rightarrow'||x.v==='\\Leftrightarrow'||x.v==='\\implies'))||x.t===';');
    for(let st of stmts){while(st.length&&st[st.length-1].t===',')st.pop();while(st.length&&st[0].t===',')st.shift();if(!st.length)continue;stats.eq++;
      const txt=raw(st,0,st.length);if(st.some(x=>SKIP.includes(x.v)||x.t===':'||x.t==='&'||(x.t==='cmd'&&/^\\(begin|end|dots|text|mathrm)$/.test(x.v)&&x.v!=='\\mathrm'))||/dB/.test(txt))continue;
      const parts=splitTop(st,x=>x.t==='=');if(parts.length<2)continue;
      {const last=raw(parts[parts.length-1],0,99);const lhs0=raw(parts[0],0,99);const bareLHS=/^(\\?[A-Za-z]+)(_\{[^{}]*(\{[^{}]*\}[^{}]*)*\}|_.)?(\((s|j\\omega|\\omega)\))?$/.test(lhs0)||/^\|[^|]*\|$/.test(lhs0);
        if(last==='0'&&(parts.length>=3||!bareLHS))parts.pop()}if(parts.length<2)continue;
      /* evaluate every part at every frequency */
      const vals_=parts.map(()=>[]);const unk=parts.map(()=>null);const perr=parts.map(()=>null);
      for(let k=0;k<fs.length;k++)parts.forEach((pt,j)=>{if(unk[j]||perr[j])return;try{vals_[j][k]=parseExpr(pt,envs[k])}catch(e){if(e instanceof Unk)unk[j]=e.name_;else perr[j]=e.message}});
      perr.forEach((e,j)=>{if(e&&!unk[j])stats.parseFail.push(raw(parts[j],0,parts[j].length)+'  ['+e+']')});
      /* definition: first part is a plain name not yet known */
      const lhs=raw(parts[0],0,parts[0].length);
      const ok=parts.map((_,j)=>!unk[j]&&!perr[j]);
      if(!ok[0]&&unk[0]){const firstOK=ok.findIndex(Boolean);if(firstOK>0){/* define the unknown name (only when the lhs is that bare name) */
          const nm=unk[0];const bare=raw(parts[0],0,parts[0].length);if(bare===nm||bare==='\\left|'+nm+'\\right|'){if(bare===nm)envs.forEach((e,k)=>e[nm]=vals_[firstOK][k]);stats.defined++;ok[0]=bare===nm;if(ok[0])vals_[0]=vals_[firstOK]}}}
      parts.forEach((_,j)=>{if(unk[j])stats.unk.add(unk[j])});
      const idx=ok.map((v,j)=>v?j:-1).filter(j=>j>=0);
      if(idx.length>=2){stats.checked++;const a=idx[0];for(const b of idx.slice(1))for(let k=0;k<fs.length;k++){const x=vals_[a][k],y=vals_[b][k];const sc=Math.max(C.abs(x),C.abs(y));const e=C.abs(C.sub(x,y))/Math.max(sc,1e-300);
          if(!(e<1e-7)&&!(sc<1e-280)){findings.push({eq:txt,part:raw(parts[b],0,parts[b].length),f:fs[k],a:x,b:y,rel:e});break}}}
      /* compare known final quantities with the app's numeric results */
      if(refs){const n0=lhs;for(let k=0;k<fs.length;k++){const r=refs[k];const vv=idx.length?vals_[idx[idx.length-1]][k]:null;if(!vv)break;
          const cmp=(want,label)=>{const e=C.abs(C.sub(vv,want))/Math.max(C.abs(want),1e-300);if(!(e<1e-7))findings.push({eq:txt,part:label,f:fs[k],a:vv,b:want,rel:e,vsApp:true})};
          if(n0==='H(s)'||n0==='H(j\\omega)'||n0==='Z(s)'||n0==='Z(j\\omega)'||n0==='Z_{in}(s)'||n0==='Z_{in}(j\\omega)'||n0==='Z_{in}')cmp(refs.isZ?r.z:r.h,'vs app numeric '+n0);
          else if(n0==='|H(j\\omega)|'||n0==='|Z(j\\omega)|')cmp([C.abs(refs.isZ?r.z:r.h),0],'vs app |.|');
          else if(n0==='\\varphi(\\omega)'){const ref=refs.isZ?r.z:r.h;let d=vv[0]-Math.atan2(ref[1],ref[0]);d=Math.atan2(Math.sin(d),Math.cos(d));if(Math.abs(d)>1e-7)findings.push({eq:txt,part:'vs app phase',f:fs[k],a:vv,b:[Math.atan2(ref[1],ref[0]),0],rel:d,vsApp:true})}}}}}
  return{findings,stats}}
module.exports={checkDerivation,tokenize,parseExpr};
