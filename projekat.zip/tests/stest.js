// semiconductor circuits (diodes, BJTs, MOSFETs, DC sources): app operating point and small-signal AC vs ngspice (.op + .ac)
const { chromium } = require('playwright');const fs=require('fs'),cp=require('child_process');
const NGS=process.env.NGSPICE||'/tmp/claude-0/-home-claude/3126b669-5ac5-5936-b9ef-b8aba5bf071a/scratchpad/ngs/inst/bin/ngspice';
const WD=fs.mkdtempSync(require('os').tmpdir()+'/st-');
let seed=+(process.env.SEED||11);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const VT=1.380649e-23*300.15/1.602176634e-19,TC=VT*1.6021918e-19/1.3806226e-23-273.15;
const qsc=()=>({bf:logU(50,400),br:pick([1,2,5]),va:pick([0,50,100,200]),is:pick([1e-15,1e-14,1e-16]),cpi:pick([0,logU(1e-12,3e-11)]),cmu:pick([0,logU(5e-13,5e-12)])});
const msc=()=>({vth:logU(0.4,2),k:logU(2e-4,2e-2),lam:pick([0,0.01,0.05]),cgs:pick([0,logU(1e-13,1e-11)]),cgd:pick([0,logU(1e-14,2e-12)])});
const dsc=()=>({is:pick([1e-14,1e-8,2.5e-9]),n:pick([1,1,1.9]),cj:pick([0,logU(1e-12,1e-11)]),tt:pick([0,logU(1e-9,1e-7)])});
/* topology library: every circuit has nodes g (ground), i (Vin), o (Vout, absent in Z mode) */
function gen(){const C={els:[],vdc:[],idc:[],devs:[],vindc:0,zmode:false};const E=(k,a,b,v)=>C.els.push({k,a,b,v});const R=(a,b,v)=>E('R',a,b,v||logU(100,1e5));const Cc=(a,b,v)=>E('C',a,b,v||logU(1e-9,1e-5));
  const VS=(a,b,v)=>C.vdc.push({a,b,v});const Q=(b,c,e,pol)=>C.devs.push({k:'Q',b,c,e,pol,sc:qsc()});const M=(g,d,s,pol)=>C.devs.push({k:'M',g,d,s,pol,sc:msc()});const D=(a,b)=>C.devs.push({k:'D',a,b,sc:dsc()});
  const typ=+(process.env.TYP||Math.floor(rnd()*(process.env.REAL?12:13)));C.typ=typ;const pol=rnd()<0.5?1:-1;const vcc=logU(3,20);
  // supply node 'vc' at pol·vcc
  switch(typ){
  case 0: /* common emitter, divider bias, emitter resistor with bypass, coupling caps */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','b');R('b','g');R('vc','c',logU(1e3,2e4));R('e','g',logU(100,5e3));if(rnd()<0.7)Cc('e','g',logU(1e-6,1e-4));Cc('i','b');Cc('c','o');R('o','g',logU(1e3,1e5));Q('b','c','e',pol);break;
  case 1: /* common source */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','gg',logU(1e5,2e6));R('gg','g',logU(1e5,2e6));R('vc','d',logU(500,2e4));R('s','g',logU(50,5e3));if(rnd()<0.6)Cc('s','g',logU(1e-6,1e-4));Cc('i','gg');Cc('d','o');R('o','g',logU(1e3,1e5));M('gg','d','s',pol);break;
  case 2: /* emitter follower */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','b');R('b','g');R('e','g',logU(200,1e4));Cc('i','b');Cc('e','o');R('o','g',logU(100,1e4));Q('b','vc','e',pol);break;
  case 3: /* source follower */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','gg',logU(1e5,2e6));R('gg','g',logU(1e5,2e6));R('s','g',logU(200,1e4));Cc('i','gg');Cc('s','o');R('o','g',logU(1e3,1e5));M('gg','vc','s',pol);break;
  case 4: /* differential pair, tail resistor, dual supply, output at one collector */
    VS('vp','g',vcc);VS('g','vn',vcc);R('i','b1',logU(100,1e4));R('b2','g',logU(100,1e4));R('vp','o',logU(1e3,2e4));R('vp','c2',logU(1e3,2e4));R('t','vn',logU(1e3,3e4));Q('b1','o','t',1);Q('b2','c2','t',1);C.vindc=0;break;
  case 5: /* cascode */
    VS('vc','g',vcc);R('vc','b2',logU(1e4,1e5));R('b2','b1',logU(1e4,1e5));R('b1','g',logU(1e4,1e5));Cc('b2','g',1e-5);Cc('i','b1');R('vc','o',logU(1e3,1e4));Q('b1','m','e',1);Q('b2','o','m',1);R('e','g',logU(100,2e3));Cc('e','g',1e-4);break;
  case 6: /* diode biased by a DC current, AC through a resistor: v_o/v_i = r_d∥… / (R + …) */
    R('i','o',logU(100,1e5));D('o','g');C.idc.push({a:'g',b:'o',v:logU(1e-6,1e-2)});if(rnd()<0.5)Cc('o','g',logU(1e-10,1e-7));break;
  case 7: /* current mirror loaded, input via resistor into the reference */
    VS('vc','g',vcc);R('vc','r',logU(1e3,1e5));R('i','r',logU(1e3,1e5));Q('r','r','g',1);Q('r','o','g',1);R('vc','o',logU(1e3,1e5));break;
  case 8: /* common base */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','b');R('b','g');Cc('b','g',1e-5);R('vc','c',logU(1e3,2e4));R('e','g',logU(500,1e4));Cc('i','e');Cc('c','o');R('o','g',logU(1e3,1e5));Q('b','c','e',pol);break;
  case 9: /* two-stage CE, direct coupling, NPN then PNP */
    VS('vc','g',vcc);R('vc','b1',logU(5e4,5e5));R('b1','g',logU(1e4,1e5));R('vc','c1',logU(1e3,2e4));R('e1','g',logU(100,2e3));Cc('i','b1');Q('b1','c1','e1',1);R('vc','e2',logU(500,5e3));Q('c1','o','e2',-1);R('o','g',logU(1e3,2e4));break;
  case 10: /* NMOS with PMOS current-source load (CMOS gain stage), gate bias from Vin DC */
    VS('vc','g',vcc);C.vindc=logU(0.8,2.5);M('i','o','g',1);M('pb','o','vc',-1);VS('vc','pb',logU(1,3));R('o','g',logU(1e4,1e6));break;
  case 11: /* Darlington follower */
    VS('vc','g',vcc);R('vc','b');R('b','g');Cc('i','b');Q('b','vc','m',1);Q('m','vc','e',1);R('e','g',logU(100,5e3));Cc('e','o');R('o','g',logU(100,1e4));break;
  default: /* random mixture */
    {const nn=['g','i','o','n1','n2','n3','n4'];VS('n4','g',vcc*(rnd()<0.5?1:-1));for(const x of nn.slice(1))if(x!=='n4'){R(x,pick(nn.filter(y=>y!==x)))}
     for(let k=0;k<3;k++){const a=pick(nn),b=pick(nn);if(a!==b)E(pick(['R','C','L']),a,b,undefined)}
     const nd=1+Math.floor(rnd()*3);for(let k=0;k<nd;k++){const s3=()=>{const s=new Set();while(s.size<3)s.add(pick(nn));return[...s]};const t=pick(['D','Q','M']);const[a,b,c]=s3();if(t==='D')D(a,b);else if(t==='Q')Q(a,b,c,pick([1,-1]));else M(a,b,c,pick([1,-1]))}
     C.els.forEach(e=>{if(e.v===undefined)e.v=e.k==='R'?logU(100,1e5):e.k==='C'?logU(1e-11,1e-6):logU(1e-6,1e-2)});C.vindc=(rnd()*2-1)*2}}
  C.zmode=rnd()<0.12;if(process.env.ZG){C.zmode=true;C.els.push({k:'R',a:'i',b:'g',v:1e9})}
  return C}
function spice(C,tag){const nn=x=>x==='g'?'0':x;const L=['* '+tag,'.options reltol=1e-10 vntol=1e-14 abstol=1e-22 itl1=500 temp='+TC.toPrecision(15)+' tnom='+TC.toPrecision(15)];
  L.push(C.zmode?`IIN 0 i DC ${C.vinI||0} AC 1`:`VIN i 0 DC ${C.vindc} AC 1`);
  C.els.forEach((e,j)=>L.push(`${e.k}${j} ${nn(e.a)} ${nn(e.b)} ${e.v.toPrecision(17)}`));C.vdc.forEach((e,j)=>L.push(`VD${j} ${nn(e.a)} ${nn(e.b)} DC ${e.v.toPrecision(17)}`));C.idc.forEach((e,j)=>L.push(`ID${j} ${nn(e.a)} ${nn(e.b)} DC ${e.v.toPrecision(17)}`));
  C.devs.forEach((d,j)=>{const s=d.sc;if(d.k==='D')L.push(`D${j} ${nn(d.a)} ${nn(d.b)} DM${j}`,`.model DM${j} D(IS=${s.is} N=${s.n} CJO=${s.cj} M=0 TT=${s.tt})`);
    else if(d.k==='Q')L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${s.is} BF=${s.bf.toPrecision(17)} BR=${s.br}${s.va>0?' VAF='+s.va:''} CJE=${s.cpi} MJE=0 CJC=${s.cmu} MJC=0)`);
    else L.push(`M${j} ${nn(d.d)} ${nn(d.g)} ${nn(d.s)} ${nn(d.s)} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${(d.pol*s.vth).toPrecision(17)} KP=${s.k.toPrecision(17)} LAMBDA=${s.lam} IS=0 GAMMA=0 CGSO=${s.cgs} CGDO=${s.cgd})`)});
  const nodes=[...new Set([].concat(...C.els.map(e=>[e.a,e.b]),...C.vdc.map(e=>[e.a,e.b]),...C.devs.map(d=>[d.a,d.b,d.c,d.e,d.g,d.d,d.s].filter(Boolean)),['i']))].filter(x=>x!=='g');C.nodes=nodes;
  const out=C.zmode?'v(i)':'v(o)';
  L.push('.control','set filetype=ascii','op',`write ${WD}/${tag}_op.raw ${nodes.map(x=>'v('+x+')').join(' ')}`,`ac dec 4 1 1e9`,`write ${WD}/${tag}_ac.raw ${out}`,'quit','.endc','.end');
  fs.writeFileSync(`${WD}/${tag}.cir`,L.join('\n'));try{cp.execFileSync(NGS,['-b',`${WD}/${tag}.cir`],{stdio:'ignore',timeout:60000})}catch(e){return null}
  const parse=(file,cplx)=>{if(!fs.existsSync(file))return null;const txt=fs.readFileSync(file,'utf8');if(!txt.includes('Values:'))return null;const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];const vals=txt.split('Values:')[1].trim().split(/\s+/);const rows=[];
    for(let i=0;i<vals.length;){i++;const r=[];for(let v=0;v<nv;v++){const s=vals[i++];r.push(cplx?s.split(',').map(Number):+s.split(',')[0])}rows.push(r)}return rows};
  const op=parse(`${WD}/${tag}_op.raw`,false),ac=parse(`${WD}/${tag}_ac.raw`,true);if(!op||!ac)return null;
  const names=fs.readFileSync(`${WD}/${tag}_op.raw`,'utf8').split('\nVariables:')[1].split('Values:')[0].trim().split('\n').map(l=>l.trim().split(/\s+/)[1]);
  const V={};names.forEach((nm,i)=>{const m=nm.match(/^v\((.*)\)$/i);if(m)V[m[1]]=op[0][i]});return{V,ac:ac.map(r=>({f:r[0][0],y:r[1]}))}}
const N=+(process.env.N||60);const list=[];for(let i=0;i<N;i++){const c=gen();c.ssall=!!process.env.SSALL;list.push(c)}
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(400);
let nF=0,nNoF=0,worstF=0,worstOp=0,worstAC=0,nOK=0,nBoth=0,nAppFail=0,nSpFail=0,res=[];
for(const [ci,C] of list.entries()){if(process.env.ONLY&&+process.env.ONLY!==ci)continue;const sp=spice(C,'c'+ci);
  const fs_=sp?sp.ac.map(r=>r.f):[];
  const r=await p.evaluate(({C,fs_})=>{uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240+80];j++;return q};
    const pk={};
    for(const e of C.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
    for(const e of C.vdc){const[x,y]=pos();const q=mkP('VDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
    for(const e of C.idc){const[x,y]=pos();const q=mkP('IDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
    C.devs.forEach((d,k)=>{const[x,y]=pos();const q=mkP(d.k,x,y,0);q.sc=Object.assign({},d.sc);if(d.k!=='D')q.pol=d.pol;parts.push(q);pk[k]=q;
      if(d.k==='D'){add(d.a,q,0);add(d.b,q,1)}else if(d.k==='Q'){add(d.b,q,0);add(d.c,q,1);add(d.e,q,2)}else{add(d.g,q,0);add(d.d,q,1);add(d.s,q,2)}});
    const vin=mkP('VIN',0,-400);vin.dc=C.vindc;vin.idc=C.vinI||0;parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!C.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
    for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
    state.parts=parts;state.wires=wires;state.realMode=false;state.std=null;state.fmin=1;state.fmax=1e9;assignNames();SS_ALL=!!C.ssall;NET=netlist();
    if(!NET.ok)return{net:NET.err};
    /* DC voltage of each named node, read at the first terminal attached to it */
    const V={};for(const k in term){const[q,e]=term[k][0];V[k]=opV(NET.semi,q.id+':'+e)}
    const H=fs_.map(f=>C.zmode?solve(f,'zin'):resp(f));
    let st='';try{update()}catch(e){st='upd '+e.message}
    let F1=null,dz='';try{const h=derive();if(DER){const w=f=>2*Math.PI*f;F1=fs_.map(f=>cx.div(spValJ(DER.FR.N,w(f),DER.vals),spValJ(DER.FR.D,w(f),DER.vals)))}else dz=h.replace(/<[^>]+>/g,' ').slice(-120)}catch(e){st+=' der '+e.message}
    for(const g of['ohm','nyq','spec','smith']){try{deriveFor(g)}catch(e){st+=' '+g+':'+e.message}}
    try{renderSchematic();renderSelBar()}catch(e){st+=' UI:'+e.message}
    return{V,H,st,F1,dz}},{C,fs_});
  if(!sp){nSpFail++;if(r.net){nBoth++;continue}console.log('SPFAIL',ci,'typ',C.typ,'z',C.zmode);continue}
  if(r.net){nAppFail++;console.log('APPFAIL',ci,'typ',C.typ,r.net);continue}
  let eo=0;for(const x of C.nodes){if(r.V[x]==null)continue;const d=Math.abs(r.V[x]-sp.V[x])/Math.max(1,Math.abs(sp.V[x]));eo=Math.max(eo,d)}
  const mx=Math.max(1e-30,...sp.ac.map(q=>Math.hypot(...q.y)).filter(isFinite));let ea=0;sp.ac.forEach((q,i)=>{const a=r.H[i];const d=Math.hypot(a[0]-q.y[0],a[1]-q.y[1])/Math.max(Math.hypot(...q.y),1e-6*mx);if(!(d<=ea))ea=d});
  let ef=null;if(r.F1){ef=0;const mh=Math.max(1e-30,...r.H.map(q=>Math.hypot(...q)).filter(isFinite));r.F1.forEach((q,i)=>{const a=r.H[i];const d=Math.hypot(a[0]-q[0],a[1]-q[1])/Math.max(Math.hypot(...a),1e-6*mh);if(!(d<=ef))ef=d});nF++;worstF=Math.max(worstF,ef)}else nNoF++;
  nOK++;worstOp=Math.max(worstOp,eo);worstAC=Math.max(worstAC,ea);if(eo>1e-7||!(ea<(+process.env.ACT||1e-5))||r.st||(ef!==null&&!(ef<1e-6)))console.log('DIFF',ci,'typ',C.typ,'op',eo.toExponential(1),'ac',ea.toExponential(1),'formula',ef===null?'-':ef.toExponential(1),r.st);if(process.env.NOF&&ef===null)console.log('NOFORMULA',ci,r.dz);
  res.push({ci,typ:C.typ,eo,ea})}
console.log('circuits',N,'compared',nOK,'appFail',nAppFail,'spiceFail',nSpFail,'(both fail',nBoth+')','worst OP',worstOp.toExponential(2),'worst AC',worstAC.toExponential(2),'formulas',nF,'worst',worstF.toExponential(2),'no formula',nNoF,'pageerrors',errs.length,errs.slice(0,3).join(' | '));
fs.writeFileSync(__dirname+'/stest.json',JSON.stringify(res));await b.close()})();
