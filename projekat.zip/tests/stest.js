// semiconductor circuits (diodes, BJTs, MOSFETs, DC sources): app operating point and small-signal AC vs ngspice (.op + .ac)
const { chromium } = require('playwright');const fs=require('fs'),cp=require('child_process');
const NGS=process.env.NGSPICE||'/tmp/claude-0/-home-claude/3126b669-5ac5-5936-b9ef-b8aba5bf071a/scratchpad/ngs/inst/bin/ngspice';
const WD=fs.mkdtempSync(require('os').tmpdir()+'/st-');
let seed=+(process.env.SEED||11);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const VT=1.380649e-23*300.15/1.602176634e-19,TC=VT*1.6021918e-19/1.3806226e-23-273.15;
const QR=!!process.env.QREAL;/* real BJT / MOSFET parameters (used when the circuit is in real mode) */
const qsc=()=>Object.assign({bf:logU(50,400),br:pick([1,2,5]),va:pick([0,50,100,200]),is:pick([1e-15,1e-14,1e-16]),cpi:pick([0,logU(1e-12,3e-11)]),cmu:pick([0,logU(5e-13,5e-12)])},
  QR?{...(process.env.NOVA?{va:0}:{}),...(process.env.NOTF?{tf:0}:{}),ikf:pick([0,logU(1e-3,1)]),rb:pick([0,logU(1,300)]),rc:pick([0,logU(0.1,30)]),re:pick([0,logU(0.05,10)]),cje:pick([0,logU(1e-12,3e-11)]),vje:0.4+rnd()*0.6,mje:0.2+rnd()*0.6,
    cjc:pick([0,logU(5e-13,1e-11)]),vjc:0.4+rnd()*0.6,mjc:0.2+rnd()*0.6,tf:pick([0,logU(1e-11,1e-9)]),tr:pick([0,logU(1e-9,1e-6)])}:{});
const msc=()=>Object.assign({vth:logU(0.4,2),k:logU(2e-4,2e-2),lam:pick([0,0.01,0.05]),cgs:pick([0,logU(1e-13,1e-11)]),cgd:pick([0,logU(1e-14,2e-12)])},
  QR?{rg:pick([0,logU(0.1,50)]),rdr:pick([0,logU(0.01,10)]),rsr:pick([0,logU(0.01,10)]),cgd0:pick([0,logU(1e-13,1e-10)]),vjd:0.3+rnd(),mjd:0.2+rnd()*0.6,
    bis:logU(1e-15,1e-11),bn:pick([1,1.2]),brs:pick([0,logU(0.01,1)]),bcj:pick([0,logU(1e-12,1e-10)]),bvj:0.4+rnd()*0.6,bm:0.2+rnd()*0.6,btt:pick([0,logU(1e-9,1e-7)])}:{});
/* diode kinds: std, zen (BV/IBV), sch, led, var; R_S, C_j(V) (VJ, M) and TT are used when the circuit is in real mode (C_j always for var) */
const dsc=(dt)=>{dt=dt||pick(['std','std','zen','sch','led','var']);const b={dt,is:dt==='sch'?logU(1e-8,1e-6):dt==='led'?pick([1e-18,2e-20,6e-28]):pick([1e-14,1e-8,2.5e-9]),n:dt==='led'?2:pick([1,1,1.9]),
  rs:pick([0,logU(0.01,20)]),cj:dt==='var'?logU(1e-11,1e-10):pick([0,logU(1e-12,1e-10)]),vj:0.3+rnd()*1.5,m:0.25+rnd()*0.65,tt:pick([0,logU(1e-9,1e-7)])};if(dt==='zen'){b.bv=logU(2,30);b.ibv=logU(1e-5,2e-2)}return b};
/* topology library: every circuit has nodes g (ground), i (Vin), o (Vout, absent in Z mode) */
/* real MOSFET C_gd(V) emulated in ngspice exactly: charge Q = C0·f(V_GD) with f = depletion form below 0 and V above; a B source makes
   f(V) on node yq, a capacitor C0 from yq through a 0 V sense source, and an F source copies its current from gate to drain */
function cgdNet(j,g,d,pol,c0,vj,m){const a=pol>0?g:d,b=pol>0?d:g;const V=x=>x==='0'?'0':`v(${x})`;const v=`(${V(a)}-${V(b)})`;
  return[`BQ${j} yq${j} 0 V=(${v}<0)?(${vj}*(1-pow(1-${v}/${vj},${1-m}))/${1-m}):(${v})`,`CQ${j} yq${j} zq${j} ${c0}`,`VQ${j} zq${j} 0 0`,`FQ${j} ${a} ${b} VQ${j} 1`]}
function gen(){const C={els:[],vdc:[],idc:[],devs:[],vindc:0,zmode:false};const E=(k,a,b,v)=>C.els.push({k,a,b,v});const R=(a,b,v)=>E('R',a,b,v||logU(100,1e5));const Cc=(a,b,v)=>E('C',a,b,v||logU(1e-9,1e-5));
  const VS=(a,b,v)=>C.vdc.push({a,b,v});C.xf=[];const XF=(p1,n1,p2,n2,n)=>{const lm=logU(1e-4,10);C.xf.push({p1,n1,p2,n2,n:n||logU(0.1,30),par:{lm,l1:lm*logU(1e-4,0.05),l2:lm*logU(1e-4,0.05)/Math.pow(n||1,2),r1:logU(0.01,50),r2:logU(0.01,50)}})};const Q=(b,c,e,pol)=>C.devs.push({k:'Q',b,c,e,pol,sc:qsc()});const M=(g,d,s,pol)=>C.devs.push({k:'M',g,d,s,pol,sc:msc()});const D=(a,b,dt)=>C.devs.push({k:'D',a,b,sc:dsc(dt)});
  const typ=+(process.env.TYP||(process.env.XFT?pick([16,17,18,18]):process.env.REAL?pick([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]):Math.floor(rnd()*16)));C.typ=typ;const pol=rnd()<0.5?1:-1;const vcc=logU(3,20);
  // supply node 'vc' at pol·vcc
  switch(typ){
  case 0: /* common emitter, divider bias, emitter resistor with bypass, coupling caps */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','b');R('b','g');R('vc','c',logU(1e3,2e4));R('e','g',logU(100,5e3));if(rnd()<0.7)Cc('e','g',logU(1e-6,1e-4));Cc('i','b');Cc('c','o');R('o','g',logU(1e3,1e5));Q('b','c','e',pol);break;
  case 1: /* common source */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','gg',logU(1e5,2e6));R('gg','g',logU(1e5,2e6));R('vc','d',logU(500,2e4));R('s','g',logU(50,5e3));if(rnd()<0.6)Cc('s','g',logU(1e-6,1e-4));Cc('i','gg');Cc('d','o');R('o','g',logU(1e3,1e5));M('gg','d','s',pol);break;
  case 2: /* emitter follower */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','b');R('b','g');R('e','g',logU(200,1e4));Cc('i','b');Cc('e','o');R('o','g',logU(100,1e4));Q('b','vc','e',pol);break;
  case 3: /* source follower */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','gg',logU(1e5,2e6));R('gg','g',logU(1e5,2e6));R('s','g',logU(200,1e4));Cc('i','gg');Cc('s','o');R('o','g',logU(1e3,1e5));M('gg','vc','s',pol);break;
  case 4: /* differential pair, tail resistor, dual supply, output at one collector */
    VS('vp','g',vcc);VS('g','vn',vcc);R('i','b1',logU(100,1e4));R('b2','g',logU(100,1e4));R('vp','o',logU(1e3,2e4));R('vp','c2',logU(1e3,2e4));R('t','vn',logU(1e3,3e4));Q('b1','o','t',1);Q('b2','c2','t',1);C.vindc=0;break;
  case 5: /* cascode */
    VS('vc','g',vcc);R('vc','b2',logU(1e4,1e5));R('b2','b1',logU(1e4,1e5));R('b1','g',logU(1e4,1e5));Cc('b2','g',1e-5);Cc('i','b1');R('vc','o',logU(1e3,1e4));Q('b1','m','e',1);Q('b2','o','m',1);R('e','g',logU(100,2e3));Cc('e','g',1e-4);break;
  case 6: /* diode biased by a DC current, AC through a resistor: v_o/v_i = r_d∥… / (R + …) */
    R('i','o',logU(100,1e5));D('o','g');C.idc.push({a:'g',b:'o',v:logU(1e-6,1e-2)});if(rnd()<0.5)Cc('o','g',logU(1e-10,1e-7));break;
  case 7: /* current mirror loaded, input via resistor into the reference */
    VS('vc','g',vcc);R('vc','r',logU(1e3,1e5));R('i','r',logU(1e3,1e5));Q('r','r','g',1);Q('r','o','g',1);R('vc','o',logU(1e3,1e5));break;
  case 8: /* common base */
    VS(pol>0?'vc':'g',pol>0?'g':'vc',vcc);R('vc','b');R('b','g');Cc('b','g',1e-5);R('vc','c',logU(1e3,2e4));R('e','g',logU(500,1e4));Cc('i','e');Cc('c','o');R('o','g',logU(1e3,1e5));Q('b','c','e',pol);break;
  case 9: /* two-stage CE, direct coupling, NPN then PNP */
    VS('vc','g',vcc);R('vc','b1',logU(5e4,5e5));R('b1','g',logU(1e4,1e5));R('vc','c1',logU(1e3,2e4));R('e1','g',logU(100,2e3));Cc('i','b1');Q('b1','c1','e1',1);R('vc','e2',logU(500,5e3));Q('c1','o','e2',-1);R('o','g',logU(1e3,2e4));break;
  case 10: /* NMOS with PMOS current-source load (CMOS gain stage), gate bias from Vin DC */
    VS('vc','g',vcc);C.vindc=logU(0.8,2.5);M('i','o','g',1);M('pb','o','vc',-1);VS('vc','pb',logU(1,3));R('o','g',logU(1e4,1e6));break;
  case 11: /* Darlington follower */
    VS('vc','g',vcc);R('vc','b');R('b','g');Cc('i','b');Q('b','vc','m',1);Q('m','vc','e',1);R('e','g',logU(100,5e3));Cc('e','o');R('o','g',logU(100,1e4));break;
  case 12: /* Zener regulator, ripple rejection */
    C.vindc=logU(8,30);R('i','o',logU(100,2000));D('g','o','zen');C.devs[0].sc.bv=logU(2,C.vindc*0.7);R('o','g',logU(500,1e5));break;
  case 13: /* varicap tuned LC, bias through a large resistor */
    R('i','o',logU(1e3,1e5));E('L','o','g',logU(1e-6,1e-3));Cc('o','g',logU(1e-11,1e-9));Cc('o','vv',1e-8);D('g','vv','var');R('vv','b',logU(1e4,1e6));VS('b','g',logU(0.5,20));break;
  case 14: /* LED or Schottky with a series resistor from a DC level */
    C.vindc=logU(2,10);R('i','o',logU(50,5e3));D('o','g',pick(['led','sch','std']));if(rnd()<0.5)R('o','g',logU(100,1e4));break;
  case 16: /* transformer-coupled common emitter: primary is the collector load, secondary drives R_L */
    VS('vc','g',vcc);R('vc','b');R('b','g');R('e','g',logU(100,2e3));Cc('e','g',logU(1e-6,1e-4));Cc('i','b');Q('b','c','e',1);XF('vc','c','o','g',logU(0.3,10));R('o','g',logU(10,1e4));break;
  case 17: /* source R, transformer, RLC network on the secondary (optionally phase-inverted) */
    R('i','a',logU(1,1e4));{const inv=rnd()<0.3;XF('a','g',inv?'g':'s',inv?'s':'g',logU(0.1,30))}R('s','o',logU(1,1e4));pick([()=>Cc('o','g',logU(1e-11,1e-6)),()=>E('L','o','g',logU(1e-6,1e-2)),()=>R('o','g',logU(10,1e5))])();R('o','g',logU(10,1e5));if(rnd()<0.4)D('o','g',pick(['std','sch']));break;
  case 18: /* random passive mixture with one or two transformers (each winding has its own DC path to ground) */
    {const nn=['g','i','o','n1','n2','n3'];for(const x of nn.slice(1))R(x,pick(nn.filter(y=>y!==x)));for(const x of nn.slice(1))if(rnd()<0.6)R(x,'g');
     for(let k=0;k<3;k++){const a=pick(nn),b=pick(nn);if(a!==b)E(pick(['R','C','L']),a,b,undefined)}
     const nx=1+(rnd()<0.4?1:0);for(let k=0;k<nx;k++){const s=new Set();while(s.size<4)s.add(pick(nn));const[a,b,c,d]=[...s];XF(a,b,c,d)}
     C.els.forEach(e=>{if(e.v===undefined)e.v=e.k==='R'?logU(10,1e5):e.k==='C'?logU(1e-11,1e-6):logU(1e-6,1e-2)});C.vindc=(rnd()*2-1)*2}break;
  default: /* random mixture */
    {const nn=['g','i','o','n1','n2','n3','n4'];VS('n4','g',vcc*(rnd()<0.5?1:-1));for(const x of nn.slice(1))if(x!=='n4'){R(x,pick(nn.filter(y=>y!==x)))}
     for(let k=0;k<3;k++){const a=pick(nn),b=pick(nn);if(a!==b)E(pick(['R','C','L']),a,b,undefined)}
     const nd=1+Math.floor(rnd()*3);for(let k=0;k<nd;k++){const s3=()=>{const s=new Set();while(s.size<3)s.add(pick(nn));return[...s]};const t=pick(['D','Q','M']);const[a,b,c]=s3();if(t==='D')D(a,b);else if(t==='Q')Q(a,b,c,pick([1,-1]));else M(a,b,c,pick([1,-1]))}
     C.els.forEach(e=>{if(e.v===undefined)e.v=e.k==='R'?logU(100,1e5):e.k==='C'?logU(1e-11,1e-6):logU(1e-6,1e-2)});C.vindc=(rnd()*2-1)*2}}
  C.zmode=rnd()<0.12;C.real=process.env.RM?process.env.RM==='1':rnd()<0.5;if(process.env.ZG){C.zmode=true;C.els.push({k:'R',a:'i',b:'g',v:1e9})}
  return C}
function spice(C,tag){const nn=x=>x==='g'?'0':x;const L=['* '+tag,'.options reltol=1e-10 vntol=1e-14 abstol=1e-22 itl1=500 temp='+TC.toPrecision(15)+' tnom='+TC.toPrecision(15)];
  L.push(C.zmode?`IIN 0 i DC ${C.vinI||0} AC 1`:`VIN i 0 DC ${C.vindc} AC 1`);
  C.els.forEach((e,j)=>L.push(`${e.k}${j} ${nn(e.a)} ${nn(e.b)} ${e.v.toPrecision(17)}`));C.vdc.forEach((e,j)=>L.push(`VD${j} ${nn(e.a)} ${nn(e.b)} DC ${e.v.toPrecision(17)}`));C.idc.forEach((e,j)=>L.push(`ID${j} ${nn(e.a)} ${nn(e.b)} DC ${e.v.toPrecision(17)}`));
  C.xf.forEach((x,j)=>{const P=x.par;if(!C.real)L.push(`VX${j} ${nn(x.p1)} xa${j} 0`,`EX${j} xa${j} ${nn(x.n1)} ${nn(x.p2)} ${nn(x.n2)} ${x.n.toPrecision(17)}`,`FX${j} ${nn(x.n2)} ${nn(x.p2)} VX${j} ${x.n.toPrecision(17)}`);
    else if(process.env.XFTEQ)L.push(`RXA${j} ${nn(x.p1)} xa${j} ${P.r1.toPrecision(17)}`,`LXA${j} xa${j} xb${j} ${P.l1.toPrecision(17)}`,`LXM${j} xb${j} ${nn(x.n1)} ${P.lm.toPrecision(17)}`,`VX${j} xb${j} xc${j} 0`,`EX${j} xc${j} ${nn(x.n1)} xd${j} ${nn(x.n2)} ${x.n.toPrecision(17)}`,`FX${j} ${nn(x.n2)} xd${j} VX${j} ${x.n.toPrecision(17)}`,`LXB${j} xd${j} xe${j} ${P.l2.toPrecision(17)}`,`RXB${j} xe${j} ${nn(x.p2)} ${P.r2.toPrecision(17)}`);
    else{const L1=P.l1+P.lm,L2=P.l2+P.lm/(x.n*x.n),M=P.lm/x.n;L.push(`RXA${j} ${nn(x.p1)} xa${j} ${P.r1.toPrecision(17)}`,`LXA${j} xa${j} ${nn(x.n1)} ${L1.toPrecision(17)}`,`RXB${j} ${nn(x.p2)} xb${j} ${P.r2.toPrecision(17)}`,`LXB${j} xb${j} ${nn(x.n2)} ${L2.toPrecision(17)}`,`KX${j} LXA${j} LXB${j} ${(M/Math.sqrt(L1*L2)).toPrecision(17)}`)}});
  C.devs.forEach((d,j)=>{const s=d.sc;const rl=C.real,cj=(rl||s.dt==='var')?s.cj:0;if(d.k==='D')L.push(`D${j} ${nn(d.a)} ${nn(d.b)} DM${j}`,`.model DM${j} D(IS=${s.is} N=${s.n} CJO=${cj} VJ=${s.vj} M=${s.m} TT=${rl?s.tt:0}${rl&&s.rs>0?' RS='+s.rs:''}${s.dt==='zen'?` BV=${s.bv} IBV=${s.ibv}`:''})`);
    else if(d.k==='Q'&&QR&&rl)L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${s.is} BF=${s.bf.toPrecision(17)} BR=${s.br}${s.va>0?' VAF='+s.va:''}${s.ikf>0?' IKF='+s.ikf:''} RB=${s.rb} RC=${s.rc} RE=${s.re} CJE=${s.cje} VJE=${s.vje} MJE=${s.mje} CJC=${s.cjc} VJC=${s.vjc} MJC=${s.mjc} TF=${s.tf} TR=${s.tr})`);
    else if(d.k==='Q')L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${s.is} BF=${s.bf.toPrecision(17)} BR=${s.br}${s.va>0?' VAF='+s.va:''} CJE=${s.cpi} MJE=0 CJC=${s.cmu} MJC=0)`);
    else if(QR&&rl){/* real MOSFET: series R, level-1 core with constant C_gs, C_gd(V) as a non-conducting junction (n = 100, its GMIN cancelled), body diode */
      const g=s.rg>0?'gi'+j:nn(d.g),dd=s.rdr>0?'di'+j:nn(d.d),ss=s.rsr>0?'si'+j:nn(d.s);if(s.rg>0)L.push(`RGI${j} ${nn(d.g)} ${g} ${s.rg}`);if(s.rdr>0)L.push(`RDI${j} ${nn(d.d)} ${dd} ${s.rdr}`);if(s.rsr>0)L.push(`RSI${j} ${nn(d.s)} ${ss} ${s.rsr}`);
      L.push(`M${j} ${dd} ${g} ${ss} ${ss} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${(d.pol*s.vth).toPrecision(17)} KP=${s.k.toPrecision(17)} LAMBDA=${s.lam} IS=0 GAMMA=0 CGSO=${s.cgs} CGDO=0)`);
      if(s.cgd0>0)L.push(...cgdNet(j,g,dd,d.pol,s.cgd0,s.vjd,s.mjd));
      L.push(d.pol>0?`DB${j} ${ss} ${dd} DBM${j}`:`DB${j} ${dd} ${ss} DBM${j}`,`.model DBM${j} D(IS=${s.bis} N=${s.bn} CJO=${s.bcj} VJ=${s.bvj} M=${s.bm} TT=${s.btt}${s.brs>0?' RS='+s.brs:''})`)}
    else L.push(`M${j} ${nn(d.d)} ${nn(d.g)} ${nn(d.s)} ${nn(d.s)} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${(d.pol*s.vth).toPrecision(17)} KP=${s.k.toPrecision(17)} LAMBDA=${s.lam} IS=0 GAMMA=0 CGSO=${s.cgs} CGDO=${s.cgd})`)});
  const nodes=[...new Set([].concat(...C.els.map(e=>[e.a,e.b]),...C.vdc.map(e=>[e.a,e.b]),...C.xf.map(x=>[x.p1,x.n1,x.p2,x.n2]),...C.devs.map(d=>[d.a,d.b,d.c,d.e,d.g,d.d,d.s].filter(Boolean)),['i']))].filter(x=>x!=='g');C.nodes=nodes;
  const out=C.zmode?'v(i)':'v(o)';
  L.push('.control','set filetype=ascii','op',`write ${WD}/${tag}_op.raw ${nodes.map(x=>'v('+x+')').join(' ')}`,`ac dec 4 1 1e9`,`write ${WD}/${tag}_ac.raw ${out}`,'quit','.endc','.end');
  fs.writeFileSync(`${WD}/${tag}.cir`,L.join('\n'));try{cp.execFileSync(NGS,['-b',`${WD}/${tag}.cir`],{stdio:'ignore',timeout:60000})}catch(e){return null}
  const parse=(file,cplx)=>{if(!fs.existsSync(file))return null;const txt=fs.readFileSync(file,'utf8');if(!txt.includes('Values:'))return null;const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];const vals=txt.split('Values:')[1].trim().split(/\s+/);const rows=[];
    for(let i=0;i<vals.length;){i++;const r=[];for(let v=0;v<nv;v++){const s=vals[i++];r.push(cplx?s.split(',').map(Number):+s.split(',')[0])}rows.push(r)}return rows};
  const op=parse(`${WD}/${tag}_op.raw`,false),ac=parse(`${WD}/${tag}_ac.raw`,true);if(!op||!ac)return null;
  const names=fs.readFileSync(`${WD}/${tag}_op.raw`,'utf8').split('\nVariables:')[1].split('Values:')[0].trim().split('\n').map(l=>l.trim().split(/\s+/)[1]);
  const V={};names.forEach((nm,i)=>{const m=nm.match(/^v\((.*)\)$/i);if(m)V[m[1]]=op[0][i]});return{V,ac:ac.map(r=>({f:r[0][0],y:r[1]}))}}
const N=+(process.env.N||60);process.env.RMOFF=process.env.RMOFF||"";const list=[];for(let i=0;i<N;i++){const c=gen();c.ssall=!!process.env.SSALL;c.edges=!!process.env.EDGES;c.expl=!!process.env.EXPL;c.rmoff=!!process.env.RMOFF;c.qreal=QR;list.push(c)}
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(400);
let nF=0,nNoF=0,worstF=0,worstOp=0,worstAC=0,nOK=0,nBoth=0,nAppFail=0,nSpFail=0,res=[];
for(const [ci,C] of list.entries()){if(process.env.ONLY&&+process.env.ONLY!==ci)continue;const sp=spice(C,'c'+ci);
  const fs_=sp?sp.ac.map(r=>r.f):[];
  const r=await p.evaluate(({C,fs_})=>{uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240+80];j++;return q};
    const pk={};
    for(const e of C.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.real=false;parts.push(q);add(e.a,q,0);add(e.b,q,1)}
    C.xf.forEach((e,xi)=>{const[x,y]=pos();const q=mkP('T',x,y,0,e.n);q.par=Object.assign({},e.par);parts.push(q);
      if(C.expl&&C.real){q.real=false;const P=e.par;const two=(k,v,a,b)=>{const[x2,y2]=pos();const r=mkP(k,x2,y2,0,v);r.real=false;parts.push(r);add(a,r,0);add(b,r,1)};
        two('R',P.r1,e.p1,'xa'+xi);two('L',P.l1,'xa'+xi,'xb'+xi);two('L',P.lm,'xb'+xi,e.n1);two('L',P.l2,'xd'+xi,'xe'+xi);two('R',P.r2,'xe'+xi,e.p2);add('xb'+xi,q,0);add(e.n1,q,1);add('xd'+xi,q,2);add(e.n2,q,3)}
      else{add(e.p1,q,0);add(e.n1,q,1);add(e.p2,q,2);add(e.n2,q,3)}});
    for(const e of C.vdc){const[x,y]=pos();const q=mkP('VDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
    for(const e of C.idc){const[x,y]=pos();const q=mkP('IDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
    C.devs.forEach((d,k)=>{const[x,y]=pos();const q=mkP(d.k,x,y,0);q.sc=Object.assign({},d.sc);if(d.k!=='D'){q.pol=d.pol;if(C.qreal)q.real=true}else{q.dt=d.sc.dt;delete q.sc.dt}parts.push(q);pk[k]=q;
      if(d.k==='D'){add(d.a,q,0);add(d.b,q,1)}else if(d.k==='Q'){add(d.b,q,0);add(d.c,q,1);add(d.e,q,2)}else{add(d.g,q,0);add(d.d,q,1);add(d.s,q,2)}});
    const vin=mkP('VIN',0,-400);vin.dc=C.vindc;vin.idc=C.vinI||0;parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!C.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
    for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
    state.parts=parts;state.wires=wires;state.realMode=!!C.real&&!C.rmoff;state.std=null;state.fmin=1;state.fmax=1e9;assignNames();SS_ALL=!!C.ssall;NET=netlist();
    if(!NET.ok)return{net:NET.err};
    /* DC voltage of each named node, read at the first terminal attached to it */
    const V={};for(const k in term){const[q,e]=term[k][0];V[k]=opV(NET.semi,q.id+':'+e)}
    const H=fs_.map(f=>C.zmode?solve(f,'zin'):resp(f));
    let st='';try{update()}catch(e){st='upd '+e.message}
    let F1=null,dz='';try{const h=derive();if(DER){const w=f=>2*Math.PI*f;F1=fs_.map(f=>cx.div(spValJ(DER.FR.N,w(f),DER.vals),spValJ(DER.FR.D,w(f),DER.vals)))}else dz=h.replace(/<[^>]+>/g,' ').slice(-120)}catch(e){st+=' der '+e.message}
    for(const g of['ohm','nyq','spec','smith']){try{deriveFor(g)}catch(e){st+=' '+g+':'+e.message}}
    try{renderSchematic();renderSelBar()}catch(e){st+=' UI:'+e.message}
    const ED=C.edges?{e:NET.edges.map(e=>[e.el.name,e.el.kind,e.el.val,e.a,e.b]),v:(NET.vccs||[]).map(x=>JSON.stringify(x,(k,v)=>k==='part'||k==='el'?undefined:v)),x:(NET.xf||[]).map(x=>[x.p1,x.n1,x.p2,x.n2,x.N.val])}:null;
    return{V,H,st,F1,dz,ED}},{C,fs_});
  if(r.ED)console.log(JSON.stringify(r.ED));
  if(!sp){nSpFail++;if(r.net){nBoth++;continue}console.log('SPFAIL',ci,'typ',C.typ,'z',C.zmode);continue}
  if(r.net){nAppFail++;console.log('APPFAIL',ci,'typ',C.typ,r.net);continue}
  let eo=0;for(const x of C.nodes){if(r.V[x]==null)continue;const d=Math.abs(r.V[x]-sp.V[x])/Math.max(1,Math.abs(sp.V[x]));eo=Math.max(eo,d)}
  const mx=Math.max(1e-30,...sp.ac.map(q=>Math.hypot(...q.y)).filter(isFinite));let ea=0;sp.ac.forEach((q,i)=>{const a=r.H[i];const d=Math.hypot(a[0]-q.y[0],a[1]-q.y[1])/Math.max(Math.hypot(...q.y),1e-6*mx);if(!(d<=ea))ea=d});
  let ef=null;if(r.F1){ef=0;const mh=Math.max(1e-30,...r.H.map(q=>Math.hypot(...q)).filter(isFinite));r.F1.forEach((q,i)=>{const a=r.H[i];const d=Math.hypot(a[0]-q[0],a[1]-q[1])/Math.max(Math.hypot(...a),1e-6*mh);if(!(d<=ef))ef=d});nF++;worstF=Math.max(worstF,ef)}else nNoF++;
  nOK++;worstOp=Math.max(worstOp,eo);worstAC=Math.max(worstAC,ea);if(eo>1e-7||!(ea<(+process.env.ACT||1e-5))||r.st||(ef!==null&&!(ef<1e-6)))console.log('DIFF',ci,'typ',C.typ,'op',eo.toExponential(1),'ac',ea.toExponential(1),'formula',ef===null?'-':ef.toExponential(1),r.st);if(process.env.NOF&&ef===null)console.log('NOFORMULA',ci,r.dz);
  if(process.env.DUMP)fs.writeFileSync(process.env.DUMP+'/d'+ci+'.json',JSON.stringify({app:r.H,sp:sp.ac,cir:fs.readFileSync(`${WD}/c${ci}.cir`,'utf8')}));
  res.push({ci,typ:C.typ,eo,ea})}
console.log('circuits',N,'compared',nOK,'appFail',nAppFail,'spiceFail',nSpFail,'(both fail',nBoth+')','worst OP',worstOp.toExponential(2),'worst AC',worstAC.toExponential(2),'formulas',nF,'worst',worstF.toExponential(2),'no formula',nNoF,'pageerrors',errs.length,errs.slice(0,3).join(' | '));
fs.writeFileSync(__dirname+'/stest.json',JSON.stringify(res));await b.close()})();
