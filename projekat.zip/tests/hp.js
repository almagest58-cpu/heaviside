// high-precision complex nodal solver (~72 significant digits), independent of app code
const P=240n,PN=240;
const bl=m=>{if(m===0n)return 0;let x=m<0n?-m:m;return x.toString(2).length};
function norm(m,e){const b=bl(m);if(b>PN){const sh=BigInt(b-PN);const half=1n<<(sh-1n);m=(m>=0n?(m+half):(m-half))>>sh;e+=Number(sh)}return{m,e}}
const ZERO={m:0n,e:0};
function fromF(x){if(x===0)return ZERO;const dv=new DataView(new ArrayBuffer(8));dv.setFloat64(0,x);const hi=dv.getUint32(0),lo=dv.getUint32(4);
  const neg=hi>>>31;const ex=(hi>>>20)&0x7ff;let m=(BigInt(hi&0xfffff)<<32n)|BigInt(lo);let e;if(ex===0)e=-1074;else{m|=1n<<52n;e=ex-1075}return{m:neg?-m:m,e}}
function mul(a,b){if(a.m===0n||b.m===0n)return ZERO;return norm(a.m*b.m,a.e+b.e)}
function add(a,b){if(a.m===0n)return b;if(b.m===0n)return a;
  const ta=a.e+bl(a.m),tb=b.e+bl(b.m);if(ta-tb>PN+8)return a;if(tb-ta>PN+8)return b;
  if(a.e>=b.e)return norm((a.m<<BigInt(a.e-b.e))+b.m,b.e);return norm(a.m+(b.m<<BigInt(b.e-a.e)),a.e)}
const neg=a=>({m:-a.m,e:a.e});const sub=(a,b)=>add(a,neg(b));
function div(a,b){if(a.m===0n)return ZERO;return norm((a.m<<(2n*P))/b.m,a.e-b.e-2*PN)}
function toF(a){if(a.m===0n)return 0;const b=bl(a.m);let m=a.m,e=a.e;if(b>60){const sh=b-60;m=m>>BigInt(sh);e+=sh}return Number(m)*Math.pow(2,e)}
const mag=a=>Math.abs(toF(a));
// complex
const C0=[ZERO,ZERO];
const cadd=(x,y)=>[add(x[0],y[0]),add(x[1],y[1])],csub=(x,y)=>[sub(x[0],y[0]),sub(x[1],y[1])];
const cmul=(x,y)=>[sub(mul(x[0],y[0]),mul(x[1],y[1])),add(mul(x[0],y[1]),mul(x[1],y[0]))];
const cdiv=(x,y)=>{const d=add(mul(y[0],y[0]),mul(y[1],y[1]));const n=cmul(x,[y[0],neg(y[1])]);return[div(n[0],d),div(n[1],d)]};
const cmag=x=>{const a=toF(x[0]),b=toF(x[1]);return Math.hypot(a,b)};
const isZ=x=>x[0].m===0n&&x[1].m===0n;
function hpSolve(edges,f,zmode){const w=mul(fromF(2*Math.PI*f),{m:1n,e:0});const ONE={m:1n,e:0};
  const Y=e=>{const v=fromF(e.v);if(e.k==='R')return[div(ONE,v),ZERO];if(e.k==='L')return[ZERO,neg(div(ONE,mul(w,v)))];return[ZERO,mul(w,v)]};
  const nodes=[...new Set(edges.flatMap(e=>[e.a,e.b]))].filter(n=>n!=='g'&&(zmode||n!=='i'));const ix={};nodes.forEach((n,i)=>ix[n]=i);const n=nodes.length;
  const A=nodes.map(()=>nodes.map(()=>C0)),b=nodes.map(()=>C0);
  for(const e of edges){const y=Y(e);const ia=ix[e.a],ib=ix[e.b];if(ia!==undefined)A[ia][ia]=cadd(A[ia][ia],y);if(ib!==undefined)A[ib][ib]=cadd(A[ib][ib],y);
    if(ia!==undefined&&ib!==undefined){A[ia][ib]=csub(A[ia][ib],y);A[ib][ia]=csub(A[ib][ia],y)}
    if(!zmode){if(e.a==='i'&&ib!==undefined)b[ib]=cadd(b[ib],y);if(e.b==='i'&&ia!==undefined)b[ia]=cadd(b[ia],y)}}
  if(zmode)b[ix['i']]=[ONE,ZERO];
  for(let c=0;c<n;c++){let p=c,bm=-1;for(let r=c;r<n;r++){const m=cmag(A[r][c]);if(m>bm){bm=m;p=r}}if(bm===0)return[NaN,NaN];[A[c],A[p]]=[A[p],A[c]];[b[c],b[p]]=[b[p],b[c]];
    for(let r=c+1;r<n;r++){if(isZ(A[r][c]))continue;const q=cdiv(A[r][c],A[c][c]);for(let k=c;k<n;k++)if(!isZ(A[c][k]))A[r][k]=csub(A[r][k],cmul(q,A[c][k]));b[r]=csub(b[r],cmul(q,b[c]))}}
  const x=Array(n);for(let r=n-1;r>=0;r--){let s=b[r];for(let k=r+1;k<n;k++)if(!isZ(A[r][k]))s=csub(s,cmul(A[r][k],x[k]));x[r]=cdiv(s,A[r][r])}
  const o=zmode?x[ix['i']]:x[ix['o']];return[toF(o[0]),toF(o[1])]}
module.exports={hpSolve};
