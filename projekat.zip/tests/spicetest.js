// Compares RLC Odziv against ngspice (independent SPICE engine)
const { chromium } = require('playwright');const {hpSolve}=require('./hp.js');const fs=require('fs');const cp=require('child_process');
const NGS=process.env.NGSPICE||'ngspice';
const WD=fs.mkdtempSync(require('os').tmpdir()+'/rlc-');
let seed=+(process.env.SEED||555);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const parOf=k=>k==='C'?{esr:logU(1e-3,1),esl:logU(1e-10,1e-8),rp:rnd()<0.5?1e12:logU(1e5,1e9)}:k==='R'?{ls:logU(1e-10,1e-7),cp:logU(1e-14,1e-11)}:{rdc:logU(1e-2,10),cp:logU(1e-13,1e-10)};
const val=k=>k==='R'?logU(1,1e5):k==='L'?logU(1e-7,1e-1):logU(1e-11,1e-4);const el=(a,b,k,v)=>({a,b,k,v:v===undefined?val(k):v,par:parOf(k)});
function gen(E){const zmode=rnd()<0.2;const nInt=Math.max(0,Math.round(E*0.5)-(zmode?2:3));const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:nInt},(_,j)=>'n'+j)];
  const order=nodes.slice().sort(()=>rnd()-0.5);const edges=[];for(let j=1;j<order.length;j++)edges.push(el(order[j],pick(order.slice(0,j)),pick(['R','L','C'])));while(edges.length<E){const a=pick(nodes),b=pick(nodes);if(a!==b)edges.push(el(a,b,pick(['R','L','C'])))}return{zmode,edges}}
function expand(edges,real){if(!real)return edges;const out=[];let c=0;for(const e of edges){const m=()=>'xx'+(c++);const p=e.par;
  if(e.k==='C'){const m1=m(),m2=m();out.push({a:e.a,b:m1,k:'R',v:p.esr},{a:m1,b:m2,k:'L',v:p.esl},{a:m2,b:e.b,k:'C',v:e.v});if(p.rp<1e12)out.push({a:m2,b:e.b,k:'R',v:p.rp})}
  else{const q=m();if(e.k==='R')out.push({a:e.a,b:q,k:'R',v:e.v},{a:q,b:e.b,k:'L',v:p.ls});else out.push({a:e.a,b:q,k:'R',v:p.rdc},{a:q,b:e.b,k:'L',v:e.v});out.push({a:e.a,b:e.b,k:'C',v:p.cp})}}return out}
const nn=x=>x==='g'?'0':'N'+x;
function runSpice(edges,zmode,freqs,tag){const lines=['* rlc odziv check','V1 Ni 0 DC 0 AC 1'];edges.forEach((e,j)=>lines.push(`${e.k}${j+1} ${nn(e.a)} ${nn(e.b)} ${e.v.toPrecision(17)}`));
  lines.push('.control','option noopac','set filetype=ascii');
  // dense sweep + list of extra frequencies
  lines.push('ac dec 40 1 1e9');lines.push(`write ${WD}/${tag}_sweep.raw ${zmode?'':'v(No) '}i(V1)`);
  freqs.forEach((f,k)=>{lines.push(`ac lin 1 ${f.toPrecision(17)} ${f.toPrecision(17)}`);lines.push(`write ${WD}/${tag}_p${k}.raw ${zmode?'':'v(No) '}i(V1)`)});
  lines.push('quit','.endc','.end');fs.writeFileSync(`${WD}/${tag}.cir`,lines.join('\n'));
  cp.execFileSync(NGS,['-b',`${WD}/${tag}.cir`],{stdio:'ignore',timeout:120000});
  const parse=file=>{const txt=fs.readFileSync(file,'utf8');const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];const vals=txt.split('Values:')[1].trim().split(/\s+/);const out=[];
    for(let i=0;i<vals.length;){i++;const row=[];for(let v=0;v<nv;v++){const [re,im]=vals[i++].split(',').map(Number);row.push([re,im])}
      out.push(zmode?{f:row[0][0],I:row[1]}:{f:row[0][0],V:row[1],I:row[2]})}return out};
  const sweep=parse(`${WD}/${tag}_sweep.raw`);const pts=freqs.map((f,k)=>parse(`${WD}/${tag}_p${k}.raw`)[0]);return{sweep,pts}}
const abs=z=>Math.hypot(z[0],z[1]);const div=(a,b)=>{const d=b[0]*b[0]+b[1]*b[1];return[(a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d]};
const H_of=(r,zmode)=>zmode?div([1,0],[-r.I[0],-r.I[1]]):r.V;const Z_of=r=>div([1,0],[-r.I[0],-r.I[1]]);
(async()=>{const b=await chromium.launch();const p=await (await b.newContext()).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html')+'',{waitUntil:'domcontentloaded'});await p.waitForTimeout(400);
const sizes=(process.env.SIZES||'3,4,5,6,8,10,12,15,20,25,30').split(',').map(Number);const per=+(process.env.PER||6);
const TB=[];const S={circuits:0,points:0,worstRel:0,worstDb:0,worstPh:0,worstZrel:0,formulas:0,worstFormula:0,chips:0,worstChipRel:0,db3Checked:0,worstDb3:0};const bad=[];let id=0;
for(const E of sizes)for(let k=0;k<per;k++)for(const real of[false,true]){const cir=gen(E);id++;
  const app=await p.evaluate(({cir,real})=>{uid=1;const parts=[],wires=[];const term={};const add=(n,q,e)=>{(term[n]=term[n]||[]).push([q,e])};
    cir.edges.forEach((e,j)=>{const q=mkP(e.k,(j%8)*200,Math.floor(j/8)*200,0,e.v);q.par=Object.assign({},e.par);parts.push(q);add(e.a,q,0);add(e.b,q,1)});
    const vin=mkP('VIN',0,-400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
    for(const k in term){const L=term[k];for(let m=1;m<L.length;m++)wires.push(W_(L[m-1][0],L[m-1][1],L[m][0],L[m][1]))}
    state.parts=parts;state.wires=wires;state.realMode=real;state.fmin=1;state.fmax=1e9;assignNames();NET=netlist();if(!NET.ok)return null;update();
    derive();const hasF=!!DER;window.__DER=DER;
    return{mode:NET.mode,hasF,pts:data.allPoints.map(q=>({f:q.f,type:q.type,label:q.label}))}},{cir,real});
  if(!app)continue;const zm=app.mode==='Z';const ex=expand(cir.edges,real);
  const chipF=app.pts.map(q=>q.f);let sp;try{sp=runSpice(ex,zm,chipF,'c'+id)}catch(e){bad.push(['spice-fail',id,String(e).slice(0,80)]);continue}
  const freqs=sp.sweep.map(r=>r.f).concat(chipF);
  const av=await p.evaluate(fs_=>fs_.map(f=>{const r=resp(f),z=solve(f,'zin');let F=null;if(window.__DER){const w=2*Math.PI*f;F=cx.div(spValJ(__DER.FR.N,w,__DER.vals),spValJ(__DER.FR.D,w,__DER.vals))}return[r,z,F]}),freqs);
  S.circuits++;const refH=sp.sweep.map(r=>H_of(r,zm)).concat(sp.pts.map(r=>H_of(r,zm)));const refZ=sp.sweep.map(Z_of).concat(sp.pts.map(Z_of));
  const mx=Math.max(...refH.map(abs).filter(isFinite)),mxZ=Math.max(...refZ.map(abs).filter(isFinite));
  freqs.forEach((f,i)=>{S.points++;const a=av[i][0],r=refH[i],ar=abs(r);if(!(ar>0)||!isFinite(ar))return;
    const rel=Math.hypot(a[0]-r[0],a[1]-r[1])/Math.max(ar,1e-9*mx);if(rel>S.worstRel)S.worstRel=rel;if(rel>1e-6){const h=hpSolve(ex,f,zm);const ea=Math.hypot(a[0]-h[0],a[1]-h[1])/Math.max(abs(h),1e-9*mx),es=Math.hypot(r[0]-h[0],r[1]-h[1])/Math.max(abs(h),1e-9*mx);TB.push({kind:'H',id,E,real,f,appErr:ea,spiceErr:es})}
    if(ar>mx*1e-10){const dB=Math.abs(20*Math.log10(abs(a)/ar));S.worstDb=Math.max(S.worstDb,dB);let d=Math.atan2(a[1],a[0])-Math.atan2(r[1],r[0]);d=Math.abs(Math.atan2(Math.sin(d),Math.cos(d)))*57.29578;S.worstPh=Math.max(S.worstPh,d)}
    const z=av[i][1],zr=refZ[i];const rz=Math.hypot(z[0]-zr[0],z[1]-zr[1])/Math.max(abs(zr),1e-9*mxZ);if(isFinite(rz)){S.worstZrel=Math.max(S.worstZrel,rz);if(rz>1e-6){const h=hpSolve(ex,f,true);const ea=Math.hypot(z[0]-h[0],z[1]-h[1])/Math.max(abs(h),1e-9*mxZ),es=Math.hypot(zr[0]-h[0],zr[1]-h[1])/Math.max(abs(h),1e-9*mxZ);TB.push({kind:'Z',id,E,real,f,appErr:ea,spiceErr:es})}}
    if(av[i][2]){const F=av[i][2];const rf=Math.hypot(F[0]-r[0],F[1]-r[1])/Math.max(ar,1e-9*mx);S.worstFormula=Math.max(S.worstFormula,rf);if(rf>1e-6){const h=hpSolve(ex,f,zm);const ea=Math.hypot(F[0]-h[0],F[1]-h[1])/Math.max(abs(h),1e-9*mx);TB.push({kind:'F',id,E,real,f,appErr:ea,spiceErr:rf})}}});
  if(app.hasF)S.formulas++;
  // chips: compare to ngspice at exactly those frequencies
  const nS=sp.sweep.length;app.pts.forEach((q,k)=>{S.chips++;const r=refH[nS+k];const a=av[nS+k][0];const rel=Math.hypot(a[0]-r[0],a[1]-r[1])/Math.max(abs(r),1e-9*mx);S.worstChipRel=Math.max(S.worstChipRel,rel);
    if(q.type==='db3'&&!zm){S.db3Checked++;/* reference: max over ngspice dense sweep and all chip points */const lv=20*Math.log10(mx)-10*Math.log10(2);const e=Math.abs(20*Math.log10(abs(r))-lv);S.worstDb3=Math.max(S.worstDb3,e);if(e>0.01)bad.push(['db3',id,E,real,q.f,e])}});
  if(id%10===0)fs.appendFileSync('spicetest.progress',JSON.stringify({id,...S})+'\n')}
console.log(JSON.stringify(S));const sum=k=>{const L=TB.filter(t=>t.kind===k);return k+': disputed points '+L.length+', app worst err vs 72-digit '+(L.length?Math.max(...L.map(t=>t.appErr)).toExponential(1):'-')+', ngspice worst err vs 72-digit '+(L.length?Math.max(...L.map(t=>t.spiceErr)).toExponential(1):'-')+', app closer in '+L.filter(t=>t.appErr<t.spiceErr).length};console.log(sum('H'));console.log(sum('Z'));console.log(sum('F'));fs.writeFileSync('tiebreak.json',JSON.stringify(TB));console.log('problems',bad.length,JSON.stringify(bad.slice(0,20)));console.log('pageerrors',errs);await b.close()})();
