// Time response (step/impulse), poles/zeros and AC curves of the app vs independent references:
//  - ngspice (.ac and .tran with all initial conditions zero), netlist taken from the app's own interpretation of the circuit
//  - pzoracle.py: MNA pencil built independently, generalized eigenvalues by LAPACK QZ
// Circuits: all examples (ideal and real mode), random passive circuits, typical op-amp circuits (otest gen2)
const { chromium } = require('playwright');const fs=require('fs');const cp=require('child_process');
const NGS=process.env.NGSPICE||'ngspice';const WD=fs.mkdtempSync(require('os').tmpdir()+'/td-');
let seed=+(process.env.SEED||4242);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const parOf=k=>k==='C'?{esr:logU(1e-3,1),esl:logU(1e-10,1e-8),rp:rnd()<0.5?1e12:logU(1e5,1e9)}:k==='R'?{ls:logU(1e-10,1e-7),cp:logU(1e-14,1e-11)}:k==='L'?{rdc:logU(1e-2,10),cp:logU(1e-13,1e-10)}
  :k==='P'?{ls:logU(1e-10,1e-6),cp:logU(1e-14,1e-10),rw:logU(1e-2,100)}:{a0:logU(1e3,1e7),gbw:logU(1e5,1e8),rin:logU(1e5,1e12),cin:logU(1e-13,1e-11),lin:logU(1e-10,1e-8),rout:logU(1,500),lout:logU(1e-10,1e-7),cout:logU(1e-14,1e-11)};
const val=k=>k==='R'?logU(10,1e5):k==='L'?logU(1e-6,1e-1):k==='C'?logU(1e-11,1e-5):logU(100,1e6);
function genP(E){const zmode=rnd()<0.2;const nInt=Math.max(0,Math.round(E*0.5)-(zmode?2:3));const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:nInt},(_,j)=>'n'+j)];
  const order=nodes.slice().sort(()=>rnd()-0.5);const els=[];const add=(a,b,k)=>els.push({k,a,b,v:val(k),par:parOf(k)});
  for(let j=1;j<order.length;j++)add(order[j],pick(order.slice(0,j)),pick(['R','L','C']));while(els.length<E){const a=pick(nodes),b=pick(nodes);if(a!==b)add(a,b,pick(['R','L','C']))}
  return{zmode,els,oas:[],realMode:rnd()<0.5}}
const src=fs.readFileSync(__dirname+'/otest.js','utf8');eval(src.slice(src.indexOf('function gen2'),src.indexOf('function expand')).replace('function gen2','global.gen2=function'));
const NPAS=+(process.env.NPAS||40),NACT=+(process.env.NACT||60),NSEMI=+(process.env.NSEMI||0);
/* SEMI: transistor/diode circuits from stest.js (QREAL=1 gives real BJT/MOSFET parameters), linearized by the app */
if(NSEMI){const s2=fs.readFileSync(__dirname+'/stest.js','utf8');eval(s2.slice(s2.indexOf('const QR='),s2.indexOf('function spice(')).replace('const QR=','global.QR=').replace(/\nconst (qsc|msc|dsc)=/g,'\nglobal.$1=').replace('function gen()','global.genS=function()'))}
const abs=z=>Math.hypot(z[0],z[1]);const div=(a,b)=>{const q=b[0]*b[0]+b[1]*b[1];return[(a[0]*b[0]+a[1]*b[1])/q,(a[1]*b[0]-a[0]*b[1])/q]};
function spice(a,tag){const nn=x=>x===a.gnd?'0':'N'+x;const zm=a.mode==='Z';
  const L=['* '+tag,`V1 N${a.vin} 0 DC 0 AC 1 PULSE(0 1 0 ${(a.T*1e-9).toPrecision(6)} 1 1e9 2e9)`];
  a.edges.forEach((e,j)=>L.push(`${e.k}${j+1} ${nn(e.a)} ${nn(e.b)} ${e.v.toPrecision(17)}`));
  a.ctrl.forEach((c,j)=>{if(c.t==='nullor')L.push(`E${j+1} ${nn(c.o)} 0 ${nn(c.p)} ${nn(c.n)} 1e9`);else L.push(`G${j+1} 0 QQ${j} ${nn(c.p)} ${nn(c.n)} ${c.A0.toPrecision(17)}`,`RX${j} QQ${j} 0 1`,`CX${j} QQ${j} 0 ${(1/c.wp).toPrecision(17)}`,`EB${j+1} ${nn(c.o)} 0 QQ${j} 0 1`)});(a.vccs||[]).forEach((v,j)=>{if(v.cap)/* transcapacitance s·C·(Va−Vb): copy Va−Vb to an extra node, |C| from it through a 0 V sense source, F source mirrors the current */L.push(`EC${j+1} XC${j} 0 ${nn(v.a)} ${nn(v.b)} 1`,`CC${j+1} XC${j} YC${j} ${Math.abs(v.G).toPrecision(17)}`,`VC${j+1} YC${j} 0 0`,`FC${j+1} ${nn(v.p)} ${nn(v.n)} VC${j+1} ${Math.sign(v.G)}`);else L.push(`GM${j+1} ${nn(v.p)} ${nn(v.n)} ${nn(v.a)} ${nn(v.b)} ${v.G.toPrecision(17)}`)});(a.xf||[]).forEach((x,j)=>L.push(`VXS${j} ${nn(x.p1)} XA${j} 0`,`EXS${j} XA${j} ${nn(x.n1)} ${nn(x.p2)} ${nn(x.n2)} ${x.n.toPrecision(17)}`,`FXS${j} ${nn(x.n2)} ${nn(x.p2)} VXS${j} ${x.n.toPrecision(17)}`));
  const out=zm?'i(V1)':`v(${nn(a.vout)}) i(V1)`;
  L.push('.options reltol=1e-7 abstol=1e-18 vntol=1e-12 chgtol=1e-20 trtol=1 method=gear maxord=2 itl4=200','.control','option noopac','set filetype=ascii',
    `ac dec 25 ${a.fmin} ${a.fmax}`,`write ${WD}/${tag}_ac.raw ${out}`,
    `tran ${(a.T/4000).toPrecision(8)} ${a.T.toPrecision(10)} 0 ${(a.T/16000).toPrecision(8)} uic`,'linearize',`write ${WD}/${tag}_tr.raw ${out}`,'quit','.endc','.end');
  fs.writeFileSync(`${WD}/${tag}.cir`,L.join('\n'));cp.execFileSync(NGS,['-b',`${WD}/${tag}.cir`],{stdio:'ignore',timeout:300000});
  const parse=(file,cplx)=>{const txt=fs.readFileSync(file,'utf8');const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];const vals=txt.split('Values:')[1].trim().split(/\s+/);const rows=[];
    for(let i=0;i<vals.length;){i++;const r=[];for(let v=0;v<nv;v++){const s=vals[i++];r.push(cplx?s.split(',').map(Number):+s.split(',')[0])}rows.push(r)}return rows};
  const ac=parse(`${WD}/${tag}_ac.raw`,true).map(r=>({f:r[0][0],H:zm?div([1,0],[-r[1][0],-r[1][1]]):r[1],Z:div([1,0],[-r[zm?1:2][0],-r[zm?1:2][1]])}));
  const tr=parse(`${WD}/${tag}_tr.raw`,false).map(r=>({t:r[0],y:zm?-r[1]:r[1]}));return{ac,tr}}
function interp(tr,t){let lo=0,hi=tr.length-1;if(t<=tr[0].t)return tr[0].y;if(t>=tr[hi].t)return tr[hi].y;while(hi-lo>1){const m=(lo+hi)>>1;if(tr[m].t<=t)lo=m;else hi=m}const a=tr[lo],b=tr[hi];return a.y+(b.y-a.y)*(t-a.t)/(b.t-a.t)}
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(500);
const keys=await p.evaluate(()=>Object.keys(EXAMPLES).filter(k=>!k.startsWith('o_')));const jobs=[];
if(!process.env.NOEX)for(const real of[false,true])for(const k of keys)jobs.push({ex:k,real,name:k+(real?' (real)':'')});
for(let i=0;i<NPAS;i++){const c=genP(3+Math.floor(rnd()*10));jobs.push({cir:c,name:'pas'+i+(c.realMode?'R':'')})}
for(let i=0;i<NACT;i++){const c=gen2();jobs.push({cir:c,name:'act'+i+'/t'+c.typ+(c.realMode?'R':'')})}
for(let i=0;i<NSEMI;i++){const c=genS();if(process.env.RM)c.real=process.env.RM==='1';jobs.push({semi:c,name:'semi'+i+'/t'+c.typ+(c.real?'R':'')})}
const rows=[];const forPZ=[];
for(const [ji,J] of jobs.entries()){
  const a=await p.evaluate(J=>{
    if(J.semi){const C=J.semi;uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240+80];j++;return q};
      for(const e of C.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.real=false;parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      for(const e of C.vdc){const[x,y]=pos();const q=mkP('VDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      for(const e of C.idc){const[x,y]=pos();const q=mkP('IDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      C.xf.forEach(e=>{const[x,y]=pos();const q=mkP('T',x,y,0,e.n);q.par=Object.assign({},e.par);parts.push(q);add(e.p1,q,0);add(e.n1,q,1);add(e.p2,q,2);add(e.n2,q,3)});
      C.devs.forEach(d=>{const[x,y]=pos();const q=mkP(d.k,x,y,0);q.sc=Object.assign({},d.sc);if(d.k!=='D'){q.pol=d.pol;q.real=true}else{q.dt=d.sc.dt;delete q.sc.dt}parts.push(q);
        if(d.k==='D'){add(d.a,q,0);add(d.b,q,1)}else if(d.k==='Q'){add(d.b,q,0);add(d.c,q,1);add(d.e,q,2)}else{add(d.g,q,0);add(d.d,q,1);add(d.s,q,2)}});
      const vin=mkP('VIN',0,-400);vin.dc=C.vindc;vin.idc=C.vinI||0;parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!C.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
      for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
      state.parts=parts;state.wires=wires;state.realMode=!!C.real;state.std=false;state.tzoom=1;state.fmin=1;state.fmax=1e9;assignNames();NET=netlist();if(!NET.ok)return{err:NET.err};update()}
    else if(J.ex){const b=document.createElement('button');b.dataset.ex=J.ex;document.getElementById('exList').appendChild(b);b.click();b.remove();closeAll();state.realMode=J.real;state.std=false;state.tzoom=1;circuitChanged()}
    else{const cir=J.cir;uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240];j++;return q};
      for(const e of cir.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.par=Object.assign({},e.par);if(e.k==='P'){q.pos=e.pos;add(e.w,q,2)}parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      for(const u of cir.oas){const[x,y]=pos();const q=mkP('OA',x,y,0);q.par=Object.assign({},u.par);q.real=u.real;parts.push(q);add(u.p,q,0);add(u.n,q,1);add(u.o,q,2)}
      const vin=mkP('VIN',0,-400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
      for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
      state.parts=parts;state.wires=wires;state.realMode=cir.realMode;state.std=false;state.tzoom=1;state.fmin=1;state.fmax=1e9;assignNames();NET=netlist();if(!NET.ok)return{err:NET.err};update()}
    if(!NET.ok||!data)return{err:NET.err||'nodata'};
    const pz=getPZ();const td=timeData();
    const N=NET;return{mode:N.mode,vin:N.vin,gnd:N.gnd,vout:N.vout,fmin:state.fmin,fmax:state.fmax,
      edges:N.edges.map(e=>({a:e.a,b:e.b,k:e.el.kind,v:e.el.val})),ctrl:(N.ctrl||[]).map(c=>c.t==='nullor'?{t:c.t,p:c.p,n:c.n,o:c.o}:{t:c.t,p:c.p,n:c.n,o:c.o,A0:c.A.val,wp:c.W.val}),xf:(N.xf||[]).map(x=>({p1:x.p1,n1:x.n1,p2:x.p2,n2:x.n2,n:x.N.val})),vccs:(N.vccs||[]).map(v=>({p:v.p,n:v.n,a:v.a,b:v.b,G:v.G.val,cap:!!v.cap})),
      pz,rmWhy:RM_WHY,td:td?{T:td.T,h:td.h,ys:Array.from(td.ys),imp:Array.from(td.imp),yinf:td.yinf,jump:td.jump,y0:td.y0,m:td.m,tskip:td.tskip,exact:td.exact,unstable:td.unstable,integ:td.integ,y00:td.an&&!td.tskip?td.an.y0:null}:null}},J);
  if(a.err){rows.push({name:J.name,err:a.err});continue}
  if(process.env.DUMPDIR)fs.writeFileSync(process.env.DUMPDIR+'/'+J.name.replace(/[^A-Za-z0-9]/g,'_')+'.json',JSON.stringify(a));
  const T=a.td?a.td.T:1/(a.fmin*10);a.T=T;let sp;
  try{sp=spice(a,'j'+ji)}catch(e){rows.push({name:J.name,err:'spice '+String(e).slice(0,60)});continue}
  /* AC */
  const fsq=sp.ac.map(r=>r.f);const av=await p.evaluate(fs_=>fs_.map(f=>[resp(f),solve(f,'zin')]),fsq);
  const mx=Math.max(...sp.ac.map(r=>abs(r.H)).filter(isFinite)),mz=Math.max(...sp.ac.map(r=>abs(r.Z)).filter(isFinite));let eH=0,eZ=0,fH=0;
  sp.ac.forEach((r,i)=>{if(isFinite(abs(r.H))){const e=abs([av[i][0][0]-r.H[0],av[i][0][1]-r.H[1]])/Math.max(abs(r.H),1e-6*mx);if(e>eH){eH=e;fH=r.f}}if(isFinite(abs(r.Z))&&abs(r.Z)<1e15){eZ=Math.max(eZ,abs([av[i][1][0]-r.Z[0],av[i][1][1]-r.Z[1]])/Math.max(abs(r.Z),1e-6*mz))}});
  /* time */
  let eS=null,eI=null,met=null,mApp=null,R_dbg=null;
  if(a.td&&!a.td.unstable){const td=a.td,n=td.ys.length,h=td.h;const ref=[];for(let k=0;k<n;k++)ref.push(k?interp(sp.tr,k*h):0);
    let my=0;for(let k=1;k<n;k++)my=Math.max(my,Math.abs(ref[k]));eS=0;for(let k=1;k<n;k++)eS=Math.max(eS,Math.abs(td.ys[k]-ref[k])/Math.max(my,1e-300));
    /* impulse: derivative of the ngspice step on a fine grid */
    const hf=T/16000;let mi=0;const ir=[];for(let k=1;k<n;k++){const t=k*h;if(t<3*hf||t>T-3*hf){ir.push(null);continue}const d=(interp(sp.tr,t+hf)-interp(sp.tr,t-hf))/(2*hf);ir.push(d);mi=Math.max(mi,Math.abs(d))}
    eI=0;for(let k=1;k<n;k++){const r=ir[k-1];if(r==null||k*h<T*0.005)continue;eI=Math.max(eI,Math.abs(td.imp[k]-r)/Math.max(mi,1e-300))}
    R_dbg={ys:td.ys.filter((_,k)=>k%100===0),ref:ref.filter((_,k)=>k%100===0),imp:td.imp.filter((_,k)=>k%100===0),ir:[null].concat(ir).filter((_,k)=>k%100===0)};met=await p.evaluate(({ys,h,yinf,sk,y00})=>stepMetrics({ys:Float64Array.from(ys),h},yinf,sk,y00),{ys:ref,h,yinf:td.yinf,sk:td.tskip,y00:td.y00});mApp=td.m}
  forPZ.push({i:rows.length,td:a.td&&!a.td.unstable?{T:a.td.T,ys:a.td.ys,imp:a.td.imp,yinf:a.td.yinf,jump:a.td.jump,tskip:a.td.tskip,y00:a.td.y00}:null,c:{edges:a.edges,ctrl:a.ctrl,vccs:a.vccs||[],xf:a.xf||[],vin:a.vin,gnd:a.gnd,vout:a.vout,mode:a.mode,s0:2*Math.PI*Math.sqrt(a.fmin*a.fmax)},app:a.pz,wmax:2*Math.PI*a.fmax});
  rows.push({name:J.name,rmWhy:a.rmWhy,mode:a.mode,nEl:a.edges.length,eH,fH,eZ,eSn:eS,eIn:eI,exact:a.td&&a.td.exact,unstable:a.td&&a.td.unstable,integ:a.td&&a.td.integ,met,mApp,T,dbg:R_dbg});
  if(ji%10===0)process.stderr.write(ji+'/'+jobs.length+'\n')}
/* poles/zeros vs QZ oracle */
const orc=JSON.parse(cp.execFileSync('python3',[__dirname+'/pzoracle.py'],{input:JSON.stringify(forPZ.map(x=>x.c)),maxBuffer:1e8}).toString());
const cancel=(P,Z)=>{const used=new Set();const Pk=[];for(const q of P){const m=abs(q);let hit=-1;Z.forEach((z,j)=>{if(hit<0&&!used.has(j)&&Math.hypot(z[0]-q[0],z[1]-q[1])<=1e-6*Math.max(m,1e-30))hit=j});if(hit>=0)used.add(hit);else Pk.push(q)}return[Pk,Z.filter((_,j)=>!used.has(j))]};
forPZ.forEach((x,k)=>{const R=rows[x.i];R.c=x.c;const o=orc[k];if(!x.app){R.pz='APP-NONE';R.oP=o.P;R.oZ=o.Z;return}const big=2*Math.PI*1e15;
  let[P,Z]=cancel(o.P.filter(q=>abs(q)<big),o.Z.filter(q=>abs(q)<big));const lim=100*x.wmax,sg=x.c.s0;
  const cmp=(ref,app)=>{let worst=0,miss=[],extra=[];const used=new Set();
    for(const q of ref){if(abs(q)>lim)continue;let bi=-1,bd=Infinity;app.forEach((z,j)=>{if(used.has(j))return;const d=Math.hypot(z[0]-q[0],z[1]-q[1])/Math.max(abs(q),1e-9*sg);if(d<bd){bd=d;bi=j}});
      if(bi>=0&&bd<1e-3){used.add(bi);worst=Math.max(worst,bd)}else miss.push(q)}
    app.forEach((z,j)=>{if(!used.has(j)&&abs(z)<=lim){/* is it in the reference at all (beyond the window)? */const near=ref.some(q=>Math.hypot(z[0]-q[0],z[1]-q[1])<1e-3*Math.max(abs(q),1e-9*sg));if(!near)extra.push(z)}});return{worst,miss,extra}};
  R.oP=P;R.oZ=Z;R.aP=x.app.poles;R.aZ=x.app.zeros;R.pzP=cmp(P,x.app.poles);R.pzZ=cmp(Z,x.app.zeros)});
/* step response vs Radau IIA reference */
{const jobs2=forPZ.filter(x=>x.td).map(x=>({c:x.c,T:x.td.T,n:x.td.ys.length-1,m:+(process.env.RADM||30)}));
 const ref=JSON.parse(cp.execFileSync('python3',[__dirname+'/tref.py'],{input:JSON.stringify(jobs2),maxBuffer:1e9}).toString());let q=0;
 for(const x of forPZ){if(!x.td)continue;const r=ref[q++];const R=rows[x.i];const n=x.td.ys.length;let my=0,mi=0;for(let k=1;k<n;k++){my=Math.max(my,Math.abs(r.y[k]));if(r.dy[k]!=null)mi=Math.max(mi,Math.abs(r.dy[k]))}
   let eS=0,kS=0,eI=0,kI=0;let e0=0;for(let k=1;k<n;k++){const e=Math.abs(x.td.ys[k]-r.y[k])/Math.max(my,1e-300);if(k<4){e0=Math.max(e0,e);continue}if(e>eS){eS=e;kS=k}if(r.dy[k]!=null&&k>n*0.003){const ei=Math.abs(x.td.imp[k]-r.dy[k])/Math.max(mi,1e-300);if(ei>eI){eI=ei;kI=k}}}
   R.eS=eS;R.kS=kS;R.e0=e0;R.met=await p.evaluate(({ys,h,yinf,sk,y00})=>stepMetrics({ys:Float64Array.from(ys),h},yinf,sk,y00),{ys:r.y,h:x.td.T/(n-1),yinf:x.td.yinf,sk:x.td.tskip,y00:x.td.y00});R.eI=eI;R.kI=kI;R.refEnd=r.y[n-1];R.refDbg={y:r.y.filter((_,k)=>k%100===0),dy:r.dy.filter((_,k)=>k%100===0)}}}
fs.writeFileSync(__dirname+'/tdtest.json',JSON.stringify(rows));
const f=v=>v==null?'-':v.toExponential(1);
for(const r of rows){if(r.err){console.log(r.name,'ERR',r.err);continue}
  const pzs=r.pz||(r.pzP?`P ${f(r.pzP.worst)}${r.pzP.miss.length?' MISS'+r.pzP.miss.length:''}${r.pzP.extra.length?' EXTRA'+r.pzP.extra.length:''} Z ${f(r.pzZ.worst)}${r.pzZ.miss.length?' MISS'+r.pzZ.miss.length:''}${r.pzZ.extra.length?' EXTRA'+r.pzZ.extra.length:''}`:'');
  const md=r.met&&r.mApp?['over','tr','ts','tau'].map(k=>{const a=r.mApp[k],b=r.met[k];if(a==null&&b==null)return'';if(a==null||b==null)return k+':'+a+'≠'+b;const e=Math.abs(a-b)/Math.max(Math.abs(b),k==='over'?1:r.T*1e-3);return e>2e-3?k+':'+a.toPrecision(4)+'/'+b.toPrecision(4):''}).filter(Boolean).join(' '):'';
  console.log([r.name,r.mode,r.nEl,'H '+f(r.eH),'Z '+f(r.eZ),'step '+f(r.eS)+'@'+r.kS+' (t0 '+f(r.e0)+')','imp '+f(r.eI),'(ngspice '+f(r.eSn)+'/'+f(r.eIn)+')',r.exact?'exact':'sim',r.unstable?'UNSTABLE':'',r.integ?'integ':'',pzs,md].join(' | '))}
console.log('pageerrors',errs.slice(0,5));await b.close()})();
