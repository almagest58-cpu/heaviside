/* NODE-ONLY */if(typeof module!=='undefined'&&typeof evalDiode==='undefined'){var _S=require('./semi.js');var evalDiode=_S.evalDiode,evalBJT=_S.evalBJT,evalMOS=_S.evalMOS,VT=_S.VT,GMIN=_S.GMIN,pnjlim=_S.pnjlim,fetlim=_S.fetlim,diodeBrk=_S.diodeBrk}/* END-NODE-ONLY */
/* ================= time-domain (transient) simulator =================
   Large-signal simulation step by step in time, like SPICE .tran: every element with its full nonlinear model (diode with breakdown,
   depletion and diffusion charge; BJT Gummel–Poon subset; MOSFET level 1), op-amps with output limited to the supply rails,
   ideal transformers, inductors, capacitors and signal generators (DC, sine, square, triangle, sawtooth, pulse).
   Method: modified nodal analysis; variable-step BDF (backward Euler on the first step after a corner of a source waveform,
   then 2nd-order BDF / Gear), local truncation error control, Newton–Raphson with SPICE voltage limiting in every step.
   Initial state: DC operating point at t = 0 (capacitors open, inductors shorted). */

/* ---- signal generator waveforms. w = {type, amp, f, off, ph (deg), duty (0…1), tr (edge time, s)} ----
   sine: off + amp·sin(2πft + ph); square: off ± amp (high for duty·T, edges of length tr); triangle: off + amp·tri (starts at off,
   rising, like the sine); sawtooth: rises from off − amp to off + amp, falls back in tr; pulse: off (low) → off + amp (high) for duty·T;
   dc: amp */
function trEdge(w){const T=1/w.f,tr=Math.max(w.tr||0,0);if(w.type==='saw')return Math.min(Math.max(tr/T,1e-9),0.5);
  const d=trDuty(w);return Math.min(Math.max(tr/T,1e-9),0.5*Math.min(d,1-d))}
function trDuty(w){return Math.min(0.99,Math.max(0.01,w.duty==null?0.5:w.duty))}
function trWave(w,t){const A=+w.amp||0;if(w.type==='dc')return A;const off=+w.off||0;let u=t*w.f+(w.ph||0)/360;u-=Math.floor(u);
  switch(w.type){
    case'sin':return off+A*Math.sin(2*Math.PI*u);
    case'tri':return off+A*(u<0.25?4*u:u<0.75?2-4*u:4*u-4);
    case'saw':{const e=trEdge(w);return off+A*(u<1-e?-1+2*u/(1-e):1-2*(u-(1-e))/e)}
    case'sq':case'pul':{const e=trEdge(w),d=trDuty(w);const s=u<e?u/e:u<d?1:u<d+e?1-(u-d)/e:0;/* 0…1 */
      return w.type==='sq'?off+A*(2*s-1):off+A*s}}
  return 0}
/* corners of the waveform (fractions of the period) */
function trCorners(w){if(w.type==='sq'||w.type==='pul'){const e=trEdge(w),d=trDuty(w);return[0,e,d,d+e]}if(w.type==='tri')return[0.25,0.75];if(w.type==='saw'){const e=trEdge(w);return[1-e,1]}return[]}
/* first corner strictly after t (Infinity if none) */
function trNextBreak(w,t){const L=trCorners(w);if(!L.length||!(w.f>0))return Infinity;const p=(w.ph||0)/360;const base=t*w.f+p;const k0=Math.floor(base);let best=Infinity;
  const eps=Math.max(Math.abs(t),1e-30)*1e-11+1e-18;
  for(let k=k0-1;k<=k0+1;k++)for(const uB of L){const tb=(k+uB-p)/w.f;if(tb>t+eps&&tb<best)best=tb}return best}

/* ---- the circuit ----
   C = {n (nodes 0…n−1, ground = −1), R:[{a,b,g}], C:[{a,b,c}], L:[{a,b,l}], V:[{a,b,w}] (voltage w(t) from a (+) to b (−)),
        I:[{a,b,w}] (current w(t) flows from a through the source to b), xf:[{p1,n1,p2,n2,n}] (ideal transformer n:1),
        oa:[{p,n,o,a0,wp,vp,vn}] (op-amp: (1/ωp)·dy/dt = A0·(V+ − V−) − y, output V_o = y limited to the rails vn…vp),
        dev:[{t:'D',a,k,par:{is,n,xbv,cj,vj,m,tt}}|{t:'Q',b,c,e,pol,par,cbe,cbc,qr}|{t:'M',g,d,s,pol,par,cgs,cgd,qgd}]}
   real BJT: qr = {cje,vje,mje,cjc,vjc,mjc,tf,tr}: charges Q_BE = Q_je(V_BE) + τ_F·I_CC/q_b, Q_BC = Q_jc(V_BC) + τ_R·I_BC (SPICE);
   real MOSFET: qgd = {c0,vj,m}: Q_GD(V_GD): depletion-type below 0, C_gd0·V_GD above (trQgd); constant C_gs and C_gd as given
   unknowns: node voltages, then currents of V sources, inductors and transformers, then op-amp output currents and states */
const TR_KNEE=0.01;/* op-amp output: knee (V) where the output bends into the rail */
function trOaS(y,o){const w=Math.min(TR_KNEE,0.25*(o.vp-o.vn));
  if(y>o.vp-w){if(y>=o.vp+w)return[o.vp,0];const d=y-o.vp+w;return[y-d*d/(4*w),1-d/(2*w)]}
  if(y<o.vn+w){if(y<=o.vn-w)return[o.vn,0];const d=o.vn+w-y;return[y+d*d/(4*w),1-d/(2*w)]}return[y,1]}
/* anti-windup: the internal state y is pushed back once it passes the rail by more than the knee */
const TR_KP=10;
function trOaPsi(y,o){const w=Math.min(TR_KNEE,0.25*(o.vp-o.vn));const hi=o.vp+w,lo=o.vn-w;if(y>hi){const d=y-hi;return[d*d,2*d]}if(y<lo){const d=lo-y;return[-d*d,2*d]}return[0,0]}
/* diode depletion charge (SPICE, FC = 0.5) and capacitance */
function trQj(v,c0,vj,m){if(!(c0>0))return[0,0];vj=Math.min(Math.max(vj,0.05),2);m=Math.min(m,0.9);const fc=0.5,dep=fc*vj;
  if(v<dep){const a=1-v/vj,s=Math.exp(-m*Math.log(a));return[vj*c0*(1-a*s)/(1-m),c0*s]}
  const f1=vj*(1-Math.pow(1-fc,1-m))/(1-m),f2=Math.pow(1-fc,1+m),f3=1-fc*(1+m),cz=c0/f2;
  return[c0*f1+cz*(f3*(v-dep)+(m/(2*vj))*(v*v-dep*dep)),cz*(f3+m*v/vj)]}
/* MOSFET gate–drain charge (real model): depletion-type for V_GD < 0 (drain above the gate), constant C_gd0 for V_GD ≥ 0, where the
   gate–drain overlap is accumulated and its capacitance stays at its maximum (continuous capacitance, smooth charge) */
function trQgd(v,c0,vj,m){if(!(c0>0))return[0,0];if(v>=0)return[c0*v,c0];return trQj(v,c0,vj,m)}
function trLimvds(vnew,vold){if(vold>=3.5){if(vnew>vold)vnew=Math.min(vnew,3*vold+2);else if(vnew<3.5)vnew=Math.max(vnew,2)}else{if(vnew>vold)vnew=Math.min(vnew,4);else vnew=Math.max(vnew,-0.5)}return vnew}

function trCreate(C,opts){opts=opts||{};
  for(const k of['R','C','L','V','I','xf','oa','dev'])C[k]=C[k]||[];
  const n=C.n,nV=C.V.length,nL=C.L.length,nX=C.xf.length,nO=C.oa.length;
  const iV=n,iL=iV+nV,iX=iL+nL,iO=iX+nX,iY=iO+nO,N=iY+nO;
  /* linear capacitors, including the constant device capacitances */
  const caps=C.C.filter(c=>c.c>0&&c.a!==c.b).slice();
  for(const d of C.dev){if(d.t==='Q'){if(d.cbe>0)caps.push({a:d.b,b:d.e,c:d.cbe});if(d.cbc>0)caps.push({a:d.b,b:d.c,c:d.cbc})}
    else if(d.t==='M'){if(d.cgs>0)caps.push({a:d.g,b:d.s,c:d.cgs});if(d.cgd>0)caps.push({a:d.g,b:d.d,c:d.cgd})}}
  /* nonlinear device charges: diode (1), real BJT (B–E and B–C), real MOSFET (G–D); dqi[j] = first charge of device j */
  const dq=[],dqi=new Int32Array(C.dev.length).fill(-1);
  C.dev.forEach((d,j)=>{if(d.t==='D'&&((d.par.cj>0)||(d.par.tt>0))){dqi[j]=dq.length;dq.push({sc:(d.par.cj||0),tt:d.par.tt||0})}
    else if(d.t==='Q'&&d.qr){dqi[j]=dq.length;dq.push({sc:d.qr.cje||0,tt:d.qr.tf||0},{sc:d.qr.cjc||0,tt:d.qr.tr||0})}
    else if(d.t==='M'&&d.qgd&&d.qgd.c0>0){dqi[j]=dq.length;dq.push({sc:d.qgd.c0,tt:0})}});
  /* dynamic quantities (charges/fluxes): caps, inductors, diode charges, op-amp states */
  const qC0=0,qL0=caps.length,qD0=qL0+nL,qO0=qD0+dq.length,NQ=qO0+nO;
  /* device state for limiting */
  const st=C.dev.map(d=>d.t==='D'?{v:0}:d.t==='Q'?{vbe:0,vbc:0}:{vgs:0,vds:0});
  const J=new Float64Array(N*N),F=new Float64Array(N),qNow=new Float64Array(NQ),hist=new Float64Array(NQ);
  /* nodes without a DC path to ground (e.g. between two capacitors) get a tiny conductance at DC only */
  const flSet=(()=>{const par=Array.from({length:n+1},(_,i)=>i);const f=i=>{i=i<0?n:i;while(par[i]!==i){par[i]=par[par[i]];i=par[i]}return i};const u=(a,b)=>{par[f(a)]=f(b)};
    for(const e of C.R)u(e.a,e.b);for(const e of C.V)u(e.a,e.b);for(const e of C.L)u(e.a,e.b);for(const e of C.xf){u(e.p1,e.n1);u(e.p2,e.n2)}for(const o of C.oa)u(o.o,-1);
    for(const d of C.dev){if(d.t==='D')u(d.a,d.k);else if(d.t==='Q'){u(d.b,d.e);u(d.c,d.e)}else u(d.d,d.s)}
    const g=f(-1),s=new Set();for(let i=0;i<n;i++)if(f(i)!==g)s.add(i);return s})();
  const V=(x,i)=>i<0?0:x[i];
  /* assemble the Newton system at x. ctx: {dc, t, a0, gsh, sc (source scale)} */
  function assemble(x,ctx,lim){J.fill(0);F.fill(0);let limited=false;
    const aj=(r,c,v)=>{if(r>=0&&c>=0)J[r*N+c]+=v};const af=(r,v)=>{if(r>=0)F[r]+=v};const dc=ctx.dc,a0=ctx.a0||0,t=ctx.t,sc=ctx.sc==null?1:ctx.sc;
    for(const e of C.R){const i=e.g*(V(x,e.a)-V(x,e.b));af(e.a,i);af(e.b,-i);aj(e.a,e.a,e.g);aj(e.b,e.b,e.g);aj(e.a,e.b,-e.g);aj(e.b,e.a,-e.g)}
    if(ctx.gsh)for(let i=0;i<n;i++){J[i*N+i]+=ctx.gsh;F[i]+=ctx.gsh*x[i]}
    /* nodes without any DC path to ground (between capacitors, or a part connected to nothing) keep a tiny conductance, also in time */
    for(const i of flSet){J[i*N+i]+=1e-12;F[i]+=1e-12*x[i]}
    if(ctx.pg){const g=ctx.pg,xp=ctx.pgx;for(let i=0;i<n;i++){J[i*N+i]+=g;F[i]+=g*(x[i]-xp[i])}}
    if(ctx.ptc){const g=ctx.ptc.c*a0,xp=ctx.ptc.xp;for(let i=0;i<n;i++){J[i*N+i]+=g;F[i]+=g*(x[i]-xp[i])}}
    const W=e=>ctx.genOff&&e.gen?0:trWave(e.w,t);for(const e of C.I){const v=sc*W(e);af(e.a,v);af(e.b,-v)}
    C.V.forEach((e,j)=>{const k=iV+j,I=x[k];af(e.a,I);af(e.b,-I);aj(e.a,k,1);aj(e.b,k,-1);F[k]=V(x,e.a)-V(x,e.b)-sc*W(e);aj(k,e.a,1);aj(k,e.b,-1)});
    C.L.forEach((e,j)=>{const k=iL+j,I=x[k];af(e.a,I);af(e.b,-I);aj(e.a,k,1);aj(e.b,k,-1);F[k]=V(x,e.a)-V(x,e.b);aj(k,e.a,1);aj(k,e.b,-1);
      const q=e.l*I;qNow[qL0+j]=q;if(!dc){F[k]-=a0*q+hist[qL0+j];J[k*N+k]-=a0*e.l}});
    C.xf.forEach((e,j)=>{const k=iX+j,I=x[k],r=e.n;af(e.p1,I);af(e.n1,-I);af(e.p2,-r*I);af(e.n2,r*I);aj(e.p1,k,1);aj(e.n1,k,-1);aj(e.p2,k,-r);aj(e.n2,k,r);
      F[k]=V(x,e.p1)-V(x,e.n1)-r*(V(x,e.p2)-V(x,e.n2));aj(k,e.p1,1);aj(k,e.n1,-1);aj(k,e.p2,-r);aj(k,e.n2,r)});
    caps.forEach((e,j)=>{const q=e.c*(V(x,e.a)-V(x,e.b));qNow[qC0+j]=q;if(dc)return;const i=a0*q+hist[qC0+j],g=a0*e.c;af(e.a,i);af(e.b,-i);aj(e.a,e.a,g);aj(e.b,e.b,g);aj(e.a,e.b,-g);aj(e.b,e.a,-g)});
    C.oa.forEach((o,j)=>{const ko=iO+j,ky=iY+j,Io=x[ko],y=x[ky];af(o.o,Io);aj(o.o,ko,1);const[s,ds]=trOaS(y,o);F[ko]=V(x,o.o)-s;aj(ko,o.o,1);J[ko*N+ky]-=ds;
      /* state row, scaled by 1/A0: (1/(ωp·A0))·dy/dt − (V+ − V−) + y/A0 + Kp·ψ(y) = 0 */
      const[ps,dps]=trOaPsi(y,o);const q=y/(o.wp*o.a0);qNow[qO0+j]=q;F[ky]=-(V(x,o.p)-V(x,o.n))+y/o.a0+TR_KP*ps;aj(ky,o.p,-1);aj(ky,o.n,1);J[ky*N+ky]+=1/o.a0+TR_KP*dps;
      if(!dc){F[ky]+=a0*q+hist[qO0+j];J[ky*N+ky]+=a0/(o.wp*o.a0)}});
    C.dev.forEach((d,j)=>{const s=st[j];const jq=dqi[j]-0;
      if(d.t==='D'){const vx=V(x,d.a)-V(x,d.k);let v=vx;
        if(ctx.initj){const p=d.par,nvt=(p.n||1)*VT;v=nvt*Math.log(nvt/(Math.SQRT2*p.is));limited=true}
        else if(lim){const p=d.par,nvt=(p.n||1)*VT,vc=nvt*Math.log(nvt/(Math.SQRT2*p.is));const xb=p.xbv;let v2;
          if(xb>0&&v<Math.min(0,-xb+10*nvt)){v2=-(pnjlim(-(v+xb),-(s.v+xb),nvt,vc)+xb)}else v2=pnjlim(v,s.v,nvt,vc);if(v2!==v)limited=true;v=v2}
        s.v=v;const r=evalDiode(v,d.par);const i=r.i+r.g*(vx-v);af(d.a,i);af(d.k,-i);aj(d.a,d.a,r.g);aj(d.k,d.k,r.g);aj(d.a,d.k,-r.g);aj(d.k,d.a,-r.g);
        if(d.par.cj>0||d.par.tt>0){const p=d.par;const[qj,cj]=trQj(v,p.cj,p.vj,p.m);const tt=p.tt||0;const q=qj+tt*(r.i-GMIN*v),c=cj+tt*(r.g-GMIN);const qi=q+c*(vx-v);
          qNow[qD0+jq]=qi;if(!dc){const ii=a0*qi+hist[qD0+jq],g=a0*c;af(d.a,ii);af(d.k,-ii);aj(d.a,d.a,g);aj(d.k,d.k,g);aj(d.a,d.k,-g);aj(d.k,d.a,-g)}}}
      else if(d.t==='Q'){const vbx=V(x,d.b)-V(x,d.e),vcx=V(x,d.b)-V(x,d.c);let vbe=vbx,vbc=vcx;
        if(ctx.initj){vbe=d.pol*VT*Math.log(VT/(Math.SQRT2*d.par.is));vbc=0;limited=true}
        else if(lim){const vc=VT*Math.log(VT/(Math.SQRT2*d.par.is));const p=d.pol;const e1=p*pnjlim(p*vbe,p*s.vbe,VT,vc),c1=p*pnjlim(p*vbc,p*s.vbc,VT,vc);if(e1!==vbe||c1!==vbc)limited=true;vbe=e1;vbc=c1}
        s.vbe=vbe;s.vbc=vbc;const r=evalBJT(vbe,vbc,d.par,d.pol);const ic=r.ic+r.dic_be*(vbx-vbe)+r.dic_bc*(vcx-vbc),ib=r.ib+r.dib_be*(vbx-vbe)+r.dib_bc*(vcx-vbc);
        af(d.c,ic);af(d.b,ib);af(d.e,-ic-ib);
        const st2=(row,dbe,dbc)=>{aj(row,d.b,dbe+dbc);aj(row,d.e,-dbe);aj(row,d.c,-dbc)};st2(d.c,r.dic_be,r.dic_bc);st2(d.b,r.dib_be,r.dib_bc);st2(d.e,-r.dic_be-r.dib_be,-r.dic_bc-r.dib_bc);
        if(d.qr){/* real BJT charges (physical voltages ve, vc; the circuit charge is pol·Q, its derivatives are those of Q) */
          const pr=d.qr,p=d.pol,ve=p*vbe,vc=p*vbc;let qd=0,ce=0,cc=0;
          if(pr.tf>0){if(ve>0){const cb=r.cbe/r.qb;qd=pr.tf*cb;ce=pr.tf*(r.gbe-cb*r.dqbdve)/r.qb;cc=-pr.tf*cb*r.dqbdvc/r.qb}else{qd=pr.tf*r.cbe;ce=pr.tf*r.gbe}}
          const[qje,cje]=trQj(ve,pr.cje,pr.vje,pr.mje),[qjc,cjc]=trQj(vc,pr.cjc,pr.vjc,pr.mjc);
          const dee=cje+ce,dec=cc,dcc=cjc+(pr.tr||0)*r.gbc;
          const qe=p*(qje+qd)+dee*(vbx-vbe)+dec*(vcx-vbc),qc=p*(qjc+(pr.tr||0)*r.cbc)+dcc*(vcx-vbc);
          qNow[qD0+jq]=qe;qNow[qD0+jq+1]=qc;
          if(!dc){const ie=a0*qe+hist[qD0+jq],ge=a0*dee,gc=a0*dec;af(d.b,ie);af(d.e,-ie);aj(d.b,d.b,ge+gc);aj(d.b,d.e,-ge);aj(d.b,d.c,-gc);aj(d.e,d.b,-ge-gc);aj(d.e,d.e,ge);aj(d.e,d.c,gc);
            const ib2=a0*qc+hist[qD0+jq+1],g2=a0*dcc;af(d.b,ib2);af(d.c,-ib2);aj(d.b,d.b,g2);aj(d.b,d.c,-g2);aj(d.c,d.b,-g2);aj(d.c,d.c,g2)}}}
      else{const vgx=V(x,d.g)-V(x,d.s),vdx=V(x,d.d)-V(x,d.s);let vgs=vgx,vds=vdx;
        if(ctx.initj){vgs=d.par.vth;vds=0;limited=true}
        else if(lim){const p=d.pol;let g1=p*vgs,d1=p*vds;const go=p*s.vgs,dold=p*s.vds;const vto=d.par.vth*p;
          if(dold>=0){g1=fetlim(g1,go,vto);d1=trLimvds(d1,dold)}else{const vgdo=go-dold;const vgd=fetlim(g1-d1,vgdo,vto);d1=g1-vgd;d1=-trLimvds(-d1,-dold)}
          if(Math.abs(p*g1-vgs)>1e-12*(1+Math.abs(vgs))||Math.abs(p*d1-vds)>1e-12*(1+Math.abs(vds))){limited=true;vgs=p*g1;vds=p*d1}}
        s.vgs=vgs;s.vds=vds;const r=evalMOS(vgs,vds,d.par,d.pol);const id=r.id+r.dvgs*(vgx-vgs)+r.dvds*(vdx-vds);
        af(d.d,id);af(d.s,-id);aj(d.d,d.g,r.dvgs);aj(d.d,d.d,r.dvds);aj(d.d,d.s,-r.dvgs-r.dvds);aj(d.s,d.g,-r.dvgs);aj(d.s,d.d,-r.dvds);aj(d.s,d.s,r.dvgs+r.dvds);
        if(jq>=0){/* real MOSFET: gate–drain charge of V_GD */const g=d.qgd,p=d.pol;const[q,c]=trQgd(p*(vgs-vds),g.c0,g.vj,g.m);const qg=p*q+c*((vgx-vdx)-(vgs-vds));
          qNow[qD0+jq]=qg;if(!dc){const ii=a0*qg+hist[qD0+jq],gg=a0*c;af(d.g,ii);af(d.d,-ii);aj(d.g,d.g,gg);aj(d.g,d.d,-gg);aj(d.d,d.g,-gg);aj(d.d,d.d,gg)}}}});
    return limited}
  /* dense LU with partial pivoting */
  const LU=new Float64Array(N*N),piv=new Int32Array(N),dx=new Float64Array(N);
  function solve(){LU.set(J);for(let c=0;c<N;c++){let q=c,b=0;for(let r=c;r<N;r++){const v=Math.abs(LU[r*N+c]);if(v>b){b=v;q=r}}if(!(b>1e-300))return false;piv[c]=q;
      if(q!==c)for(let k=c;k<N;k++){const t=LU[c*N+k];LU[c*N+k]=LU[q*N+k];LU[q*N+k]=t}/* multipliers stay in place (LINPACK style), matching the interleaved forward substitution below */
      const d=LU[c*N+c];for(let r=c+1;r<N;r++){const f=LU[r*N+c]/d;if(f===0)continue;LU[r*N+c]=f;for(let k=c+1;k<N;k++)LU[r*N+k]-=f*LU[c*N+k]}}
    for(let i=0;i<N;i++)dx[i]=-F[i];for(let c=0;c<N;c++){const q=piv[c];if(q!==c){const t=dx[c];dx[c]=dx[q];dx[q]=t}const v=dx[c];if(v!==0)for(let r=c+1;r<N;r++)dx[r]-=LU[r*N+c]*v}
    for(let r=N-1;r>=0;r--){let s=dx[r];for(let k=r+1;k<N;k++)s-=LU[r*N+k]*dx[k];dx[r]=s/LU[r*N+r]}return true}
  const RTN=opts.newtonTol||1e-7;
  /* Newton from x (modified in place); returns true when converged */
  function newton(x,ctx,maxIt){let good=0;
    for(let it=0;it<maxIt;it++){const limited=assemble(x,it===0&&ctx.ij?Object.assign({},ctx,{initj:true}):ctx,true);if(!solve()){return false}let ok=!limited;
      for(let i=0;i<N;i++){const xi=x[i],xn=xi+dx[i];/* source, transformer and op-amp output currents follow from the node voltages; they are not tested (round-off of large
         conductances would hide convergence) */const tol=RTN*Math.max(Math.abs(xi),Math.abs(xn))+(i<n||i>=iY?1e-9:1e-12);if(!(Math.abs(dx[i])<=tol)&&(i<iV||(i>=iL&&i<iX)||i>=iY))ok=false;x[i]=xn}
      if(!x.every(isFinite))return false;if(ok){good++;if(good>=2||it>0&&good>=1&&ctx.fast)return true}else good=0}
    return false}
  /* damped Newton (backtracking on the scaled residual), used when plain Newton fails: slower but much more robust */
  const xt=new Float64Array(N),wr=new Float64Array(N);
  function resNorm(x,ctx){assemble(x,ctx,false);let m=0;for(let i=0;i<N;i++){const v=Math.abs(F[i])*wr[i];if(!(v<=m))m=v}return m}
  function newtonLS(x,ctx,maxIt){let good=0;
    for(let it=0;it<maxIt;it++){assemble(x,ctx,false);for(let i=0;i<N;i++)wr[i]=1/Math.max(Math.abs(J[i*N+i]),1e-12);
      let r0=0;for(let i=0;i<N;i++){const v=Math.abs(F[i])*wr[i];if(!(v<=r0))r0=v}
      if(!solve())return false;let lam=1,r1=Infinity;
      for(let k=0;k<12;k++){for(let i=0;i<N;i++)xt[i]=x[i]+lam*dx[i];r1=resNorm(xt,ctx);if(r1<r0*(1-1e-4*lam)||!(r0>0))break;lam/=2}
      let ok=lam===1;for(let i=0;i<N;i++){const tol=RTN*Math.max(Math.abs(x[i]),Math.abs(xt[i]))+(i<n||i>=iY?1e-9:1e-12);if(!(Math.abs(xt[i]-x[i])<=tol)&&(i<iV||(i>=iL&&i<iX)||i>=iY))ok=false}
      x.set(xt);if(!x.every(isFinite))return false;if(ok){good++;if(good>=2)return true}else good=0}
    return false}
  const S={_asm:(x,ctx)=>{assemble(x,ctx,false);return{J:Float64Array.from(J),F:Float64Array.from(F)}},N,n,x:new Float64Array(N),t:0,ok:false,iV,iL,iX,iO,iY,stats:{steps:0,rej:0,nf:0}};
  /* initial device state: junctions near the knee, like SPICE */
  function initDev(){C.dev.forEach((d,j)=>{const s=st[j];if(d.t==='D')s.v=0;else if(d.t==='Q'){s.vbe=0;s.vbc=0}else{s.vgs=0;s.vds=0}})}
  /* ---- DC operating point at t = 0 ---- */
  S.dcop=function(genOff){const go=!!genOff;const x=new Float64Array(N);initDev();let ok=newton(x,{dc:true,t:0,ij:true,genOff:go},150);
    if(!ok){x.fill(0);initDev();ok=newtonLS(x,{dc:true,t:0,genOff:go},300)}
    if(!ok){x.fill(0);initDev();let g=1e-2,good=true;for(const gg of[1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8,1e-9,1e-10,1e-12]){g=gg;if(!newton(x,{dc:true,t:0,gsh:g,genOff:go},150)){good=false;break}}if(good)ok=newton(x,{dc:true,t:0,genOff:go},150)}
    if(!ok){x.fill(0);initDev();let s=0,step=0.05;ok=true;while(s<1){const s2=Math.min(1,s+step);const keep=Float64Array.from(x);if(newton(x,{dc:true,t:0,sc:s2,genOff:go},100)){s=s2;step=Math.min(step*2,0.25)}else{x.set(keep);step/=4;if(step<1e-7){ok=false;break}}}}
    if(!ok){/* pseudo-transient continuation: the circuit (sources frozen at t = 0) with a small capacitance at every node is integrated
         from zero until it settles; it finds a stable state also with positive feedback or nearly floating parts */
      x.fill(0);initDev();const xp=new Float64Array(N);let h=1e-9,good=0;const cpt=1e-9;
      for(let k=0;k<3000&&h<1e9;k++){xp.set(x);assemble(x,{dc:true,t:0,genOff:go},false);hist.set(qNow);for(let q=0;q<NQ;q++)hist[q]=-hist[q]/h;
        const ctx={dc:false,t:0,a0:1/h,ptc:{c:cpt,xp},ij:k===0,genOff:go};if(newton(x,ctx,30)){let d=0;for(let i=0;i<N;i++)d=Math.max(d,Math.abs(x[i]-xp[i])/(1e-6+Math.abs(x[i])));h*=d<1e-3?4:2;good++}else{x.set(xp);h/=4;if(h<1e-18)break}}
      ok=newton(x,{dc:true,t:0,genOff:go},150)}
    if(!ok)return false;assemble(x,{dc:true,t:0,genOff:go},false);S.x.set(x);S.t=0;S.ok=true;
    /* history for the first transient step */
    hq1.set(qNow);xs=[Float64Array.from(x)];ts=[0];qs=[Float64Array.from(qNow)];nSince=1;return true};
  /* ---- transient ---- */
  let hq1=new Float64Array(NQ),hq2=new Float64Array(NQ),xs=[],ts=[],qs=[],nSince=1,hNext=0;
  /* the step is controlled by the truncation error of the charges and fluxes (like SPICE): each against its own largest value so far */
  const peakq=new Float64Array(NQ),qsc=new Float64Array(NQ),qp=new Float64Array(NQ);
  /* error-checked unknowns: node voltages, inductor currents, op-amp states */
  S.rtol=opts.rtol||1e-3;S.vfloor=opts.vfloor||1e-3;S.ifloor=opts.ifloor||1e-9;
  caps.forEach((e,j)=>qsc[qC0+j]=e.c*S.vfloor);C.L.forEach((e,j)=>qsc[qL0+j]=e.l*S.ifloor);dq.forEach((d,j)=>qsc[qD0+j]=d.sc*S.vfloor+d.tt*1e-6);C.oa.forEach((o,j)=>qsc[qO0+j]=S.vfloor/(o.wp*o.a0));
  function nextBreak(t){let b=Infinity;for(const e of C.V)b=Math.min(b,trNextBreak(e.w,t));for(const e of C.I)b=Math.min(b,trNextBreak(e.w,t));return b}
  /* advance to tEnd; hmax = largest step; onStep(t, x) after every accepted step. Returns false on failure */
  S.run=function(tEnd,hmax,onStep,maxSteps,noClip){S.limit=false;if(!S.ok)return false;maxSteps=maxSteps||2e6;const hmin=Math.max(1e-18,hmax*1e-9);const x=new Float64Array(N),xp=new Float64Array(N);let steps=0;
    if(!(hNext>0))hNext=hmax*1e-3;
    const tStop=noClip?tEnd:tEnd*(1-1e-13)-1e-30;let skipH=null;while(S.t<tStop){if(++steps>maxSteps){S.limit=true;return false}
      const t0=S.t,bp=nextBreak(t0);let h=skipH?Math.min(skipH[0],noClip?Infinity:tEnd-t0):Math.min(hNext,hmax,noClip?Infinity:tEnd-t0);let hitBp=false;
      if(t0+h>=bp-1e-9*h){h=bp-t0;hitBp=true}else if(t0+2*h>bp){h=0.5*(bp-t0)}
      if(!(h>0))h=hmin;
      /* order and coefficients */
      const ord=nSince>=2&&!skipH?2:1;let a0,a1=0,a2=0,h1=0,h2=0;
      if(ord===1)a0=1/h;else{h1=t0-ts[1];const r=h/h1;a0=(1+2*r)/(h*(1+r));a1=-(1+r)/h;a2=r*r/(h*(1+r))}
      if(ord===1)for(let k=0;k<NQ;k++)hist[k]=-hq1[k]/h;else for(let k=0;k<NQ;k++)hist[k]=a1*hq1[k]+a2*hq2[k];
      /* predictor: polynomial through the last points since the corner */
      const np=skipH?1:Math.min(nSince,3);const t1=t0+h;
      for(let i=0;i<N;i++){if(np===1)xp[i]=xs[0][i];else if(np===2){xp[i]=xs[0][i]+(xs[0][i]-xs[1][i])*(t1-ts[0])/(ts[0]-ts[1])}
        else{const[T0,T1,T2]=ts,[X0,X1,X2]=[xs[0][i],xs[1][i],xs[2][i]];xp[i]=X0*(t1-T1)*(t1-T2)/((T0-T1)*(T0-T2))+X1*(t1-T0)*(t1-T2)/((T1-T0)*(T1-T2))+X2*(t1-T0)*(t1-T1)/((T2-T0)*(T2-T1))}}
      x.set(xp);
      /* device limiting starts from the previous accepted solution */
      let ok=skipH?newtonLS(x,{dc:false,t:t1,a0},400):newton(x,{dc:false,t:t1,a0},40);
      /* at the smallest step a fold of the algebraic part (positive feedback) has no nearby solution: the circuit jumps. Find the
         new state with a pseudo-transient continuation at this time point (a conductance to the previous iterate, reduced to zero) */
      if(!ok&&h<=hmin&&!skipH){x.set(xs[0]);ok=newtonLS(x,{dc:false,t:t1,a0},300)}
      /* still no solution at the smallest step: the algebraic part of the circuit has a fold (e.g. a latch switching) and the state
         jumps. Like SPICE stepping over it, larger steps are tried from the last point (backward Euler), the error test is skipped */
      if(!ok){S.stats.nf++;if(skipH){skipH.shift();if(!skipH.length)return false;continue}if(h<=hmin){skipH=[hmax,hmax/10,hmax/100,hmax/1e3,hmax/1e4];continue}hNext=Math.max(hmin,h/8);nSince=Math.min(nSince,np);continue}
      /* local truncation error */
      let r=0;if(np>=2&&!skipH){h2=np>=3?ts[1]-ts[2]:0;h1=t0-ts[1];
        let fac;if(ord===2&&np>=3){const L=h*h*(h+h1)*(h+h1)/(6*(2*h+h1)),P=h*(h+h1)*(h+h1+h2)/6;fac=L/(L+P)}else{fac=h/(2*h+h1)}
        assemble(x,{dc:false,t:t1,a0},false);
        for(let k=0;k<NQ;k++){let pv;if(np===2)pv=qs[0][k]+(qs[0][k]-qs[1][k])*(t1-ts[0])/(ts[0]-ts[1]);
          else{const[T0,T1,T2]=ts;pv=qs[0][k]*(t1-T1)*(t1-T2)/((T0-T1)*(T0-T2))+qs[1][k]*(t1-T0)*(t1-T2)/((T1-T0)*(T1-T2))+qs[2][k]*(t1-T0)*(t1-T1)/((T2-T0)*(T2-T1))}
          const tol=S.rtol*Math.max(peakq[k],Math.abs(qNow[k]),qsc[k])+1e-30;const e=fac*Math.abs(qNow[k]-pv)/tol;if(e>r)r=e}}
      const k1=1/(ord+1);
      if(r>1&&h>hmin){S.stats.rej++;hNext=Math.max(hmin,h*Math.max(0.1,0.9*Math.pow(r,-k1)));continue}
      /* accept */
      assemble(x,{dc:false,t:t1,a0},false);
      hq2.set(hq1);hq1.set(qNow);xs.unshift(Float64Array.from(x));ts.unshift(t1);qs.unshift(Float64Array.from(qNow));if(xs.length>3){xs.pop();ts.pop();qs.pop()}
      for(let k=0;k<NQ;k++){const a=Math.abs(qNow[k]);if(a>peakq[k])peakq[k]=a}
      S.t=t1;S.x.set(x);S.stats.steps++;nSince++;
      hNext=np>=2?h*Math.min(2,Math.max(0.2,0.9*Math.pow(Math.max(r,1e-10),-k1))):h*2;
      if(skipH){skipH=null;S.stats.jump=(S.stats.jump||0)+1;hitBp=true}
      if(hitBp){nSince=1;xs=[xs[0]];ts=[ts[0]];qs=[qs[0]];hNext=Math.min(hmax*1e-3,hNext)}
      if(onStep)onStep(S.t,S.x)}
    return true};
  return S}
/* convenience for tests: simulate 0…tEnd, return samples */
function trRun(C,tEnd,hmax,opts){const S=trCreate(C,opts);if(!S.dcop())return{ok:false,msg:'dcop'};const T=[0],X=[Float64Array.from(S.x)];
  const ok=S.run(tEnd,hmax,(t,x)=>{T.push(t);X.push(Float64Array.from(x))});return{ok,T,X,S}}
if(typeof module!=='undefined')module.exports={trCreate,trRun,trWave,trNextBreak,trCorners,trQj,trQgd,trOaS};
