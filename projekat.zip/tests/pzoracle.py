# Independent poles/zeros oracle: builds the MNA descriptor pencil G + s*C from the netlist on its own
# and gets the finite generalized eigenvalues with LAPACK's QZ algorithm (scipy.linalg.eig).
# Input (stdin): JSON list of circuits {edges:[{a,b,k,v}], ctrl:[{t,p,n,o,A0,wp}], vin, gnd, vout|null, mode:'H'|'Z', s0}
# Output: JSON list of {P:[[re,im]...], Z:[...]} for the function the app plots (H = Vout/Vin, or Zin)
import sys, json, numpy as np, scipy.linalg as sl

def pencil(c, drive):
    nodes = sorted(({e['a'] for e in c['edges']} | {e['b'] for e in c['edges']} |
                   {x for q in c['ctrl'] for x in (q['p'], q['n'], q['o'])} |
                   {x for q in c.get('vccs', []) for x in (q['p'], q['n'], q['a'], q['b'])} | {c['vin']}) - {c['gnd']})
    ix = {x: i for i, x in enumerate(nodes)}
    Ls = [e for e in c['edges'] if e['k'] == 'L']
    n = len(nodes) + len(Ls) + len(c['ctrl']) + (1 if drive == 'v' else 0)
    G = np.zeros((n, n)); C = np.zeros((n, n)); b = np.zeros(n)
    I = lambda x: -1 if x == c['gnd'] else ix[x]
    def add(M, r, k, v):
        if r >= 0 and k >= 0: M[r, k] += v
    for e in c['edges']:
        a, bb, v = I(e['a']), I(e['b']), e['v']
        if e['k'] == 'R':
            y = 1.0 / v
            add(G, a, a, y); add(G, bb, bb, y); add(G, a, bb, -y); add(G, bb, a, -y)
        elif e['k'] == 'C':
            add(C, a, a, v); add(C, bb, bb, v); add(C, a, bb, -v); add(C, bb, a, -v)
    k = len(nodes)
    for e in Ls:   # branch current i: V(a) - V(b) - s L i = 0
        a, bb = I(e['a']), I(e['b'])
        add(G, a, k, 1); add(G, bb, k, -1); add(G, k, a, 1); add(G, k, bb, -1); add(C, k, k, -e['v']); k += 1
    for q in c['ctrl']:   # output current k enters node o
        o, p, m = I(q['o']), I(q['p']), I(q['n'])
        add(G, o, k, -1)
        if q['t'] == 'nullor':
            add(G, k, p, 1); add(G, k, m, -1)
        else:                # (s + wp) Vo = A0 wp (V+ - V-)
            add(C, k, o, 1); add(G, k, o, q['wp']); add(G, k, p, -q['A0'] * q['wp']); add(G, k, m, q['A0'] * q['wp'])
        k += 1
    for q in c.get('vccs', []):   # current G (V_a - V_b) leaves node p, enters node n
        p_, n_, a_, b_ = I(q['p']), I(q['n']), I(q['a']), I(q['b'])
        add(G, p_, a_, q['G']); add(G, p_, b_, -q['G']); add(G, n_, a_, -q['G']); add(G, n_, b_, q['G'])
    vi = I(c['vin'])
    if drive == 'v':
        add(G, vi, k, 1); add(G, k, vi, 1); b[k] = 1
    else:
        b[vi] = 1
    return G, C, b, I

def feig(G, C, s0):
    """finite eigenvalues s of det(G + s C) = 0, frequency-normalised and equilibrated"""
    n = G.shape[0]
    if n == 0: return []
    A = G.copy(); B = s0 * C
    r = np.ones(n); q = np.ones(n)
    for _ in range(6):
        m = np.max(np.abs(A) + np.abs(B), axis=1); m[m == 0] = 1; A /= np.sqrt(m)[:, None]; B /= np.sqrt(m)[:, None]
        m = np.max(np.abs(A) + np.abs(B), axis=0); m[m == 0] = 1; A /= np.sqrt(m)[None, :]; B /= np.sqrt(m)[None, :]
    w = sl.eig(A, -B, right=False, homogeneous_eigvals=True)
    al, be = w
    out = []
    for a_, b_ in zip(al, be):
        if abs(b_) > 1e-9 * abs(a_) and abs(b_) > 1e-300:
            s = a_ / b_ * s0
            out.append(s)
    return out

def run(c):
    s0 = c['s0']
    if c['mode'] == 'Z':
        Gi, Ci, _, _ = pencil(c, 'i'); Gv, Cv, _, _ = pencil(c, 'v')
        P = feig(Gi, Ci, s0); Z = feig(Gv, Cv, s0)
    else:
        G, C, b, I = pencil(c, 'v'); P = feig(G, C, s0)
        n = G.shape[0]
        G2 = np.zeros((n + 1, n + 1)); C2 = np.zeros((n + 1, n + 1))
        G2[:n, :n] = G; C2[:n, :n] = C; G2[:n, n] = -b; G2[n, I(c['vout'])] = 1
        Z = feig(G2, C2, s0)
    return {'P': [[s.real, s.imag] for s in P], 'Z': [[s.real, s.imag] for s in Z]}

if __name__ == '__main__':
    data = json.load(sys.stdin)
    print(json.dumps([run(c) for c in data]))
