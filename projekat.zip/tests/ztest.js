// Zener/LED/Schottky single diode currents vs ngspice over a sweep of voltages
const {evalDiode,diodeBrk,VT}=require('./semi.js');const fs=require('fs'),cp=require('child_process');const NG=process.env.NGSPICE;
const TK=VT*1.6021918e-19/1.3806226e-23,TC=TK-273.15;
const models=[{is:1e-14,n:1,bv:5.1,ibv:1e-3},{is:1e-14,n:1.2,bv:12,ibv:5e-3},{is:1e-7,n:1.05},{is:1e-18,n:2},{is:2e-9,n:1.8,bv:3.3,ibv:2e-2},{is:1e-12,n:1,bv:20,ibv:1e-9}];
const vs=[];for(let v=-25;v<=1.2;v+=0.137)vs.push(+v.toFixed(4));
const L=['* z','.options reltol=1e-10 vntol=1e-14 abstol=1e-22 temp='+TC.toPrecision(15)+' tnom='+TC.toPrecision(15)];const pr=[];
models.forEach((m,j)=>{L.push(`.model DM${j} D(IS=${m.is} N=${m.n}${m.bv?` BV=${m.bv} IBV=${m.ibv}`:''})`);vs.forEach((v,i)=>{L.push(`V${j}_${i} a${j}_${i} 0 DC ${v}`,`D${j}_${i} a${j}_${i} 0 DM${j}`);pr.push(`i(V${j}_${i})`)})});
L.push('.control','set numdgt=16','op');for(let k=0;k<pr.length;k+=40)L.push('print '+pr.slice(k,k+40).join(' '));L.push('quit','.endc','.end');fs.writeFileSync('/tmp/z.cir',L.join('\n'));
const out=cp.execFileSync(NG,['-b','/tmp/z.cir'],{stdio:['ignore','pipe','ignore'],maxBuffer:1e8}).toString();
let worst=0,bad=0;models.forEach((m,j)=>{const par=Object.assign({},m);par.xbv=diodeBrk(par);vs.forEach((v,i)=>{if(m.bv&&v<-m.bv-0.4)return;if(!m.bv&&v<-25)return;const mm=out.match(new RegExp(`i\\(v${j}_${i}\\) = ([-+0-9.e]+)`));const ng=-(+mm[1]);const a=evalDiode(v,par).i;const e=Math.abs(a-ng)/Math.max(Math.abs(ng),1e-13);if(e>1e-7){bad++;if(bad<8)console.log(j,v,a,ng,e)}worst=Math.max(worst,e)})});
console.log('points',models.length*vs.length,'worst rel',worst.toExponential(2),'bad',bad);
