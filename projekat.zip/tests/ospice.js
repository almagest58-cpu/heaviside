// ngspice (independent engine) vs the 72-digit oracle on the structured op-amp/pot circuits
const fs=require('fs'),cp=require('child_process');const {hpSolveX}=require('./hpx.js');
const NGS=process.env.NGSPICE||'ngspice';
const WD=fs.mkdtempSync(require('os').tmpdir()+'/spo-');
const src=fs.readFileSync(__dirname+'/otest.js','utf8');eval(src.slice(src.indexOf('function expand'),src.indexOf('const N=+')).replace('function expand','global.expand=function'));
const d=JSON.parse(fs.readFileSync(__dirname+'/otest2.json'));const FS=Array.from({length:19},(_,i)=>Math.pow(10,i/2));
const nn=x=>x==='g'?'0':'N'+x;const abs=z=>Math.hypot(z[0],z[1]);const div=(a,b)=>{const q=b[0]*b[0]+b[1]*b[1];return[(a[0]*b[0]+a[1]*b[1])/q,(a[1]*b[0]-a[0]*b[1])/q]};
let worstH=0,worstZ=0,n=0,wR=0,nR=0;const bad=[];
d.list.forEach((cir,ci)=>{const ex=expand(cir);const L=['* oa check','V1 Ni 0 DC 0 AC 1'];ex.edges.forEach((e,j)=>L.push(`${e.k}${j+1} ${nn(e.a)} ${nn(e.b)} ${e.v.toPrecision(17)}`));
  ex.ctrl.forEach((c,j)=>{if(c.t==='nullor')L.push(`E${j+1} ${nn(c.o)} 0 ${nn(c.p)} ${nn(c.n)} 1e10`);else{L.push(`G${j+1} 0 QQ${j} ${nn(c.p)} ${nn(c.n)} ${c.A0.toPrecision(17)}`,`RX${j} QQ${j} 0 1`,`CX${j} QQ${j} 0 ${(1/c.wp).toPrecision(17)}`,`EB${j+1} ${nn(c.o)} 0 QQ${j} 0 1`)}});
  L.push('.control','option noopac','set filetype=ascii');FS.forEach((f,k)=>{L.push(`ac lin 1 ${f.toPrecision(17)} ${f.toPrecision(17)}`,`write ${WD}/c${ci}_${k}.raw v(No) i(V1)`)});L.push('quit','.endc','.end');
  fs.writeFileSync(`${WD}/c${ci}.cir`,L.join('\n'));try{cp.execFileSync(NGS,['-b',`${WD}/c${ci}.cir`],{stdio:'ignore',timeout:60000})}catch(e){bad.push([ci,'spice fail']);return}
  const mxH=[],rows=[];FS.forEach((f,k)=>{const txt=fs.readFileSync(`${WD}/c${ci}_${k}.raw`,'utf8');const v=txt.split('Values:')[1].trim().split(/\s+/);const V=v[2].split(',').map(Number),I=v[3].split(',').map(Number);
    const hH=hpSolveX(ex.edges,ex.ctrl,f,false),hZ=hpSolveX(ex.edges,ex.ctrl,f,true);rows.push({f,V,Z:div([1,0],[-I[0],-I[1]]),hH,hZ})});
  const mx=Math.max(...rows.map(r=>abs(r.hH))),mz=Math.max(...rows.map(r=>abs(r.hZ)).filter(isFinite));n++;
  const allR=cir.oas.every(u=>cir.realMode&&u.real);if(allR)nR++;
  for(const r of rows){const eH=abs([r.V[0]-r.hH[0],r.V[1]-r.hH[1]])/Math.max(abs(r.hH),1e-9*mx);worstH=Math.max(worstH,eH);if(allR)wR=Math.max(wR,eH);if(eH>1e-6)bad.push([ci,cir.typ,'H',r.f,eH]);
    if(isFinite(abs(r.hZ))&&abs(r.hZ)<1e40){const eZ=abs([r.Z[0]-r.hZ[0],r.Z[1]-r.hZ[1]])/Math.max(abs(r.hZ),1e-9*mz);worstZ=Math.max(worstZ,eZ);if(allR)wR=Math.max(wR,eZ);if(eZ>1e-6)bad.push([ci,cir.typ,'Z',r.f,eZ])}}});
bad.sort((a,b)=>b[4]-a[4]);bad.slice(0,12).forEach(b=>{const c=d.list[b[0]];console.log(JSON.stringify(b),'real mode',c.realMode,'oa',c.oas.map(u=>c.realMode&&u.real?'R':'I').join(''))});console.log('real-op-amp circuits (identical model in ngspice)',nR,'worst rel H/Z',wR.toExponential(2));console.log('circuits',n,'worst H rel (ngspice vs oracle)',worstH.toExponential(2),'worst Z rel',worstZ.toExponential(2),'bad',bad.length,JSON.stringify(bad.slice(0,12)));
