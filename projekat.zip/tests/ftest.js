// Formula check over many circuits: all examples (ideal, real), typical op-amp circuits, random passive circuits.
// Every equation of every derivation (H, Zin, Nyquist, spectrum, Smith) is evaluated numerically (texcheck.js).
const { chromium } = require('playwright');const fs=require('fs');const {checkDerivation,tokenize}=require('./texcheck.js');
let seed=+(process.env.SEED||9090);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const src=fs.readFileSync(__dirname+'/otest.js','utf8');eval(src.slice(src.indexOf('const parOf'),src.indexOf('function gen()')).replace(/const (\w+)=/g,'global.$1='));eval(src.slice(src.indexOf('function gen2'),src.indexOf('function expand')).replace('function gen2','global.gen2=function'));
eval(src.slice(src.indexOf('function gen()'),src.indexOf('function gen2')).replace('function gen()','global.gen1=function()'));
function genP(E){const zmode=rnd()<0.25;const nInt=Math.max(0,Math.round(E*0.5)-(zmode?2:3));const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:nInt},(_,j)=>'n'+j)];
  const order=nodes.slice().sort(()=>rnd()-0.5);const els=[];const add=(a,b,k)=>els.push({k,a,b,v:val(k),par:parOf(k)});
  for(let j=1;j<order.length;j++)add(order[j],pick(order.slice(0,j)),pick(['R','L','C']));while(els.length<E){const a=pick(nodes),b=pick(nodes);if(a!==b)add(a,b,pick(['R','L','C']))}
  return{zmode,els,oas:[],realMode:rnd()<0.3}}
const canon=k=>{let r=tokenize(k).map(x=>x.t==='num'?String(x.v):x.v).join('');return r};
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(500);
if(process.env.LANG_)await p.evaluate(l=>setLang(l),process.env.LANG_);
const keys=await p.evaluate(()=>Object.keys(EXAMPLES));const jobs=[];
if(!process.env.NOEX)for(const real of[false,true])for(const k of keys)jobs.push({ex:k,real,name:k+(real?' (real)':'')});
for(let i=0;i<+(process.env.NACT||120);i++){const c=gen2();jobs.push({cir:c,name:'act'+i+'/t'+c.typ+(c.realMode?'R':'')})}
for(let i=0;i<+(process.env.NRND||60);i++){const c=gen1();jobs.push({cir:c,name:'rnd'+i+(c.realMode?'R':'')})}
for(let i=0;i<+(process.env.NPAS||80);i++){const c=genP(2+Math.floor(rnd()*8));jobs.push({cir:c,name:'pas'+i+(c.realMode?'R':'')})}
const all=[];let tot={eq:0,checked:0,defined:0,der:0,fail:0};const unkAll={};const pf=[];
for(const J of jobs){
  const r=await p.evaluate(J=>{
    if(J.ex){const b=document.createElement('button');b.dataset.ex=J.ex;document.getElementById('exList').appendChild(b);b.click();b.remove();closeAll();state.realMode=J.real;state.std=false;circuitChanged()}
    else{const cir=J.cir;uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240];j++;return q};
      for(const e of cir.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.par=Object.assign({},e.par);if(e.k==='P'){q.pos=e.pos;add(e.w,q,2)}parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      for(const u of cir.oas){const[x,y]=pos();const q=mkP('OA',x,y,0);q.par=Object.assign({},u.par);q.real=u.real;parts.push(q);add(u.p,q,0);add(u.n,q,1);add(u.o,q,2)}
      const vin=mkP('VIN',0,-400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
      for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
      state.parts=parts;state.wires=wires;state.realMode=cir.realMode;state.std=false;state.fmin=10;state.fmax=1e7;assignNames();NET=netlist();if(!NET.ok)return{err:NET.err};update()}
    if(!NET.ok)return{err:NET.err};
    const eqs=h=>{const d=document.createElement('div');d.innerHTML=h;const out=[];d.querySelectorAll('.eq').forEach(e=>{const t=e.textContent;const m=t.match(/\\\[[\s\S]*?\\\]/g);if(m)out.push(...m)});return out};
    const res=[];const fs=[0.17,0.43,0.71].map(u=>Math.pow(10,Math.log10(state.fmin)+u*(Math.log10(state.fmax)-Math.log10(state.fmin))));
    const refs=fs.map(f=>({h:resp(f),z:solve(f,'zin')}));
    for(const g of['main','ohm','nyq','spec','smith']){let h='';try{h=g==='main'?derive():deriveFor(g)}catch(e){res.push({g,exc:e.message});continue}
      if(!DER){res.push({g,none:true,msg:h.replace(/<[^>]+>/g,' ').slice(0,120)});continue}
      const vals={};for(const k in DER.vals)vals[symTex(k)]=DER.vals[k];res.push({g,isZ:!!DER.isZ,vals,eqs:eqs(h)})}
    return{res,fs,refs,mode:NET.mode}},J);
  if(r.err){all.push({name:J.name,err:r.err});continue}
  const row={name:J.name,mode:r.mode,ders:[]};
  for(const d of r.res){if(d.exc){row.ders.push({g:d.g,exc:d.exc});tot.fail++;continue}if(d.none){row.ders.push({g:d.g,none:d.msg});continue}tot.der++;
    const vals={};for(const k in d.vals)vals[canon(k)]=[d.vals[k],0];
    const refs=(d.g==='main'||d.g==='ohm')?Object.assign(r.refs.map(x=>({h:x.h,z:x.z})),{isZ:d.isZ||d.g==='ohm'}):null;
    const c=checkDerivation(d.eqs,vals,r.fs,refs);tot.eq+=c.stats.eq;tot.checked+=c.stats.checked;tot.defined+=c.stats.defined;c.stats.unk.forEach(u=>unkAll[u]=(unkAll[u]||0)+1);c.stats.parseFail.forEach(x=>pf.push(J.name+' '+d.g+': '+x));
    row.ders.push({g:d.g,neq:d.eqs.length,checked:c.stats.checked,findings:c.findings})}
  all.push(row)}
fs.writeFileSync(__dirname+'/ftest.json',JSON.stringify(all));
let nf=0;for(const r of all){if(r.err)continue;for(const d of r.ders){if(d.exc)console.log('EXC',r.name,d.g,d.exc);if(d.findings&&d.findings.length){nf+=d.findings.length;console.log('FIND',r.name,d.g,JSON.stringify(d.findings.slice(0,3)).slice(0,900))}}}
console.log('totals',JSON.stringify(tot),'circuits',all.length,'netErr',all.filter(r=>r.err).length,'findings',nf);
console.log('unknown names (count of derivations):',JSON.stringify(Object.entries(unkAll).sort((a,b)=>b[1]-a[1]).slice(0,60)));
console.log('parse failures',pf.length);[...new Set(pf.map(x=>x.replace(/^\S+ \S+: /,'')))].slice(0,40).forEach(x=>console.log('  PF',x.slice(0,300)));
console.log('pageerrors',errs.slice(0,5));await b.close()})();
