import json,sys
R=json.load(open(sys.argv[1] if len(sys.argv)>1 else 'tdtest.json'))
f=lambda v:'-' if v is None else '%.1e'%v
print('rows',len(R),'errors',sum(1 for r in R if 'err' in r))
for r in R:
  if 'err' in r: print('ERR',r['name'],r['err'][:80])
W={}
for r in R:
  if 'err' in r: continue
  for k in ['eH','eZ','eS','eI','eSn','eIn','e0']:
    v=r.get(k)
    if v is not None and (k not in W or v>W[k][0]): W[k]=(v,r['name'])
print('worst',{k:(f(v[0]),v[1]) for k,v in W.items()})
print('exact',sum(1 for r in R if r.get('exact')),'sim',sum(1 for r in R if 'err' not in r and r.get('eS') is not None and not r.get('exact')))
for r in R:
  if 'err' in r: continue
  flags=[]
  if r.get('eS') is not None and r['eS']>1e-3: flags.append('step %s@%s'%(f(r['eS']),r.get('kS')))
  if r.get('eI') is not None and r['eI']>1e-2: flags.append('imp %s@%s'%(f(r['eI']),r.get('kI')))
  if r.get('eH',0)>1e-6: flags.append('H '+f(r['eH']))
  if r.get('eZ',0)>1e-6: flags.append('Z '+f(r['eZ']))
  for q in ['pzP','pzZ']:
    x=r.get(q)
    if x and (x['miss'] or x['extra'] or x['worst']>1e-6): flags.append('%s w%s miss%d extra%d'%(q,f(x['worst']),len(x['miss']),len(x['extra'])))
  if r.get('pz'): flags.append(r['pz'])
  if r.get('met') and r.get('mApp'):
    for k in ['over','tr','ts','tau']:
      a,b=r['mApp'].get(k),r['met'].get(k)
      if (a is None)!=(b is None): flags.append('%s %s/%s'%(k,a,b))
      elif a is not None:
        sc=max(abs(b),1 if k=='over' else r['T']*1e-3)
        if abs(a-b)/sc>5e-3: flags.append('%s %.4g/%.4g'%(k,a,b))
  if flags: print(r['name'],r['mode'],'exact' if r.get('exact') else 'sim(why=%s)'%r.get('rmWhy'),'|',' ; '.join(flags))
