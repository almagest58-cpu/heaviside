// Drawing check: every graph is drawn on an instrumented canvas; the axis labels that were actually written are parsed back
// into an axis mapping, and the drawn curve is compared, pixel by pixel, with the true response computed independently at
// fine frequency spacing (vertices AND the straight segments between them: a segment that cuts a corner of the true curve
// by more than a pixel means the graph is under-sampled there).
const { chromium } = require('playwright');const fs=require('fs');
let seed=+(process.env.SEED||2468);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const src=fs.readFileSync(__dirname+'/otest.js','utf8');eval(src.slice(src.indexOf('const parOf'),src.indexOf('function gen()')).replace(/const (\w+)=/g,'global.$1='));eval(src.slice(src.indexOf('function gen2'),src.indexOf('function expand')).replace('function gen2','global.gen2=function'));
const NSEMI=+(process.env.NSEMI||0);
/* SEMI: transistor/diode circuits from stest.js (QREAL=1 gives real BJT/MOSFET parameters), linearized by the app */
if(NSEMI){const s2=fs.readFileSync(__dirname+'/stest.js','utf8');eval(s2.slice(s2.indexOf('const QR='),s2.indexOf('function spice(')).replace('const QR=','global.QR=').replace(/\nconst (qsc|msc|dsc)=/g,'\nglobal.$1=').replace('function gen()','global.genS=function()'))}
function genP(E){const zmode=rnd()<0.25;const nInt=Math.max(0,Math.round(E*0.5)-(zmode?2:3));const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:nInt},(_,j)=>'n'+j)];
  const order=nodes.slice().sort(()=>rnd()-0.5);const els=[];const add=(a,b,k)=>els.push({k,a,b,v:val(k),par:parOf(k)});
  for(let j=1;j<order.length;j++)add(order[j],pick(order.slice(0,j)),pick(['R','L','C']));while(els.length<E){const a=pick(nodes),b=pick(nodes);if(a!==b)add(a,b,pick(['R','L','C']))}
  return{zmode,els,oas:[],realMode:rnd()<0.4}}
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(500);
await p.evaluate(()=>{window.__LOG=null;const P=CanvasRenderingContext2D.prototype;
  for(const m of['moveTo','lineTo','arc','fillText','stroke','fill','beginPath','closePath','fillRect','strokeRect','rect','save','restore','translate','clip']){const o=P[m];P[m]=function(...a){if(window.__LOG)window.__LOG.push({m,a,ss:this.strokeStyle,fs:this.fillStyle,lw:this.lineWidth,ta:this.textAlign,tb:this.textBaseline,ga:this.globalAlpha,dash:this.getLineDash().length,tr:this.getTransform().e+','+this.getTransform().f});return o.apply(this,a)}}
  /* parse a label written on an axis back into a number */
  window.__num=s=>{s=String(s).replace(/−/g,'-').replace(/\s+/g,' ').trim();s=s.replace(/^j/,'');const m=s.match(/^([-+]?[0-9]*\.?[0-9]+(?:e[-+]?\d+)?)\s*([afpnuµmkMGT]?)/);if(!m)return NaN;const mul={'':1,a:1e-18,f:1e-15,p:1e-12,n:1e-9,u:1e-6,'µ':1e-6,m:1e-3,k:1e3,M:1e6,G:1e9,T:1e12}[m[2]];return(+m[1])*(mul===undefined?1:mul)};
  /* curves: paths stroked with lineWidth 2 in a given colour, solid; returns list of polylines */
  window.__curves=(L,col,lw)=>{const out=[];let cur=[],path=[];for(const e of L){if(e.m==='beginPath'){path=[];cur=null}else if(e.m==='moveTo'){cur=[[e.a[0],e.a[1]]];path.push(cur)}else if(e.m==='lineTo'){if(cur)cur.push([e.a[0],e.a[1]])}else if(e.m==='stroke'){if(e.ss===col&&Math.abs(e.lw-(lw||2))<1e-9&&!e.dash&&e.ga===1&&e.tr==='0,0')for(const q of path)if(q.length>3)out.push(q);path=[]}}return out}});
const keys=await p.evaluate(()=>Object.keys(EXAMPLES).filter(k=>!k.startsWith('o_')));const jobs=[];
if(!process.env.NOEX)for(const real of[false,true])for(const k of keys)jobs.push({ex:k,real,name:k+(real?' (real)':'')});
for(let i=0;i<+(process.env.NACT||40);i++){const c=gen2();jobs.push({cir:c,name:'act'+i+'/t'+c.typ+(c.realMode?'R':'')})}
for(let i=0;i<+(process.env.NPAS||60);i++){const c=genP(2+Math.floor(rnd()*10));jobs.push({cir:c,name:'pas'+i+(c.realMode?'R':'')})}
for(let i=0;i<NSEMI;i++){const c=genS();if(process.env.RM)c.real=process.env.RM==='1';jobs.push({semi:c,name:'semi'+i+'/t'+c.typ+(c.real?'R':'')})}
const rows=[];const ONLY=process.env.ONLY?process.env.ONLY.split(','):null;
for(const J of jobs){if(ONLY&&!ONLY.includes(J.name))continue;J.dbgt=!!process.env.DBGT;
  const r=await p.evaluate(J=>{window.__DBGT=!!J.dbgt;
    if(J.semi){const C=J.semi;uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240+80];j++;return q};
      for(const e of C.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.real=false;parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      for(const e of C.vdc){const[x,y]=pos();const q=mkP('VDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      for(const e of C.idc){const[x,y]=pos();const q=mkP('IDC',x,y,0,e.v);parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      C.xf.forEach(e=>{const[x,y]=pos();const q=mkP('T',x,y,0,e.n);q.par=Object.assign({},e.par);parts.push(q);add(e.p1,q,0);add(e.n1,q,1);add(e.p2,q,2);add(e.n2,q,3)});
      C.devs.forEach(d=>{const[x,y]=pos();const q=mkP(d.k,x,y,0);q.sc=Object.assign({},d.sc);if(d.k!=='D'){q.pol=d.pol;q.real=true}else{q.dt=d.sc.dt;delete q.sc.dt}parts.push(q);
        if(d.k==='D'){add(d.a,q,0);add(d.b,q,1)}else if(d.k==='Q'){add(d.b,q,0);add(d.c,q,1);add(d.e,q,2)}else{add(d.g,q,0);add(d.d,q,1);add(d.s,q,2)}});
      const vin=mkP('VIN',0,-400);vin.dc=C.vindc;vin.idc=C.vinI||0;parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!C.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
      for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
      state.parts=parts;state.wires=wires;state.realMode=!!C.real;state.std=false;state.tzoom=1;state.tolMode=false;state.fmin=1;state.fmax=1e9;assignNames();NET=netlist();if(!NET.ok)return{err:NET.err};update()}
    else if(J.ex){const b=document.createElement('button');b.dataset.ex=J.ex;document.getElementById('exList').appendChild(b);b.click();b.remove();closeAll();state.realMode=J.real;state.std=false;state.tolMode=false;circuitChanged()}
    else{const cir=J.cir;uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240];j++;return q};
      for(const e of cir.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.par=Object.assign({},e.par);if(e.k==='P'){q.pos=e.pos;add(e.w,q,2)}parts.push(q);add(e.a,q,0);add(e.b,q,1)}
      for(const u of cir.oas){const[x,y]=pos();const q=mkP('OA',x,y,0);q.par=Object.assign({},u.par);q.real=u.real;parts.push(q);add(u.p,q,0);add(u.n,q,1);add(u.o,q,2)}
      const vin=mkP('VIN',0,-400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
      for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
      state.parts=parts;state.wires=wires;state.realMode=cir.realMode;state.std=false;state.tolMode=false;
      const lo=Math.floor(Math.random()*4),hi=lo+3+Math.floor(Math.random()*5);state.fmin=Math.pow(10,lo);state.fmax=Math.pow(10,Math.min(10,hi));assignNames();NET=netlist();if(!NET.ok)return{err:NET.err};update()}
    if(!NET.ok||!data)return{err:NET.err||'nodata'};
    const pal=PRINT_PAL;const W=370,Hh=210;const res={};const isH=MODE()==='H';
    /* --- frequency plots (Bode and Ω tab) --- */
    for(const[tab,which]of[['bode','mag'],['bode','ph'],['ohm','mag'],['ohm','ph']]){const spec=series(tab,which);if(!spec)continue;const cv=document.createElement('canvas');cv.width=W;cv.height=Hh;
      window.__LOG=[];const g=drawFreq(cv,spec,pal,W,Hh,1,which==='mag');const L=window.__LOG;window.__LOG=null;if(!g)continue;
      const T=6,ph=Hh-6-18;const ticks=L.filter(e=>e.m==='fillText'&&e.ta==='right'&&Math.abs(e.a[1]-(g.L-5))<1e-9).map(e=>({y:e.a[2],v:__num(e.a[0]),s:e.a[0]}));
      const ylog=!!spec.ylog;const tv=ticks.map(t=>({y:t.y,v:ylog?Math.log10(t.v):t.v}));
      /* least-squares axis from the labels, and how well the labels agree with a straight axis */
      const n=tv.length;let sy=0,sv=0,syy=0,syv=0;for(const t of tv){sy+=t.y;sv+=t.v;syy+=t.y*t.y;syv+=t.y*t.v}const a=(n*syv-sy*sv)/(n*syy-sy*sy),b0=(sv-a*sy)/n;
      let labErr=0;for(const t of tv)labErr=Math.max(labErr,Math.abs((t.v-b0)/a-t.y));
      const toV=y=>a*y+b0,toY=v=>(v-b0)/a,fOf=x=>Math.pow(10,g.l0+(x-g.L)/g.pw*(g.l1-g.l0));
      const col=which==='ph'?pal.ph:pal.mag;const curves=__curves(L,col,2);
      const truth=f=>{const c=tab==='ohm'?solve(f,'zin'):resp(f);if(which==='mag')return tab==='ohm'?Math.log10(cx.abs(c)):20*Math.log10(cx.abs(c));return Math.atan2(c[1],c[0])*180/Math.PI};
      const near=(v,ref)=>{if(which!=='ph')return v;let d=v-ref;d-=360*Math.round(d/360);return ref+d};
      let vErr=0,vAt=null,mErr=0,mAt=null,nv=0,nm=0;const inPlot=y=>y>=T&&y<=T+ph;
      for(const c of curves){for(let k=0;k<c.length;k++){const[x,y]=c[k];if(!inPlot(y))continue;const f=fOf(x);const tv_=truth(f);if(!isFinite(tv_))continue;const yA=toY(near(truth(fOf(x-0.3)),toV(y))),yB=toY(near(truth(fOf(x+0.3)),toV(y)));if(!(Math.abs(yA-yB)<3))continue;const yv=toY(near(tv_,toV(y)));nv++;const e=Math.abs(yv-y);if(e>vErr){vErr=e;vAt=f}
          if(k>0){const[x0,y0]=c[k-1];if(!inPlot(y0)||Math.abs(x-x0)<0.25)continue;/* check 3 interior points of the segment */for(const u of[0.25,0.5,0.75]){const xm=x0+(x-x0)*u,ym=y0+(y-y0)*u;const tm=truth(fOf(xm));if(!isFinite(tm))continue;const yt=toY(near(tm,toV(ym)));if(!inPlot(yt))continue;{const yA=toY(near(truth(fOf(xm-0.3)),toV(ym))),yB=toY(near(truth(fOf(xm+0.3)),toV(ym)));if(!(Math.abs(yA-yB)<3))continue}nm++;const e2=Math.abs(yt-ym);if(e2>mErr){mErr=e2;mAt=fOf(xm)}}}}}
      res[tab+'_'+which]={labErr,vErr,vAt,mErr,mAt,nv,nm,ncurves:curves.length,nt:n,labels:ticks.map(t=>t.s).join(' ')}}
    /* --- Nyquist and Smith: geometric distance of the drawn path to the true curve --- */
    const dense=(fn,n)=>{const out=[];const l0=Math.log10(state.fmin),l1=Math.log10(state.fmax);for(let i=0;i<=n;i++)out.push(fn(Math.pow(10,l0+(l1-l0)*i/n)));return out};
    {const cv=document.createElement('canvas');cv.width=W;cv.height=W;window.__LOG=[];const g=drawNyq(cv,pal,W,W,1);const L=window.__LOG;window.__LOG=null;
      if(g){const xt=L.filter(e=>e.m==='fillText'&&e.ta==='center').map(e=>({p:e.a[1],v:__num(e.a[0])})),yt=L.filter(e=>e.m==='fillText'&&e.ta==='right').map(e=>({p:e.a[2],v:__num(e.a[0])}));
        const fit=t=>{const n=t.length;let sy=0,sv=0,syy=0,syv=0;for(const q of t){sy+=q.p;sv+=q.v;syy+=q.p*q.p;syv+=q.p*q.v}const a=(n*syv-sy*sv)/(n*syy-sy*sy),b=(sv-a*sy)/n;let e=0;for(const q of t)e=Math.max(e,Math.abs((q.v-b)/a-q.p));return{a,b,e}};
        const fx=fit(xt),fy=fit(yt);const T=8,Bt=W-20,Lx=46,Rx=W-10;
        const curves=__curves(L,pal.mag,2);const tr=dense(resp,40000).map(c=>[(c[0]-fx.b)/fx.a,(c[1]-fy.b)/fy.a]);
        /* distance of a pixel point to the true path (polyline of dense samples) */
        const segD=(P,A,B)=>{const dx=B[0]-A[0],dy=B[1]-A[1];const l=dx*dx+dy*dy;let u=l>0?((P[0]-A[0])*dx+(P[1]-A[1])*dy)/l:0;u=Math.max(0,Math.min(1,u));return Math.hypot(P[0]-A[0]-u*dx,P[1]-A[1]-u*dy)};
        const dist=P=>{let m=Infinity;for(let i=1;i<tr.length;i++){const A=tr[i-1],B=tr[i];if(!isFinite(A[0])||!isFinite(B[0]))continue;if(Math.min(A[0],B[0])>P[0]+m||Math.max(A[0],B[0])<P[0]-m||Math.min(A[1],B[1])>P[1]+m||Math.max(A[1],B[1])<P[1]-m)continue;m=Math.min(m,segD(P,A,B))}return m};
        const inP=P=>P[0]>=Lx&&P[0]<=Rx&&P[1]>=T&&P[1]<=Bt;let vE=0,mE=0;
        for(const c of curves)for(let k=0;k<c.length;k++){if(!inP(c[k]))continue;vE=Math.max(vE,dist(c[k]));if(k>0&&inP(c[k-1])){const M=[(c[k][0]+c[k-1][0])/2,(c[k][1]+c[k-1][1])/2];mE=Math.max(mE,dist(M))}}
        const sag=(R,fn,map)=>{if(!R)return null;let sm=0,vm=0;const segD=(P,A,B)=>{const dx=B[0]-A[0],dy=B[1]-A[1];const l=dx*dx+dy*dy;let u=l>0?((P[0]-A[0])*dx+(P[1]-A[1])*dy)/l:0;u=Math.max(0,Math.min(1,u));return Math.hypot(P[0]-A[0]-u*dx,P[1]-A[1]-u*dy)};
          for(let i=0;i<R.fs.length;i++){const v=R.v[i];if(!isFinite(v[0])||!isFinite(v[1]))continue;const A=map(v);const t=map(fn(R.fs[i]));vm=Math.max(vm,Math.hypot(A[0]-t[0],A[1]-t[1]));
            if(i+1<R.fs.length){const w=R.v[i+1];if(!isFinite(w[0])||!isFinite(w[1]))continue;const B=map(w);{const out=Q=>Q[0]<Lx-20*(Rx-Lx)||Q[0]>Rx+20*(Rx-Lx)||Q[1]<T-20*(Bt-T)||Q[1]>Bt+20*(Bt-T);if(out(A)&&out(B))continue}for(let k=1;k<8;k++){const f=R.fs[i]*Math.pow(R.fs[i+1]/R.fs[i],k/8);const P=map(fn(f));if(!isFinite(P[0])||!isFinite(P[1]))continue;
              if(Math.min(A[0],B[0],P[0])>Rx+50||Math.max(A[0],B[0],P[0])<Lx-50||Math.min(A[1],B[1],P[1])>Bt+50||Math.max(A[1],B[1],P[1])<T-50)continue;const dd=segD(P,A,B);if(dd>sm){sm=dd;window.__sagAt=[R.fs[i],R.fs[i+1],f,A,B,P,R.v[i],R.v[i+1],fn(f)]}}}}return{sm,vm,at:window.__sagAt}};
        const sg=sag(data._nyR,resp,c=>[(c[0]-fx.b)/fx.a,(c[1]-fy.b)/fy.a]);
        res.nyq={at:sg&&sg.at,labErr:Math.max(fx.e,fy.e),denseErr:vE,vErr:sg?sg.vm:vE,mErr:sg?sg.sm:mE,ncurves:curves.length,scaleRatio:fx.a/(-fy.a)}}}
    {const cv=document.createElement('canvas');cv.width=W;cv.height=W;window.__LOG=[];const g=drawSmith(cv,pal,W,W,1);const L=window.__LOG;window.__LOG=null;
      /* the unit circle (|Γ| = 1) is the largest circle drawn */
      const arcs=L.filter(e=>e.m==='arc'&&e.tr==='0,0');if(g!==null&&arcs.length){const uc=arcs.find(e=>Math.abs(e.lw-1.2)<1e-3);if(!uc)throw new Error("no unit circle");const cx0=uc.a[0],cy0=uc.a[1],R=uc.a[2];
        const curves=__curves(L,pal.mag,2);const Z0=state.z0;const tr=dense(f=>{const z=solve(f,'zin');if(!isFinite(z[0]))return[cx0+R,cy0];const G=cx.div(cx.sub(z,[Z0,0]),cx.add(z,[Z0,0]));return[cx0+R*G[0],cy0-R*G[1]]},40000);
        const segD=(P,A,B)=>{const dx=B[0]-A[0],dy=B[1]-A[1];const l=dx*dx+dy*dy;let u=l>0?((P[0]-A[0])*dx+(P[1]-A[1])*dy)/l:0;u=Math.max(0,Math.min(1,u));return Math.hypot(P[0]-A[0]-u*dx,P[1]-A[1]-u*dy)};
        const dist=P=>{let m=Infinity;for(let i=1;i<tr.length;i++){const A=tr[i-1],B=tr[i];if(Math.min(A[0],B[0])>P[0]+m||Math.max(A[0],B[0])<P[0]-m||Math.min(A[1],B[1])>P[1]+m||Math.max(A[1],B[1])<P[1]-m)continue;m=Math.min(m,segD(P,A,B))}return m};
        let vE=0,mE=0;for(const c of curves)for(let k=0;k<c.length;k++){vE=Math.max(vE,dist(c[k]));if(k>0){const M=[(c[k][0]+c[k-1][0])/2,(c[k][1]+c[k-1][1])/2];mE=Math.max(mE,dist(M))}}
        const S=data._smR;let sm=0,vm=0;const map=f=>{const z=solve(f,'zin');if(!isFinite(z[0])&&!isNaN(z[0]))return[cx0+R,cy0];const G=cx.div(cx.sub(z,[Z0,0]),cx.add(z,[Z0,0]));return[cx0+R*G[0],cy0-R*G[1]]};
        if(S)for(let i=0;i<S.fs.length;i++){const A=[cx0+R*S.v[i][0],cy0-R*S.v[i][1]];const t=map(S.fs[i]);vm=Math.max(vm,Math.hypot(A[0]-t[0],A[1]-t[1]));if(i+1<S.fs.length){const B=[cx0+R*S.v[i+1][0],cy0-R*S.v[i+1][1]];for(let k=1;k<8;k++){const P=map(S.fs[i]*Math.pow(S.fs[i+1]/S.fs[i],k/8));sm=Math.max(sm,segD(P,A,B))}}}
        res.smith={denseErr:vE,vErr:S?vm:vE,mErr:S?sm:mE,ncurves:curves.length,R}}}
    /* --- time plots: vertices vs the app's own time data on the label axis --- */
    const td=timeData();if(td)for(const which of['step','imp']){const cv=document.createElement('canvas');cv.width=W;cv.height=Hh;window.__LOG=[];const g=drawTime(cv,which,pal,W,Hh,1);const L=window.__LOG;window.__LOG=null;if(!g)continue;
      const yt=L.filter(e=>e.m==='fillText'&&e.ta==='right').map(e=>({p:e.a[2],v:__num(e.a[0])})).filter(q=>isFinite(q.v));const xt=L.filter(e=>e.m==='fillText'&&e.ta==='center').map(e=>({p:e.a[1],v:__num(e.a[0])})).filter(q=>isFinite(q.v));
      const fit=t=>{const n=t.length;let sy=0,sv=0,syy=0,syv=0;for(const q of t){sy+=q.p;sv+=q.v;syy+=q.p*q.p;syv+=q.p*q.v}const a=(n*syv-sy*sv)/(n*syy-sy*sy),b=(sv-a*sy)/n;let e=0;for(const q of t)e=Math.max(e,Math.abs((q.v-b)/a-q.p));return{a,b,e}};
      const fy=fit(yt),fx=fit(xt.filter(q=>q.p>g.L+12&&q.p<g.L+g.pw-20));const ys=which==='step'?td.ys:td.imp;
      const curves=__curves(L,which==='step'?pal.mag:pal.ph,2);let vE=0,vAt=null;
      /* every drawn vertex must lie within the range of the true response over its pixel column (x ± 0.5 px): exact model evaluated
         densely when there is one, else the samples; the time axis is the drawing's own (t = (x − L)/pw·T) */
      const fn=td.an?(which==='step'?td.an.y:td.an.dy):null;const band=(t0,t1)=>{let a=Infinity,b=-Infinity;const sub=fn?1024:24;const pts=[];for(let j=0;j<=sub;j++)pts.push(t0+(t1-t0)*j/sub);if(fn&&t0<td.h)for(let j=0;j<=40;j++)pts.push(t0*Math.pow(Math.max(t1,td.h)/t0,j/40));for(const t of pts){if(t<=0||t>td.T)continue;const v=fn?fn(t):tAt(ys,td.h,t);if(v<a)a=v;if(v>b)b=v}
        /* the samples in the column are values of the response too (a dense grid can miss the peaks of oscillations much faster than a pixel) */
        for(let k=Math.max(1,Math.ceil(t0/td.h));k*td.h<=t1&&k<ys.length;k++){a=Math.min(a,ys[k]);b=Math.max(b,ys[k])}return[a,b]};
      /* vertices outside the plot rectangle are clipped away by the drawing (fast transients right after t = 0 may run off the plot) */
      const fr=L.filter(e=>e.m==='strokeRect').pop();const pT=fr?fr.a[1]-0.5:6,pB=fr?fr.a[1]+fr.a[3]+0.5:Hh-18;
      for(const c of curves)for(let k=1;k<c.length;k++){const[x,y]=c[k];if(y<6||y>Hh-18||y<pT||y>pB)continue;const t0=(x-0.5-g.L)/g.pw*g.T,t1=(x+0.5-g.L)/g.pw*g.T;if(t1<=td.h)continue;const[a,b]=band(Math.max(t0,fn?1e-12*td.T:td.h*0.5),t1);
        const ya=(a-fy.b)/fy.a,yb=(b-fy.b)/fy.a;const lo=Math.min(ya,yb),hi=Math.max(ya,yb);const e=y<lo?lo-y:y>hi?y-hi:0;if(e>vE){vE=e;vAt=(x-g.L)/g.pw;if(window.__DBGT)window.__vdet={which,x,y,lo,hi,t0,t1,a,b,k,prev:c[k-1],next:c[k+1],pT,pB,h:td.h,env:!!td._env}}}
      res[which]={labErrY:fy.e,labErrX:fx.e,tScale:fx.a*g.pw/td.T,vErr:vE,vAt,ncurves:curves.length};if(window.__DBGT){res[which].det=window.__vdet;window.__vdet=null}if(window.__DBGT&&which==='step')res.dbgT={c0:curves[0]&&curves[0].slice(0,6),ys:Array.from(ys.slice(0,6)),h:td.h,T:td.T,an:!!td.an,jump:td.jump,y0:td.y0,fy:[fy.a,fy.b],g}}
    /* --- poles/zeros: marker centres vs the values --- */
    const pz=getPZ();if(pz){const cv=document.createElement('canvas');cv.width=W;cv.height=W;window.__LOG=[];const g=drawPZ(cv,pal,W,W,1);const L=window.__LOG;window.__LOG=null;
      if(g){const xt=L.filter(e=>e.m==='fillText'&&e.ta==='center').map(e=>({p:e.a[1],v:__num(e.a[0])})).filter(q=>isFinite(q.v)),yt=L.filter(e=>e.m==='fillText'&&e.ta==='left'&&/^j/.test(e.a[0])).map(e=>({p:e.a[2],v:__num(e.a[0])})).filter(q=>isFinite(q.v));
        const fit=t=>{const n=t.length;if(n<2)return null;let sy=0,sv=0,syy=0,syv=0;for(const q of t){sy+=q.p;sv+=q.v;syy+=q.p*q.p;syv+=q.p*q.v}const a=(n*syv-sy*sv)/(n*syy-sy*sy),b=(sv-a*sy)/n;let e=0;for(const q of t)e=Math.max(e,Math.abs((q.v-b)/a-q.p));return{a,b,e}};
        const fx=fit(xt),fy=fit(yt);let mk=0,mE=0;
        if(fx&&fy){const ys_=L.filter(e=>e.m==='arc'&&Math.abs(e.a[2]-6)<1e-9);const xs_=[];for(let k=0;k<L.length-3;k++){const e=L[k];if(e.m==='moveTo'&&L[k+1].m==='lineTo'&&Math.abs(L[k+1].a[0]-e.a[0]-12)<1e-9&&Math.abs(L[k+1].a[1]-e.a[1]-12)<1e-9)xs_.push([e.a[0]+6,e.a[1]+6])}
          const chk=(P,list)=>{for(const q of list){const x=(q[0]-fx.b)/fx.a,y=(q[1]-fy.b)/fy.a;if(x<10||x>W-10||y<8||y>W-10)continue;let best=Infinity;for(const m of P)best=Math.min(best,Math.hypot(m[0]-x,m[1]-y));mk++;mE=Math.max(mE,best)}};
          chk(xs_,pz.poles);chk(ys_.map(e=>[e.a[0],e.a[1]]),pz.zeros)}
        res.pz={labErr:fx&&fy?Math.max(fx.e,fy.e):null,markers:mk,mErr:mE,aspect:fx&&fy?fx.a/(-fy.a):null}}}
    return{res,mode:MODE(),fmin:state.fmin,fmax:state.fmax}},J);
  rows.push({name:J.name,cir:J.cir,...r})}
fs.writeFileSync(__dirname+'/gtest.json',JSON.stringify(rows));
const w={};const bad=[];for(const r of rows){if(r.err)continue;for(const k in r.res){const q=r.res[k];for(const m of['labErr','vErr','mErr','labErrY','labErrX']){if(q[m]==null)continue;const key=k+'.'+m;if(!w[key]||q[m]>w[key][0])w[key]=[q[m],r.name]}
    if((q.vErr>2)||(q.mErr>2)||(q.labErr>1.01)||(q.labErrY>1.01)||(q.labErrX>1.01)||(k==='nyq'&&Math.abs(q.scaleRatio-1)>0.02)||(k==='pz'&&q.aspect&&Math.abs(q.aspect-1)>0.02)||(q.tScale&&Math.abs(q.tScale-1)>0.02))bad.push([r.name,k,JSON.stringify(q).slice(0,300)])}}
if(process.env.DBGT)rows.forEach(r=>{if(r.res&&r.res.dbgT)console.log(r.name||'',JSON.stringify(r.res.dbgT))});
console.log('circuits',rows.length,'errors',rows.filter(r=>r.err).length);for(const k of Object.keys(w).sort())console.log(k.padEnd(18),w[k][0].toFixed(3),'px  (',w[k][1],')');
console.log('flagged',bad.length);bad.slice(0,60).forEach(x=>console.log(' ',x.join(' | ')));console.log('pageerrors',errs.slice(0,5));await b.close()})();
