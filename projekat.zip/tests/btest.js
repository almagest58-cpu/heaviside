const { chromium } = require('playwright');const fs=require('fs');const {hpSolve}=require('./hp.js');
const C={abs:a=>Math.hypot(a[0],a[1]),sub:(a,b)=>[a[0]-b[0],a[1]-b[1]]};
let seed=+(process.env.SEED||4242);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const parOf=k=>k==='C'?{esr:logU(1e-3,1),esl:logU(1e-10,1e-8),rp:rnd()<0.5?1e12:logU(1e5,1e9)}:k==='R'?{ls:logU(1e-10,1e-7),cp:logU(1e-14,1e-11)}:{rdc:logU(1e-2,10),cp:logU(1e-13,1e-10)};
const val=k=>k==='R'?logU(1,1e5):k==='L'?logU(1e-7,1e-1):logU(1e-11,1e-4);
const el=(a,b,k,v)=>({a,b,k,v:v===undefined?val(k):v,par:parOf(k)});
function randomCircuit(E){const zmode=rnd()<0.2;const nInt=Math.max(0,Math.round(E*0.5)-(zmode?2:3));const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:nInt},(_,j)=>'n'+j)];
  const order=nodes.slice().sort(()=>rnd()-0.5);const edges=[];for(let j=1;j<order.length;j++)edges.push(el(order[j],pick(order.slice(0,j)),pick(['R','L','C'])));
  while(edges.length<E){const a=pick(nodes),b=pick(nodes);if(a!==b)edges.push(el(a,b,pick(['R','L','C'])))}return{name:'random '+E,zmode,edges}}
function ladder(){const e=[el('i','x0','R',50)];let prev='x0';for(let j=0;j<14;j++){const n='y'+j;e.push(el(prev,n,'L',1e-6*(1+j%3)));e.push(el(n,'g','C',1e-9*(1+(j*7)%4)));prev=n}e.push(el(prev,'o','L',1e-6));e.push(el('o','g','R',50));return{name:'LC ladder 31 el.',zmode:false,edges:e}}
function decaps(){const e=[el('i','x','R',0.01),el('x','v','L',2e-9)];const cs=[1e-4,4.7e-5,1e-5,4.7e-6,1e-6,4.7e-7,1e-7,4.7e-8,1e-8,1e-9];cs.forEach((c,j)=>e.push(el('v','g','C',c)));return{name:'10 decaps + supply (12 el.)',zmode:true,edges:e}}
function rcChain(){const e=[];let prev='i';for(let j=0;j<15;j++){const n=j===14?'o':'r'+j;e.push(el(prev,n,'R',1e3*(1+j%2)));e.push(el(n,'g','C',1e-8*(1+j%3)));prev=n}return{name:'RC chain 30 el.',zmode:false,edges:e}}
function mesh(){const N=['i','o','g','m0','m1','m2','m3','m4','m5','m6','m7'];const e=[];for(let j=1;j<N.length;j++)e.push(el(N[j],N[j-1],pick(['R','L','C'])));while(e.length<30){const a=pick(N),b=pick(N);if(a!==b)e.push(el(a,b,pick(['R','L','C'])))}return{name:'dense mesh 30 el.',zmode:false,edges:e}}
function expand(edges,real){if(!real)return edges;const out=[];let c=0;for(const e of edges){const m=()=>'x_'+(c++);const p=e.par;
  if(e.k==='C'){const m1=m(),m2=m();out.push({a:e.a,b:m1,k:'R',v:p.esr},{a:m1,b:m2,k:'L',v:p.esl},{a:m2,b:e.b,k:'C',v:e.v});if(p.rp<1e12)out.push({a:m2,b:e.b,k:'R',v:p.rp})}
  else{const q=m();if(e.k==='R')out.push({a:e.a,b:q,k:'R',v:e.v},{a:q,b:e.b,k:'L',v:p.ls});else out.push({a:e.a,b:q,k:'R',v:p.rdc},{a:q,b:e.b,k:'L',v:e.v});out.push({a:e.a,b:e.b,k:'C',v:p.cp})}}return out}
const list=[];
for(const E of[10,15,20,25,30])for(let r=0;r<6;r++){const c=randomCircuit(E);list.push({...c,real:false});list.push({...JSON.parse(JSON.stringify(c)),real:true})}
for(const f of[ladder,decaps,rcChain,mesh]){const c=f();list.push({...c,real:false});list.push({...JSON.parse(JSON.stringify(c)),real:true})}
const FS=Array.from({length:10},(_,i)=>Math.pow(10,i));// 1 Hz .. 1 GHz
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html')+'',{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(500);
const rows=[];
for(const cir of list){
  const r=await p.evaluate(({cir,FS})=>{uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};
    cir.edges.forEach((e,j)=>{const q=mkP(e.k,(j%8)*200,Math.floor(j/8)*200,0,e.v);q.par=Object.assign({},e.par);parts.push(q);add(e.a,q,0);add(e.b,q,1)});
    const vin=mkP('VIN',0,-400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
    for(const k in term){const L=term[k];for(let j=1;j<L.length;j++)wires.push(W_(L[j-1][0],L[j-1][1],L[j][0],L[j][1]))}
    state.parts=parts;state.wires=wires;state.realMode=cir.real;state.fmin=1;state.fmax=1e9;state.cursor=1000;assignNames();NET=netlist();
    if(!NET.ok)return{net:NET.err};
    let t0=performance.now();update();const tUpd=performance.now()-t0;
    t0=performance.now();for(let k=0;k<3;k++)update();const tUpd3=(performance.now()-t0)/3;
    const app=FS.map(f=>resp(f)),appZ=FS.map(f=>solve(f,'zin'));
    t0=performance.now();let h='';let status='';try{h=derive()}catch(e){status='EXC '+e.message}const tDer=performance.now()-t0;
    if(!status)status=DER?(/too long to display/.test(h)?'formula (parts too long to show)':'formula OK'):/too complex/.test(h)?'too complex':/more than|nodes|čvor/i.test(h)?'too many nodes':'no formula';
    let F1=null;if(DER){const w=f=>2*Math.PI*f;F1=FS.map(f=>cx.div(spValJ(DER.FR.N,w(f),DER.vals),spValJ(DER.FR.D,w(f),DER.vals)))}
    t0=performance.now();let secErr='';for(const g of['nyq','spec','smith']){try{deriveFor(g)}catch(e){secErr+=g+':'+e.message}}const tSec=performance.now()-t0;
    return{app,appZ,F1,status,secErr,tUpd,tUpd3,tDer,tSec,nEdges:NET.edges.length,nNodes:NET.nodes.length,mode:NET.mode}},{cir,FS});
  if(r.net){rows.push({name:cir.name,real:cir.real,err:r.net});continue}
  const ex=expand(cir.edges,cir.real);const t0=Date.now();const ref=FS.map(f=>hpSolve(ex,f,cir.zmode)),refZ=FS.map(f=>hpSolve(ex,f,true));const tRef=Date.now()-t0;
  const metr=(a,bb)=>{const mx=Math.max(...bb.map(C.abs).filter(isFinite));let rel=0,dB=0,ph=0;a.forEach((x,i)=>{const y=bb[i],ay=C.abs(y);if(!(ay>0)||!isFinite(ay))return;
      const e=C.abs(C.sub(x,y))/Math.max(ay,1e-9*mx);rel=Math.max(rel,isFinite(e)?e:Infinity);
      if(ay>mx*1e-10){dB=Math.max(dB,Math.abs(20*Math.log10(C.abs(x)/ay)));let d=Math.atan2(x[1],x[0])-Math.atan2(y[1],y[0]);d=Math.abs(Math.atan2(Math.sin(d),Math.cos(d)))*180/Math.PI;ph=Math.max(ph,d)}});return{rel,dB,ph}};
  const g=metr(r.app,ref),gz=metr(r.appZ,refZ);const fm=r.F1?metr(r.F1,ref):null;
  const minDb=Math.min(...ref.map(y=>20*Math.log10(C.abs(y)||1e-300)));
  const row={name:cir.name,real:cir.real,elems:cir.edges.length,internal:r.nEdges,nodes:r.nNodes,mode:r.mode,graphRel:Math.max(g.rel,gz.rel),graphDb:Math.max(g.dB,gz.dB),graphPh:Math.max(g.ph,gz.ph),minDb,formula:r.status,formulaRel:fm?fm.rel:null,secErr:r.secErr,tUpd:Math.round(r.tUpd),tUpd3:Math.round(r.tUpd3),tDer:Math.round(r.tDer),tSec:Math.round(r.tSec),tRef};
  rows.push(row);fs.appendFileSync('btest.progress',JSON.stringify(row)+'\n')}
fs.writeFileSync('btest.json',JSON.stringify({rows,errs},null,1));console.log('done',rows.length,'pageerrors',errs.length);await b.close()})();
