// DC operating point: semi.js vs ngspice .op on random circuits
const {dcSolve,VT,dcResidual,devImax}=require('./semi.js');const fs=require('fs'),cp=require('child_process');
const NG=process.env.NGSPICE||'ngspice';const WD=fs.mkdtempSync('/tmp/op-');
/* ngspice uses old constants: choose its temperature so that its VT equals ours (TNOM = TEMP: no parameter scaling) */
const TK=VT*1.6021918e-19/1.3806226e-23,TC=TK-273.15;
let seed=+(process.env.SEED||1);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
function gen(){const n=3+Math.floor(rnd()*6);const D={n,R:[],V:[],I:[],nul:[],vcvs:[],dev:[]};const nodes=[-1,...Array.from({length:n},(_,i)=>i)];
  for(let i=0;i<n;i++){D.R.push({a:i,b:pick(nodes.filter(x=>x!==i)),g:1/logU(100,1e6)})}
  for(let k=0;k<Math.floor(rnd()*n);k++){const a=pick(nodes),b=pick(nodes);if(a!==b)D.R.push({a,b,g:1/logU(10,1e6)})}
  const nV=1+Math.floor(rnd()*2);const usedV=new Set();for(let k=0;k<nV;k++){const a=pick(nodes.slice(1).filter(x=>!usedV.has(x)));if(a===undefined)break;usedV.add(a);D.V.push({a,b:-1,v:(rnd()<0.5?1:-1)*logU(0.5,20)})}
  if(rnd()<0.35){const free=nodes.slice(1).filter(x=>!usedV.has(x));if(free.length){const o=pick(free);usedV.add(o);const p=pick(nodes),q=pick(nodes);if(p!==q)D.vcvs.push({p,n:q,o,a0:pick([1e4,1e5,2e5,1e6])});else usedV.delete(o)}}
  if(rnd()<0.3){const a=pick(nodes),b=pick(nodes);if(a!==b)D.I.push({a,b,i:(rnd()<0.5?1:-1)*logU(1e-5,1e-2)})}
  const nd=1+Math.floor(rnd()*4);for(let k=0;k<nd;k++){const t=pick(['D','Q','Q','M']);const three=()=>{const s=new Set();while(s.size<3)s.add(pick(nodes));return[...s]};
    if(t==='D'){const[a,b]=three();D.dev.push({t,a,k:b,par:{is:pick([1e-14,1e-7,2.5e-9]),n:pick([1,1,1.8])}})}
    else if(t==='Q'){const[c,b,e]=three();D.dev.push({t,c,b,e,pol:pick([1,-1]),par:{is:pick([1e-15,1e-14,1e-16]),bf:logU(50,400),br:pick([1,2,5]),va:pick([Infinity,50,100,200])}})}
    else{const[d,g,s]=three();const pol=pick([1,-1]);D.dev.push({t,d,g,s,pol,par:{vth:pol*logU(0.4,2),k:logU(1e-4,1e-1),lam:pick([0,0.01,0.05])}})}}
  return D}
function spice(D,tag,ns){const nn=i=>i<0?'0':'n'+i;const L=['* op','.options reltol=1e-10 vntol=1e-14 abstol=1e-22 itl1=500 temp='+TC.toPrecision(15)+' tnom='+TC.toPrecision(15)];
  D.R.forEach((e,j)=>L.push(`R${j} ${nn(e.a)} ${nn(e.b)} ${(1/e.g).toPrecision(17)}`));D.V.forEach((e,j)=>L.push(`V${j} ${nn(e.a)} ${nn(e.b)} DC ${e.v.toPrecision(17)}`));
  D.vcvs.forEach((e,j)=>L.push(`E${j} ${nn(e.o)} 0 ${nn(e.p)} ${nn(e.n)} ${e.a0}`));D.I.forEach((e,j)=>L.push(`I${j} ${nn(e.a)} ${nn(e.b)} DC ${e.i.toPrecision(17)}`));
  D.dev.forEach((d,j)=>{if(d.t==='D'){L.push(`D${j} ${nn(d.a)} ${nn(d.k)} DM${j}`,`.model DM${j} D(IS=${d.par.is} N=${d.par.n})`)}
    else if(d.t==='Q'){L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${d.par.is} BF=${d.par.bf.toPrecision(17)} BR=${d.par.br}${isFinite(d.par.va)?' VAF='+d.par.va:''})`)}
    else{L.push(`M${j} ${nn(d.d)} ${nn(d.g)} ${nn(d.s)} ${nn(d.s)} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${d.par.vth.toPrecision(17)} KP=${d.par.k.toPrecision(17)} LAMBDA=${d.par.lam} IS=0 GAMMA=0)`)}});
  if(ns)L.push('.nodeset '+ns.slice(0,D.n).map((v,i)=>`v(${nn(i)})=${(+v).toPrecision(17)}`).join(' '));L.push('.control','set numdgt=16','op','print '+Array.from({length:D.n},(_,i)=>'v('+nn(i)+')').join(' '),'quit','.endc','.end');fs.writeFileSync(`${WD}/${tag}.cir`,L.join('\n'));
  let out;try{out=cp.execFileSync(NG,['-b',`${WD}/${tag}.cir`],{timeout:30000,stdio:['ignore','pipe','ignore']}).toString()}catch(e){return null}
  const v=[];for(let i=0;i<D.n;i++){const m=out.match(new RegExp('v\\(n'+i+'\\) = ([-+0-9.e]+)'));v.push(m?+m[1]:NaN)}if(/doAnalyses|singular|Timestep|failed/i.test(out)&&v.some(isNaN))return null;return v}
const N=+(process.env.N||300);let nFloat=0,nMulti=0,nLoose=0,nAbs=0,worst=0,nOK=0,nFailApp=0,nFailSp=0,bad=[];
for(let it=0;it<N;it++){const D=gen();const r=dcSolve(D);const sp=spice(D,'c'+it);
  if(!sp||sp.some(isNaN)){nFailSp++;if(!r.ok)continue;continue}
  if(!r.ok){const im=devImax(D,sp);if(im>1||sp.some(v=>Math.abs(v)>1e4)||r.msg==='overcurrent'||r.msg==='overvoltage'){nAbs++;continue}if(r.msg==='floating'){nFloat++;continue}if(false){nAbs++;continue}nFailApp++;bad.push(['appfail',it,'resSpice',dcResidual(D,sp).toExponential(1),'Imax',im.toExponential(1)]);continue}
  let e=0;for(let i=0;i<D.n;i++){const d=Math.abs(r.x[i]-sp[i]);const sc=Math.max(Math.abs(sp[i]),1e-3);e=Math.max(e,d/sc)}
  nOK++;if(e>1e-6&&!r.loose){}else if(r.loose){nLoose++;if(process.env.SHOWL)console.log('loose',it,r.how,e.toExponential(1),r.res.toExponential(1),dcResidual(D,sp).toExponential(1))}else worst=Math.max(worst,e);if(e>(r.loose?1e-3:1e-6)){const sp2=spice(D,'c'+it+'n',Array.from(r.x));let e2=Infinity;if(sp2&&!sp2.some(isNaN)){e2=0;for(let i=0;i<D.n;i++)e2=Math.max(e2,Math.abs(r.x[i]-sp2[i])/Math.max(Math.abs(sp2[i]),1e-3))}if(e2<1e-6||(dcResidual(D,Array.from(r.x).slice(0,D.n))<1e-9&&dcResidual(D,sp)<1e-9)){nMulti++;continue}}if(e>(r.loose?1e-3:1e-6))bad.push(['diff',it,e.toExponential(2),r.how,'resApp',dcResidual(D,r.x).toExponential(1),'resSpice',dcResidual(D,sp).toExponential(1)])}
console.log('circuits',N,'compared',nOK,'app fail',nFailApp,'absurd(>1A)',nAbs,'ngspice fail',nFailSp,'worst rel',worst.toExponential(2),'loose',nLoose,'floating(refused)',nFloat,'multiOP(ngspice confirms app OP via nodeset)',nMulti);console.log(JSON.stringify(bad.slice(0,30)))
