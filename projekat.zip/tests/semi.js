/* ================= semiconductors: device models and DC operating point =================
   Models (identical equations to SPICE/ngspice, so results can be checked against it):
   diode  — Shockley: I = IS·(e^(V/(N·VT)) − 1); below −3·N·VT the SPICE cubic reverse form; capacitance C_d = CJ0 + TT·g_d
   BJT    — Gummel–Poon with IS, β_F, β_R, V_A (forward Early voltage), I_KF (high injection, real model only); NPN/PNP.
            Ideal: constant C_π, C_μ. Real: r_b, r_c, r_e, C_je(V), C_jc(V), τ_F, τ_R (charges as in SPICE)
   MOSFET — Shichman–Hodges (SPICE level 1) with V_th, k = μC_ox·W/L, λ; bulk tied to the source; N/P. Capacitances C_gs, C_gd
   VT = kT/q at 27 °C with the exact SI constants. */
const SEMI_K=1.380649e-23,SEMI_Q=1.602176634e-19,SEMI_T=300.15,VT=SEMI_K*SEMI_T/SEMI_Q;
/* like SPICE, a tiny conductance GMIN = 1e-12 S is part of every pn junction (also the MOSFET drain–bulk junction): it keeps a node
   that is only reached through an off junction defined, and changes nothing measurable */
const GMIN=1e-12;
/* junction exponential with the SPICE reverse-bias form (smooth, keeps the current bounded): returns [I, dI/dV] */
function junc(v,is,nvt){if(v>=-3*nvt){const e=Math.exp(Math.min(v/nvt,700));return[is*(e-1),is*e/nvt]}
  let a=3*nvt/(v*Math.E);a=a*a*a;return[-is*(1+a),is*3*a/v]}
/* device evaluation: terminal voltages → terminal currents (into the device) and their Jacobian */
/* reverse breakdown (Zener) as in SPICE: the voltage where the breakdown exponential starts is shifted from BV so that the current at
   V = −BV equals IBV (iterated like ngspice diotemp.c). bv = 0: no breakdown */
function diodeBrk(par){if(!(par.bv>0))return 0;const nbv=(par.nbv||par.n||1)*VT,is=par.is,bv=par.bv;let cbv=par.ibv>0?par.ibv:1e-3;
  if(cbv<is*bv/VT)return bv;let xbv=bv-nbv*Math.log(1+cbv/is);for(let k=0;k<100;k++){const x2=bv-nbv*Math.log(cbv/is+1-xbv/VT);if(Math.abs(x2-xbv)<=1e-15*bv){xbv=x2;break}xbv=x2}return xbv}
function evalDiode(dv,par){const n=par.n||1,nvt=n*VT;let i,g;
  if(par.xbv>0&&dv<-3*nvt&&dv<-par.xbv){const nb=(par.nbv||n)*VT;const e=Math.exp(Math.min(-(par.xbv+dv)/nb,700));i=-par.is*e;g=par.is*e/nb}
  else[i,g]=junc(dv,par.is,nvt);return{i:i+GMIN*dv,g:g+GMIN}}
/* BJT, pol = +1 NPN, −1 PNP. vbe, vbc are the "physical" (pol-multiplied) voltages. Returns ic, ib (into C and B, pol applied back)
   and derivatives w.r.t. the terminal voltage differences Vbe, Vbc as seen in the circuit */
/* diac (behavioural, current-controlled): V = f(I), odd in I; par = {vbo, ibo, m, A, ron, tau, cj} from diacPar.
   |I| ≤ I_BO (blocking): f = V_BO·(1 − (1 − u)^m), u = |I|/I_BO; f rises steeply from 0 and is flat at the breakover point.
   |I| > I_BO (breakback, negative resistance): f = V_BO − (A/2)·ln(1 + w²) + R_on·I_BO·w, w = u − 1 (smooth at the peak, then a
   logarithmic fall to V_BO − ΔV at I_k, and the bulk resistance R_on at large currents). Returns {v, g = dV/dI} */
function evalDiac(I,p){const s=I<0?-1:1,u=Math.abs(I)/p.ibo;let v,g;
  if(u<=1){const w=1-u,wm=Math.pow(w,p.m-1);v=p.vbo*(1-wm*w);g=p.vbo*p.m*wm/p.ibo}
  else{const w=u-1;v=p.vbo-0.5*p.A*Math.log1p(w*w)+p.ron*p.ibo*w;g=-p.A*w/((1+w*w)*p.ibo)+p.ron}
  return{v:s*v,g}}
/* stored "flux" of the diac's carriers: ψ = τ·A·ln(1 + |I|/I_BO) (sign of I); the current cannot jump, it follows within ~τ */
function diacPsi(I,p){const a=Math.abs(I);return{q:(I<0?-1:1)*p.tau*p.A*Math.log1p(a/p.ibo),l:p.tau*p.A/(p.ibo+a)}}
/* Newton limiting of a diac current: it may at most double (plus I_BO) per iteration */
function diacLim(inew,iold,ibo){const a=Math.abs(inew),c=2*Math.abs(iold)+ibo;return a>c?(inew<0?-c:c):inew}
function evalBJT(Vbe,Vbc,par,pol){const vbe=pol*Vbe,vbc=pol*Vbc;const[cbe,gbe]=junc(vbe,par.is,VT),[cbc,gbc]=junc(vbc,par.is,VT);/* GMIN sits in the base leakage terms, as in SPICE bjtload (cben, cbcn) */
  const vaf=par.va>0&&isFinite(par.va)?par.va:Infinity;let arg=1-(isFinite(vaf)?vbc/vaf:0);if(arg<1e-4)arg=1e-4;const q1=1/arg;
  /* base charge q_b: Early effect (q1) and, in the real model, high injection with the knee current I_KF (SPICE: q2 = cbe/IKF, IKR = ∞) */
  const oik=par.ikf>0&&isFinite(par.ikf)?1/par.ikf:0;let qb,dqbdve,dqbdvc;
  if(!oik){qb=q1;dqbdve=0;dqbdvc=isFinite(vaf)?q1*qb/vaf:0}
  else{const q2=oik*cbe;const a=Math.max(0,1+4*q2);const sq=a!==0?Math.sqrt(a):1;qb=q1*(1+sq)/2;dqbdve=q1*oik*gbe/sq;dqbdvc=isFinite(vaf)?q1*qb/vaf:0}
  const bf=par.bf,br=par.br||1;
  const ic=(cbe-cbc)/qb-cbc/br-GMIN*vbc,ib=cbe/bf+cbc/br+GMIN*(vbe+vbc);
  const dic_dvbe=(gbe-(cbe-cbc)*dqbdve/qb)/qb,dic_dvbc=(-gbc)/qb-(cbe-cbc)*dqbdvc/(qb*qb)-gbc/br-GMIN;
  const dib_dvbe=gbe/bf+GMIN,dib_dvbc=gbc/br+GMIN;
  /* currents into the terminals: ic, ib; derivatives w.r.t. circuit Vbe, Vbc: pol·pol = 1. cbe, gbe, cbc, gbc, qb and its derivatives
     are also returned for the charges of the real model */
  return{ic:pol*ic,ib:pol*ib,dic_be:dic_dvbe,dic_bc:dic_dvbc,dib_be:dib_dvbe,dib_bc:dib_dvbc,cbe,cbc,gbe,gbc,qb,dqbdve,dqbdvc}}
/* MOSFET level 1, pol = +1 N, −1 P; returns drain current (into D) and derivatives w.r.t. circuit Vgs, Vds */
function evalMOS(Vgs,Vds,par,pol){let vgs=pol*Vgs,vds=pol*Vds;let mode=1;if(vds<0){mode=-1;vgs=vgs-vds;vds=-vds}/* drain and source swap roles */
  const vth=pol*par.vth,k=par.k,lam=par.lam||0;const vgst=vgs-vth;let id=0,gm=0,gds=0;
  if(vgst>0){const bp=k*(1+lam*vds);if(vgst<=vds){id=bp*vgst*vgst*0.5;gm=bp*vgst;gds=lam*k*vgst*vgst*0.5}
    else{id=bp*vds*(vgst-0.5*vds);gm=bp*vds;gds=bp*(vgst-vds)+lam*k*vds*(vgst-0.5*vds)}}
  const gj=GMIN*Vds;/* drain–bulk junction conductance (bulk = source) */
  if(mode===1)return{id:pol*id+gj,dvgs:gm,dvds:gds+GMIN,region:vgst<=0?'off':vgst<=vds?'sat':'lin'};
  /* reversed: the physical source is the circuit drain. I_D(circuit) = −id(vgs' = vgd, vds' = −vds) */
  return{id:-pol*id+gj,dvgs:-gm,dvds:gm+gds+GMIN,region:vgst<=0?'off':vgst<=vds?'sat':'lin',rev:true}}
/* SPICE voltage limiting for junctions and FET gate voltages (keeps Newton from overshooting the exponential) */
function pnjlim(vnew,vold,vt,vcrit){if(vnew>vcrit&&Math.abs(vnew-vold)>2*vt){if(vold>0){const a=1+(vnew-vold)/vt;vnew=a>0?vold+vt*Math.log(a):vcrit}else vnew=vt*Math.log(Math.max(vnew/vt,1e-300))}return vnew}
function fetlim(vnew,vold,vto){const vtsthi=Math.abs(2*(vold-vto))+2,vtstlo=vtsthi/2+2,vtox=vto+3.5,delv=vnew-vold;
  if(vold>=vto){if(vold>=vtox){if(delv<=0){if(vnew>=vtox){if(-delv>vtstlo)vnew=vold-vtstlo}else vnew=Math.max(vnew,vto+2)}else if(delv>=vtsthi)vnew=vold+vtsthi}
    else{if(delv<=0)vnew=Math.max(vnew,vto-0.5);else vnew=Math.min(vnew,vto+4)}}
  else{if(delv<=0){if(-delv>vtsthi)vnew=vold-vtsthi}else{const vtemp=vto+0.5;if(vnew<=vtemp){if(delv>vtstlo)vnew=vold+vtstlo}else vnew=vtemp}}return vnew}
/* DC netlist D: {n (number of non-ground nodes; ground = -1), R:[{a,b,g}], V:[{a,b,v}], I:[{a,b,i}] (current i flows from a through the
   source to b), nul:[{p,n,o}] (ideal op-amp), vcvs:[{p,n,o,a0}], dev:[{t:'D',a,k,par}|{t:'Q',c,b,e,pol,par}|{t:'M',d,g,s,pol,par}]}
   returns {ok, x (node voltages), it, msg} */
/* nodes with no DC path to ground. Paths: resistors, voltage sources, op-amp/VCVS outputs (driven to ground), diode, BJT (all three
   terminals), MOSFET drain–source. Not paths: current sources, MOSFET gate. Returns {float:[node...], devFloat: bool} */
function dcFloating(D){D.xf=D.xf||[];const n=D.n,par=Array.from({length:n+1},(_,i)=>i);const f=i=>{i=i<0?n:i;while(par[i]!==i){par[i]=par[par[i]];i=par[i]}return i};const u=(a,b)=>{par[f(a)]=f(b)};
  for(const e of D.R)u(e.a,e.b);for(const e of D.V)u(e.a,e.b);for(const e of D.nul.concat(D.vcvs))u(e.o,-1);for(const e of D.xf){u(e.p1,e.n1);u(e.p2,e.n2)}
  for(const d of D.dev){if(d.t==='D')u(d.a,d.k);else if(d.t==='X')u(d.a,d.b);else if(d.t==='Q'){u(d.b,d.e);u(d.c,d.e)}else u(d.d,d.s)}
  const g=f(-1),fl=[];for(let i=0;i<n;i++)if(f(i)!==g)fl.push(i);const fs=new Set(fl);
  const devFloat=D.dev.some(d=>(d.t==='D'?[d.a,d.k]:d.t==='X'?[d.a,d.b]:d.t==='Q'?[d.c,d.b,d.e]:[d.d,d.g,d.s]).some(i=>fs.has(i)));return{float:fl,devFloat}}
function dcSolve(D,opts){opts=opts||{};const FL=dcFloating(D);if(FL.devFloat)return{ok:false,msg:'floating',nodes:FL.float};const flSet=new Set(FL.float);const n=D.n,nv=D.V.length,nn=D.nul.length,na=D.vcvs.length,nx=D.xf.length;let nz=0;
  const devs=D.dev;/* each diac has its current as an unknown, after the transformers */for(const d of devs)if(d.t==='X')d._k=n+nv+nn+na+nx+(nz++);const N=n+nv+nn+na+nx+nz;
  /* initial junction states near the knee, like SPICE; parts of a thyristor start off (d.off), so that the off state is found and not the unstable holding point */
  const st=devs.map(d=>d.t==='X'?{i:0}:d.t==='D'?{v:d.off?0:VT*Math.log(VT/(Math.SQRT2*d.par.is))}:d.t==='Q'?{vbe:d.off?0:VT*Math.log(VT/(Math.SQRT2*d.par.is)),vbc:0}:{vgs:d.par.vth+0.5*d.pol,vds:0.1*d.pol});
  const Vof=(x,i)=>i<0?0:x[i];
  function assemble(x,gshunt,srcScale,lim){const A=new Float64Array(N*N),b=new Float64Array(N);let limited=false;
    const a=(r,c,v)=>{if(r>=0&&c>=0)A[r*N+c]+=v};const rh=(r,v)=>{if(r>=0)b[r]+=v};
    for(const e of D.R){a(e.a,e.a,e.g);a(e.b,e.b,e.g);a(e.a,e.b,-e.g);a(e.b,e.a,-e.g)}
    if(gshunt)for(let i=0;i<n;i++)a(i,i,gshunt);for(const i of flSet)a(i,i,1e-12);/* DC-isolated nodes without devices (e.g. between two capacitors): voltage defined as 0 */
    D.V.forEach((e,j)=>{const k=n+j;a(e.a,k,1);a(e.b,k,-1);a(k,e.a,1);a(k,e.b,-1);b[k]=e.v*srcScale});
    D.nul.forEach((e,j)=>{const k=n+nv+j;a(e.o,k,1);a(k,e.p,1);a(k,e.n,-1)});
    D.vcvs.forEach((e,j)=>{const k=n+nv+nn+j;a(e.o,k,1);a(k,e.o,1);a(k,e.p,-e.a0);a(k,e.n,e.a0)});
    /* ideal transformer n:1 — primary current I (into p1) is an unknown; V(p1) − V(n1) = n·(V(p2) − V(n2)), the secondary delivers n·I */
    D.xf.forEach((e,j)=>{const k=n+nv+nn+na+j,r=e.n;a(e.p1,k,1);a(e.n1,k,-1);a(e.p2,k,-r);a(e.n2,k,r);a(k,e.p1,1);a(k,e.n1,-1);a(k,e.p2,-r);a(k,e.n2,r)});
    for(const e of D.I){rh(e.a,-e.i*srcScale);rh(e.b,e.i*srcScale)}
    devs.forEach((d,j)=>{const s=st[j];
      if(d.t==='X'){/* V_a − V_b = f(I), linearized at the (limited) current */const k=d._k;let I=x[k];if(lim){const I2=diacLim(I,s.i,d.par.ibo);if(I2!==I)limited=true;I=I2}s.i=I;
        const r=evalDiac(I,d.par);a(d.a,k,1);a(d.b,k,-1);a(k,d.a,1);a(k,d.b,-1);a(k,k,-r.g);b[k]=r.v-r.g*I;return}
      if(d.t==='D'){let v=Vof(x,d.a)-Vof(x,d.k);if(lim){const nvt=(d.par.n||1)*VT,vc=nvt*Math.log(nvt/(Math.SQRT2*d.par.is));const xb=d.par.xbv;let v2;
          /* in breakdown the junction is limited on the mirrored voltage, like SPICE */
          if(xb>0&&v<Math.min(0,-xb+10*(d.par.nbv||d.par.n||1)*VT)){const nb=(d.par.nbv||d.par.n||1)*VT;v2=-(pnjlim(-(v+xb),-(s.v+xb),nb,vc)+xb)}else v2=pnjlim(v,s.v,nvt,vc);if(v2!==v)limited=true;v=v2}s.v=v;
        const r=evalDiode(v,d.par);const ieq=r.i-r.g*v;a(d.a,d.a,r.g);a(d.k,d.k,r.g);a(d.a,d.k,-r.g);a(d.k,d.a,-r.g);rh(d.a,-ieq);rh(d.k,ieq)}
      else if(d.t==='Q'){let vbe=Vof(x,d.b)-Vof(x,d.e),vbc=Vof(x,d.b)-Vof(x,d.c);
        if(lim){const vc=VT*Math.log(VT/(Math.SQRT2*d.par.is));const p=d.pol;const e1=p*pnjlim(p*vbe,p*s.vbe,VT,vc),c1=p*pnjlim(p*vbc,p*s.vbc,VT,vc);if(e1!==vbe||c1!==vbc)limited=true;vbe=e1;vbc=c1}
        s.vbe=vbe;s.vbc=vbc;const r=evalBJT(vbe,vbc,d.par,d.pol);
        /* linearized: ic = ic0 + dic_be·(vbe − vbe0) + dic_bc·(vbc − vbc0), same for ib; ie = −ic − ib */
        const B=d.b,C=d.c,E=d.e;const ic0=r.ic-r.dic_be*vbe-r.dic_bc*vbc,ib0=r.ib-r.dib_be*vbe-r.dib_bc*vbc;
        const stamp=(row,dbe,dbc,i0)=>{/* current into the device at terminal 'row' = dbe·(Vb − Ve) + dbc·(Vb − Vc) + i0 → leaves the node */
          a(row,B,dbe+dbc);a(row,E,-dbe);a(row,C,-dbc);rh(row,-i0)};
        stamp(C,r.dic_be,r.dic_bc,ic0);stamp(B,r.dib_be,r.dib_bc,ib0);stamp(E,-r.dic_be-r.dib_be,-r.dic_bc-r.dib_bc,-ic0-ib0)}
      else{let vgs=Vof(x,d.g)-Vof(x,d.s),vds=Vof(x,d.d)-Vof(x,d.s);
        if(lim){const p=d.pol;let g1=p*vgs,d1=p*vds;const go=p*s.vgs,dold=p*s.vds;const vto=d.par.vth*p;
          if(dold>=0){g1=fetlim(g1,go,vto);const vgd=g1-d1;d1=limvds(d1,dold)}else{const vgdo=go-dold;let vgd=fetlim(g1-d1,vgdo,vto);d1=g1-vgd;d1=-limvds(-d1,-dold)}
          if(Math.abs(p*g1-vgs)>1e-12*(1+Math.abs(vgs))||Math.abs(p*d1-vds)>1e-12*(1+Math.abs(vds))){limited=true;vgs=p*g1;vds=p*d1}}
        s.vgs=vgs;s.vds=vds;const r=evalMOS(vgs,vds,d.par,d.pol);const i0=r.id-r.dvgs*vgs-r.dvds*vds;const Dd=d.d,G=d.g,S=d.s;
        a(Dd,G,r.dvgs);a(Dd,Dd,r.dvds);a(Dd,S,-r.dvgs-r.dvds);rh(Dd,-i0);a(S,G,-r.dvgs);a(S,Dd,-r.dvds);a(S,S,r.dvgs+r.dvds);rh(S,i0)}});
    return{A,b,limited}}
  function limvds(vnew,vold){if(vold>=3.5){if(vnew>vold)vnew=Math.min(vnew,3*vold+2);else if(vnew<3.5)vnew=Math.max(vnew,2)}else{if(vnew>vold)vnew=Math.min(vnew,4);else vnew=Math.max(vnew,-0.5)}return vnew}
  function lu(A){const M=Float64Array.from(A),p=new Int32Array(N);
    for(let c=0;c<N;c++){let q=c,best=0;for(let r=c;r<N;r++){const v=Math.abs(M[r*N+c]);if(v>best){best=v;q=r}}if(!(best>1e-300))return null;p[c]=q;
      if(q!==c)for(let k=c;k<N;k++){const t=M[c*N+k];M[c*N+k]=M[q*N+k];M[q*N+k]=t}
      const dd=M[c*N+c];for(let r=c+1;r<N;r++){const f=M[r*N+c]/dd;if(f===0)continue;M[r*N+c]=f;for(let k=c+1;k<N;k++)M[r*N+k]-=f*M[c*N+k]}}return{M,p}}
  function sol(L,bv){const{M,p}=L;const x=Float64Array.from(bv);for(let c=0;c<N;c++){const q=p[c];if(q!==c){const t=x[c];x[c]=x[q];x[q]=t}const v=x[c];if(v!==0)for(let r=c+1;r<N;r++)x[r]-=M[r*N+c]*v}
    for(let r=N-1;r>=0;r--){let s=x[r];for(let k=r+1;k<N;k++)s-=M[r*N+k]*x[k];x[r]=s/M[r*N+r]}return x}
  /* one Newton run from x0 with fixed gshunt and source scale */
  function newton(x0,gshunt,scale,maxIt,tf){tf=tf||1;let x=Float64Array.from(x0);let good=0,stall=0,bestR=Infinity;
    for(let it=0;it<maxIt;it++){const{A,b,limited}=assemble(x,gshunt,scale,true);const L=lu(A);if(!L)return null;const xn=sol(L,b);
      let ok=!limited,dmax=0,ratio=0;for(let i=0;i<N;i++){const d=Math.abs(xn[i]-x[i]);const tol=tf*(i<n?1e-11*Math.max(Math.abs(xn[i]),Math.abs(x[i]))+1e-13:1e-9*Math.max(Math.abs(xn[i]),Math.abs(x[i]))+1e-14);/* source currents: ill-conditioned sums, looser */if(!(d<=tol))ok=false;dmax=Math.max(dmax,d);ratio=Math.max(ratio,d/tol)}
      x=xn;if(!x.every(isFinite))return null;if(ok){good++;if(good>=2)return{x,it}}else good=0;
      /* round-off floor: high-gain loops (op-amp gain 1e5–1e6) amplify rounding so the update stalls slightly above the tolerance;
         accept when the update is within 1e-7 relative and has stopped shrinking for 4 iterations */
      if(!limited&&ratio<1e4){if(ratio>0.5*bestR)stall++;else stall=0;bestR=Math.min(bestR,ratio);if(stall>=4)return{x,it,floor:ratio}}else{stall=0;bestR=Infinity}}
    return null}
  let x=new Float64Array(N),r=newton(x,0,1,150),how='newton';
  if(!r){/* gmin stepping: a conductance from every node to ground, reduced step by step */
    let xx=new Float64Array(N),okk=true;for(const g of[1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8,1e-9,1e-10,1e-12,1e-14]){const q=newton(xx,g,1,150);if(!q){okk=false;break}xx=q.x}
    if(okk){r=newton(xx,0,1,150);how='gmin'}}
  if(!r){/* source stepping */let xx=new Float64Array(N),sc=0,step=0.05,okk=true;st.forEach((s,j)=>{const d=devs[j];if(d.t==='X')s.i=0;else if(d.t==='D')s.v=0;else if(d.t==='Q'){s.vbe=0;s.vbc=0}else{s.vgs=0;s.vds=0}});
    while(sc<1){const s2=Math.min(1,sc+step);const q=newton(xx,0,s2,100);if(q){xx=q.x;sc=s2;step=Math.min(step*2,0.25)}else{step/=4;if(step<1e-6){okk=false;break}}}
    if(okk){r={x:xx,it:0};how='source'}}
  let loose=false;if(!r){/* last resort: nearly floating nodes (e.g. a base reachable only through junctions) make the Jacobian
     ill-conditioned; accept a solution converged to 1e-6 relative and report it as low accuracy */
    let xx=new Float64Array(N);for(const g of[1e-2,1e-4,1e-6,1e-8,1e-10,1e-12]){const q=newton(xx,g,1,150,1e5);if(!q){xx=null;break}xx=q.x}
    if(xx){const q=newton(xx,0,1,200,1e5);if(q){r=q;how='loose';loose=true}}}
  if(!r)return{ok:false,msg:'noconv'};
  const xs=Array.from(r.x.slice(0,n));const im=devImax(D,r.x);if(!(im<=10))return{ok:false,msg:'overcurrent',imax:im,x:r.x};
  if(xs.some(v=>!(Math.abs(v)<=1e4)))return{ok:false,msg:'overvoltage',x:r.x};
  const res=dcResidual(D,xs);
  return{ok:true,x:r.x,how,it:r.it,loose,res}}
/* KCL residual of node voltages v (array of n) with the full nonlinear models: largest |sum of currents| at a node, and the
   largest current magnitude for scale. Branch currents of sources are eliminated: nodes tied by voltage sources are not checked */
function dcResidual(D,v){const n=D.n,F=new Float64Array(n),S=new Float64Array(n);const V=i=>i<0?0:v[i];const add=(i,c)=>{if(i>=0){F[i]+=c;S[i]=Math.max(S[i],Math.abs(c))}};
  for(const e of D.R){const c=e.g*(V(e.a)-V(e.b));add(e.a,c);add(e.b,-c)}for(const e of D.I){add(e.a,e.i);add(e.b,-e.i)}
  for(const d of D.dev){if(d.t==='X')continue;if(d.t==='D'){const r=evalDiode(V(d.a)-V(d.k),d.par);add(d.a,r.i);add(d.k,-r.i)}
    else if(d.t==='Q'){const r=evalBJT(V(d.b)-V(d.e),V(d.b)-V(d.c),d.par,d.pol);add(d.c,r.ic);add(d.b,r.ib);add(d.e,-r.ic-r.ib)}
    else{const r=evalMOS(V(d.g)-V(d.s),V(d.d)-V(d.s),d.par,d.pol);add(d.d,r.id);add(d.s,-r.id)}}
  const fixed=new Set();for(const e of D.V){fixed.add(e.a);fixed.add(e.b)}for(const e of D.xf||[]){fixed.add(e.p1);fixed.add(e.n1);fixed.add(e.p2);fixed.add(e.n2)}for(const e of D.nul.concat(D.vcvs))fixed.add(e.o);/* a diac's current is not a function of its voltage: its nodes are not checked */for(const d of D.dev)if(d.t==='X'){fixed.add(d.a);fixed.add(d.b)}
  let worst=0;for(let i=0;i<n;i++){if(fixed.has(i))continue;worst=Math.max(worst,Math.abs(F[i])/Math.max(S[i],1e-15))}return worst}
/* largest terminal current of any semiconductor device at node voltages x (used to flag unphysical operating points) */
function devImax(D,x){const V=i=>i<0?0:x[i];let m=0;for(const d of D.dev){let c;
  if(d.t==='X')c=d._k>=0&&d._k<x.length?Math.abs(x[d._k]):0;
  else if(d.t==='D')c=Math.abs(evalDiode(V(d.a)-V(d.k),d.par).i);
  else if(d.t==='Q'){const r=evalBJT(V(d.b)-V(d.e),V(d.b)-V(d.c),d.par,d.pol);c=Math.max(Math.abs(r.ic),Math.abs(r.ib),Math.abs(r.ic+r.ib))}
  else c=Math.abs(evalMOS(V(d.g)-V(d.s),V(d.d)-V(d.s),d.par,d.pol).id);m=Math.max(m,c)}return m}
if(typeof module!=='undefined')module.exports={evalDiac,diacPsi,diacLim,pnjlim,fetlim,diodeBrk,dcSolve,evalBJT,evalMOS,evalDiode,VT,junc,dcResidual,devImax,dcFloating,GMIN};
