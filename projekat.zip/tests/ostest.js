// Oscilloscope mode, end to end: random circuits are built in the app from parts (signal generators of all six kinds, R/L/C, diodes of
// every kind in ideal and real mode, BJT, MOSFET, op-amps with supply rails, transformers, DC sources), the app's own netlist for the
// time-domain simulator is built (trNetlist) and simulated; the channels (voltmeters between nodes and ground, the current through one
// resistor) are compared with ngspice .tran of an independent netlist written from the same description.
const { chromium } = require('playwright');const fs=require('fs'),cp=require('child_process');
const NGS=process.env.NGSPICE||'/tmp/claude-0/-home-claude/3126b669-5ac5-5936-b9ef-b8aba5bf071a/scratchpad/ngs/inst/bin/ngspice';
const WD=fs.mkdtempSync(require('os').tmpdir()+'/os-');
let seed=+(process.env.SEED||3);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const VT=1.380649e-23*300.15/1.602176634e-19,TC=VT*1.6021918e-19/1.3806226e-23-273.15;const p17=v=>(+v).toPrecision(17);
/* real MOSFET C_gd(V) emulated in ngspice exactly: charge Q = C0·f(V_GD) with f = depletion form below 0 and V above; a B source makes
   f(V) on node yq, a capacitor C0 from yq through a 0 V sense source, and an F source copies its current from gate to drain */
function cgdNet(j,g,d,pol,c0,vj,m){const a=pol>0?g:d,b=pol>0?d:g;const V=x=>x==='0'?'0':`v(${x})`;const v=`(${V(a)}-${V(b)})`;
  return[`BQ${j} yq${j} 0 V=(${v}<0)?(${vj}*(1-pow(1-${v}/${vj},${1-m}))/${1-m}):(${v})`,`CQ${j} yq${j} zq${j} ${c0}`,`VQ${j} zq${j} 0 0`,`FQ${j} ${a} ${b} VQ${j} 1`]}
function gen(){const G={els:[],gens:[],vdc:[],devs:[],oas:[],xfs:[],probe:null};const nodes=new Set();const nd=x=>{if(x!=='g')nodes.add(x);return x};
  const E=(k,a,b,v)=>G.els.push({k,a:nd(a),b:nd(b),v});const R=(a,b,v)=>E('R',a,b,v||logU(100,1e5)),Cc=(a,b,v)=>E('C',a,b,v||logU(1e-9,1e-5)),Ll=(a,b,v)=>E('L',a,b,v||logU(1e-5,1e-1));
  const f0=logU(20,2e4);const W=type=>({type,amp:logU(0.5,10),f:f0,off:pick([0,0,(rnd()*2-1)*2]),ph:type==='sin'?pick([0,90]):0,duty:pick([50,30,70]),tr:pick([1e-3,1e-2])/f0});
  const SG=(a,b,type)=>G.gens.push({a:nd(a),b:nd(b),w:W(type||pick(['sin','sq','tri','saw','pul','dc']))});const VD=(a,b,v)=>G.vdc.push({a:nd(a),b:nd(b),v});
  const D=(a,k,dt)=>{dt=dt||pick(['std','zen','sch','led','var']);const sc={is:dt==='sch'?1e-7:dt==='led'?1e-18:1e-14,n:dt==='led'?2:1,rs:pick([0,logU(0.1,20)]),cj:dt==='var'?logU(1e-11,1e-10):pick([0,logU(1e-12,1e-10)]),vj:0.7,m:0.5,tt:pick([0,logU(1e-9,1e-7)])};
    if(dt==='zen'){sc.bv=logU(2,8);sc.ibv=5e-3}G.devs.push({k:'D',dt,a:nd(a),b:nd(k),sc,real:rnd()<0.6})};
  /* QREAL: the transistor is one of the app's ready-made types (parameters read from the app) in real mode */
  const QR=!!process.env.QREAL;
  const Q=(b,c,e,pol)=>G.devs.push({k:'Q',b:nd(b),c:nd(c),e:nd(e),pol,sc:{bf:logU(50,300),br:1,va:pick([0,100]),is:1e-14,cpi:pick([0,1e-11]),cmu:pick([0,2e-12])},ty:QR?pick(['gen','bc547','2n2222','2n3904']):null,real:QR});
  const M=(g,d,s,pol)=>G.devs.push({k:'M',g:nd(g),d:nd(d),s:nd(s),pol,sc:{vth:logU(0.5,2),k:logU(1e-3,1e-2),lam:pick([0,0.02]),cgs:pick([0,2e-12]),cgd:pick([0,5e-13])},ty:QR?pick(['gen','2n7000','irf540']):null,real:QR});
  const OA=(p,n,o,vs)=>G.oas.push({p:nd(p),n:nd(n),o:nd(o),vs:vs||pick([5,12,15])});const XF=(p1,n1,p2,n2,n)=>G.xfs.push({p1:nd(p1),n1:nd(n1),p2:nd(p2),n2:nd(n2),n});
  const typ=+(process.env.TYP||Math.floor(rnd()*9));G.typ=typ;G.real=QR||rnd()<0.5;
  switch(typ){
  case 0:SG('i','g');R('i','a');pick([()=>Cc('a','g'),()=>Ll('a','g'),()=>{Ll('a','b');Cc('b','g');R('b','g',logU(1e3,1e5))}])();G.probe=0;break;
  case 1:SG('i','g','sin');G.gens[0].w.amp=logU(3,15);R('i','a',logU(1,100));D('a','o','std');Cc('o','g',logU(1e-7,1e-4));R('o','g',logU(100,1e4));G.probe=0;break;
  case 2:SG('i','g',pick(['sin','tri','sq']));G.gens[0].w.amp=logU(3,12);R('i','o',logU(100,5e3));D('g','o','zen');if(rnd()<0.5)D('o','g','led');G.probe=0;break;
  case 3:{VD('vc','g',logU(6,15));R('vc','b',logU(2e4,2e5));R('b','g',logU(5e3,5e4));R('vc','c',logU(1e3,1e4));R('e','g',logU(100,2e3));Cc('e','g',1e-5);SG('s','g','sin');G.gens[0].w.amp=logU(1e-3,0.2);G.gens[0].w.off=0;Cc('s','b',1e-6);Cc('c','o',1e-6);R('o','g',logU(1e3,1e5));Q('b','c','e',1);G.probe=7}break;
  case 4:{VD('vd','g',logU(3,12));SG('gs','g','sq');G.gens[0].w.amp=logU(1,5);G.gens[0].w.off=G.gens[0].w.amp;R('gs','gg',100);R('vd','d',logU(200,5e3));Cc('d','g',1e-9);M('gg','d','g',1);G.probe=1}break;
  case 5:SG('i','g',pick(['sin','tri']));R('i','p',1e3);OA('p','g','o');R('o','a',logU(330,2e3));D('a','g','led');G.probe=1;break;
  case 6:SG('i','g');R('i','m',logU(1e3,1e4));R('m','o',logU(1e4,1e5));OA('g','m','o');R('o','g',logU(1e3,1e5));G.probe=1;break;
  case 7:SG('i','g','sin');G.gens[0].w.amp=logU(5,30);R('i','a',logU(1,10));XF('a','g','s1','s2',logU(1,8));R('s2','g',1e6);D('s1','p','std');D('g','s2','std');Cc('p','g',logU(1e-6,1e-4));R('p','g',logU(100,1e4));G.probe=0;break;
  default:SG('i','g','pul');VD('vc','g',logU(5,12));R('i','b',logU(1e3,1e5));Q('b','c','vc',-1);R('c','g',logU(1e3,1e4));Cc('c','g',1e-9);D('g','c','var');G.probe=1}
  G.nodes=[...nodes];G.f0=f0;return G}
/* ngspice netlist of the same circuit (independent of the app) */
function wSpice(w){const A=w.amp,off=w.off||0;if(w.type==='dc')return`DC ${p17(A)}`;const Tp=1/w.f,d=w.duty/100;
  if(w.type==='sin')return`DC ${p17(off)} SIN(${p17(off)} ${p17(A)} ${p17(w.f)} 0 0 0)`;const e=Math.min(Math.max(w.tr*w.f,1e-9),w.type==='saw'?0.5:0.5*Math.min(d,1-d));
  if(w.type==='sq')return`PULSE(${p17(off-A)} ${p17(off+A)} 0 ${p17(e*Tp)} ${p17(e*Tp)} ${p17((d-e)*Tp)} ${p17(Tp)})`;
  if(w.type==='pul')return`PULSE(${p17(off)} ${p17(off+A)} 0 ${p17(e*Tp)} ${p17(e*Tp)} ${p17((d-e)*Tp)} ${p17(Tp)})`;
  const pts=[];for(let k=0;k<NPER+2;k++){if(w.type==='tri')pts.push([k*Tp,off],[(k+0.25)*Tp,off+A],[(k+0.75)*Tp,off-A]);else pts.push([k*Tp,off-A],[(k+1-e)*Tp,off+A])}return`PWL(${pts.map(q=>p17(q[0])+' '+p17(q[1])).join(' ')})`}
const NPER=+(process.env.NPER||3);
function spice(G,tag,tEnd,hmax){const nn=x=>x==='g'?'0':'n_'+x;const L=['* '+tag,`.options reltol=1e-6 abstol=1e-15 vntol=1e-9 chgtol=1e-20 method=gear maxord=2 itl4=200 itl1=500 temp=${TC.toPrecision(15)} tnom=${TC.toPrecision(15)}`];
  G.els.forEach((e,j)=>{if(j===G.probe)L.push(`VP ${nn(e.a)} pp 0`,`R${j} pp ${nn(e.b)} ${p17(e.v)}`);else L.push(`${e.k}${j} ${nn(e.a)} ${nn(e.b)} ${p17(e.v)}`)});
  /* ngspice 26 ignores the SIN phase: a phase-shifted sine is written as a B source */
  G.gens.forEach((g,j)=>{if(g.w.type==='sin'&&g.w.ph)L.push(`BG${j} ${nn(g.a)} ${nn(g.b)} V=${p17(g.w.off||0)}+${p17(g.w.amp)}*sin(${p17(2*Math.PI*g.w.f)}*time+${p17(g.w.ph*Math.PI/180)})`);else L.push(`VG${j} ${nn(g.a)} ${nn(g.b)} ${wSpice(g.w)}`)});G.vdc.forEach((v,j)=>L.push(`VD${j} ${nn(v.a)} ${nn(v.b)} DC ${p17(v.v)}`));
  G.xfs.forEach((x,j)=>L.push(`VX${j} ${nn(x.p1)} xa${j} 0`,`EX${j} xa${j} ${nn(x.n1)} ${nn(x.p2)} ${nn(x.n2)} ${p17(x.n)}`,`FX${j} ${nn(x.n2)} ${nn(x.p2)} VX${j} ${p17(x.n)}`));
  G.oas.forEach((o,j)=>{const w=0.01,vp=o.vs,vn=-o.vs,a0=1e6,wp=2*Math.PI*1e9/a0,Kp=10;const y=`y${j}`;
    L.push(`CY${j} ${y} 0 ${p17(1/(wp*a0))}`,`RY${j} ${y} 0 1e15`,`BY${j} 0 ${y} I=(v(${nn(o.p)})-v(${nn(o.n)}))-v(${y})/${p17(a0)}-${Kp}*((v(${y})>${p17(vp+w)})?(v(${y})-${p17(vp+w)})*(v(${y})-${p17(vp+w)}):((v(${y})<${p17(vn-w)})?-(${p17(vn-w)}-v(${y}))*(${p17(vn-w)}-v(${y})):0))`,
      `BO${j} ${nn(o.o)} 0 V=(v(${y})>=${p17(vp+w)})?${p17(vp)}:((v(${y})>${p17(vp-w)})?v(${y})-(v(${y})-${p17(vp-w)})*(v(${y})-${p17(vp-w)})/${p17(4*w)}:((v(${y})<=${p17(vn-w)})?${p17(vn)}:((v(${y})<${p17(vn+w)})?v(${y})+(${p17(vn+w)}-v(${y}))*(${p17(vn+w)}-v(${y}))/${p17(4*w)}:v(${y}))))`)});
  G.devs.forEach((d,j)=>{const s=d.sc;if(d.k==='D'){const rl=G.real&&d.real,cap=rl||d.dt==='var';L.push(`D${j} ${nn(d.a)} ${nn(d.b)} DM${j}`,`.model DM${j} D(IS=${s.is} N=${s.n} CJO=${cap?s.cj:0} VJ=${s.vj} M=${s.m} TT=${rl?s.tt:0}${rl&&s.rs>0?' RS='+s.rs:''}${d.dt==='zen'?` BV=${s.bv} IBV=${s.ibv}`:''})`)}
    else if(d.k==='Q'&&G.real&&d.real)L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${s.is} BF=${p17(s.bf)} BR=${s.br}${s.va>0?' VAF='+s.va:''}${s.ikf>0?' IKF='+s.ikf:''} RB=${s.rb} RC=${s.rc} RE=${s.re} CJE=${s.cje} VJE=${s.vje} MJE=${s.mje} CJC=${s.cjc} VJC=${s.vjc} MJC=${s.mjc} TF=${s.tf} TR=${s.tr})`);
    else if(d.k==='M'&&G.real&&d.real){const g=s.rg>0?'gi'+j:nn(d.g),dd=s.rdr>0?'di'+j:nn(d.d),ss=s.rsr>0?'si'+j:nn(d.s);if(s.rg>0)L.push(`RGI${j} ${nn(d.g)} ${g} ${s.rg}`);if(s.rdr>0)L.push(`RDI${j} ${nn(d.d)} ${dd} ${s.rdr}`);if(s.rsr>0)L.push(`RSI${j} ${nn(d.s)} ${ss} ${s.rsr}`);
      L.push(`M${j} ${dd} ${g} ${ss} ${ss} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${p17(d.pol*s.vth)} KP=${p17(s.k)} LAMBDA=${s.lam} IS=0 GAMMA=0 CGSO=${s.cgs} CGDO=0)`);
      if(s.cgd0>0)L.push(...cgdNet(j,g,dd,d.pol,s.cgd0,s.vjd,s.mjd));
      L.push(d.pol>0?`DB${j} ${ss} ${dd} DBM${j}`:`DB${j} ${dd} ${ss} DBM${j}`,`.model DBM${j} D(IS=${s.bis} N=${s.bn} CJO=${s.bcj} VJ=${s.bvj} M=${s.bm} TT=${s.btt}${s.brs>0?' RS='+s.brs:''})`)}
    else if(d.k==='Q')L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${s.is} BF=${p17(s.bf)} BR=${s.br}${s.va>0?' VAF='+s.va:''} CJE=${s.cpi} MJE=0 CJC=${s.cmu} MJC=0)`);
    else L.push(`M${j} ${nn(d.d)} ${nn(d.g)} ${nn(d.s)} ${nn(d.s)} MM${j} W=1 L=1`,`.model MM${j} ${d.pol>0?'NMOS':'PMOS'}(LEVEL=1 VTO=${p17(d.pol*s.vth)} KP=${p17(s.k)} LAMBDA=${s.lam} IS=0 GAMMA=0 CGSO=${s.cgs} CGDO=${s.cgd})`)});
  const vs=G.nodes.slice(0,4);L.push('.control','set filetype=ascii',`tran ${p17(hmax/4)} ${p17(tEnd)} 0 ${p17(hmax)}`,`write ${WD}/${tag}.raw ${vs.map(x=>'v('+nn(x)+')').join(' ')} i(VP)`,'quit','.endc','.end');
  fs.writeFileSync(`${WD}/${tag}.cir`,L.join('\n'));try{cp.execFileSync(NGS,['-b',`${WD}/${tag}.cir`],{stdio:'ignore',timeout:300000})}catch(e){return null}
  const file=`${WD}/${tag}.raw`;if(!fs.existsSync(file)||fs.statSync(file).size>4e8)return null;const txt=fs.readFileSync(file,'utf8');if(!txt.includes('Values:'))return null;const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];
  const vals=txt.split('Values:')[1].trim().split(/\s+/);const rows=[];for(let i=0;i<vals.length;){i++;const r=[];for(let v=0;v<nv;v++)r.push(+vals[i++]);rows.push(r)}return rows}
function interp(ts,ys,t){let lo=0,hi=ts.length-1;if(t<=ts[0])return ys[0];if(t>=ts[hi])return ys[hi];while(hi-lo>1){const m=(lo+hi)>>1;if(ts[m]<=t)lo=m;else hi=m}const a=ts[lo],b=ts[hi];return ys[lo]+(ys[hi]-ys[lo])*(t-a)/(b-a)}
const N=+(process.env.N||40);
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(400);
let nOK=0,worst=0,nApp=0,nSp=0,nBoth=0;const PRE=await p.evaluate(()=>({Q:TY_PRE('Q'),M:TY_PRE('M')}));
for(let ci=0;ci<N;ci++){const G=gen();if(process.env.ONLY&&+process.env.ONLY!==ci)continue;const per=1/G.f0,tEnd=NPER*per,hmax=per/400;
  for(const d of G.devs)if(d.ty)d.sc=Object.assign({},PRE[d.k][d.ty]);
  const r=await p.evaluate(({G,tEnd,hmax,RTO})=>{uid=1;OSC.run=false;const parts=[],wires=[],term={};const add=(n,q,e)=>{(term[n]=term[n]||[]).push([q,e])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240+80];j++;return q};
    G.els.forEach(e=>{const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.real=false;parts.push(q);add(e.a,q,0);add(e.b,q,1);e.id=q.id});
    G.gens.forEach(g=>{const[x,y]=pos();const q=mkP('SG',x,y,0,g.w.amp);q.wf=g.w.type;q.sg={f:g.w.f,off:g.w.off,ph:g.w.ph,duty:g.w.duty,tr:g.w.tr};parts.push(q);add(g.a,q,0);add(g.b,q,1)});
    G.vdc.forEach(v=>{const[x,y]=pos();const q=mkP('VDC',x,y,0,v.v);parts.push(q);add(v.a,q,0);add(v.b,q,1)});
    G.xfs.forEach(xx=>{const[x,y]=pos();const q=mkP('T',x,y,0,xx.n);q.real=false;parts.push(q);add(xx.p1,q,0);add(xx.n1,q,1);add(xx.p2,q,2);add(xx.n2,q,3)});
    G.oas.forEach(o=>{const[x,y]=pos();const q=mkP('OA',x,y,0);q.real=false;q.vsup=o.vs;parts.push(q);add(o.p,q,0);add(o.n,q,1);add(o.o,q,2)});
    G.devs.forEach(d=>{const[x,y]=pos();const q=mkP(d.k,x,y,0);q.sc=Object.assign({},d.sc);if(d.k==='D'){q.dt=d.dt;q.real=d.real;add(d.a,q,0);add(d.b,q,1)}else{q.pol=d.pol;if(d.real){q.real=true;q.ty=d.ty}if(d.k==='Q'){add(d.b,q,0);add(d.c,q,1);add(d.e,q,2)}else{add(d.g,q,0);add(d.d,q,1);add(d.s,q,2)}}parts.push(q)});
    const gp=mkP('GND',0,-400);parts.push(gp);add('g',gp,0);const vms=[];G.nodes.slice(0,4).forEach((nm,i)=>{const q=mkP('VM',300+i*240,-400,0);parts.push(q);add(nm,q,0);add('g',q,1);vms.push(q)});
    for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
    state.parts=parts;state.wires=wires;state.realMode=!!G.real;state.std=null;assignNames();
    state.osc={ch:vms.map(q=>({id:q.id,q:'v'})).concat(G.probe!=null?[{id:G.els[G.probe].id,q:'i'}]:[]),win:0};
    const nl=trNetlist();if(nl.err)return{err:nl.err};const S=trCreate(nl.C,{rtol:RTO});if(!S.dcop(false))return{err:'dcop'};
    const ch=nl.chans.map(c=>Object.assign({},c,{vi:c.vi>=0?S.iV+c.vi:-1}));const T=[0],Y=[ch.map(c=>oscVal(c,S.x))];
    const ok=S.run(tEnd,hmax,(t,x)=>{T.push(t);Y.push(ch.map(c=>oscVal(c,x)))});if(!ok)return{err:'run at '+S.t};
    let st='';try{circuitChanged();renderSelBar()}catch(e){st=e.message}return{T,Y,st}},{G,tEnd,hmax,RTO:+(process.env.RTO||1e-6)});
  const sp=spice(G,'o'+ci,tEnd,hmax);
  if(r.err&&!sp){nBoth++;continue}if(!sp||sp[sp.length-1][0]<tEnd*0.999){nSp++;console.log('SPFAIL',ci,'typ',G.typ);continue}if(r.err){nApp++;console.log('APPFAIL',ci,'typ',G.typ,r.err);continue}
  const st=sp.map(q=>q[0]);let e=0,eAt=null;const nch=r.Y[0].length;
  for(let k=0;k<nch;k++){const ya=r.Y.map(y=>y[k]),ys=sp.map(q=>q[k+1]);let mx=0,mn=0;ys.forEach(v=>{mx=Math.max(mx,v);mn=Math.min(mn,v)});const rng=Math.max(mx-mn,Math.abs(mx),Math.abs(mn),k<4?1e-3:1e-9);
    const tw=1e-3*per;for(let i=0;i<=600;i++){const t=tEnd*i/600;const bb=interp(st,ys,t);let d=Infinity;for(let q=-4;q<=4;q++)d=Math.min(d,Math.abs(interp(r.T,ya,t+q*tw/4)-bb));d/=rng;if(d>e){e=d;eAt=[k,(t/per).toFixed(3)]}}}
  if(process.env.DBG){console.log(JSON.stringify(G));for(const f of (process.env.PTS||"0,0.1,0.5,1,2,2.875").split(",").map(Number)){const t=f*per;console.log(f,Array.from({length:nch},(_,k)=>interp(r.T,r.Y.map(y=>y[k]),t).toPrecision(5)+'/'+interp(st,sp.map(q=>q[k+1]),t).toPrecision(5)).join('  '))}console.log(fs.readFileSync(WD+'/o'+ci+'.cir','utf8').split('.control')[0])}
  nOK++;worst=Math.max(worst,e);if(e>(+process.env.TH||3e-3)||r.st)console.log('DIFF',ci,'typ',G.typ,'real',G.real,'err',e.toExponential(2),'at ch',JSON.stringify(eAt),r.st||'')}
console.log('circuits',N,'compared',nOK,'appFail',nApp,'spiceFail',nSp,'bothFail',nBoth,'worst',worst.toExponential(2),'pageerrors',errs.length,errs.slice(0,3).join(' | '));await b.close()})();
