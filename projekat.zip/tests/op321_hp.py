import json
from decimal import Decimal as Dd, getcontext
getcontext().prec=60
D=json.load(open(__import__('os').path.join(__import__('os').path.dirname(__file__),'op321.json')))
VT=Dd('1.380649e-23')*Dd('300.15')/Dd('1.602176634e-19');GMIN=Dd('1e-12');E=Dd(1).exp()
def junc(v,is_,nvt):
    if v>=-3*nvt: return is_*((v/nvt).exp()-1)
    a=3*nvt/(v*E);a=a*a*a;return -is_*(1+a)
R=D['R'];g=lambda j:Dd(repr(R[j]['g']))
V2=Dd(repr(D['V'][1]['v']));V3=Dd(repr(D['V'][0]['v']))
q=D['dev'][2]['par'];IS=Dd(repr(q['is']));BF=Dd(repr(q['bf']));BR=Dd(q['br'])
dp=D['dev'][1]['par'];DIS=Dd(repr(dp['is']))
A0=Dd(100000)
def F(V1,V4):
    V0=A0*(V4-V1)
    vbe=-(V1-V2);vbc=-(V1-V3)
    ib=-(junc(vbe,IS,VT)/BF+junc(vbc,IS,VT)/BR+GMIN*(vbe+vbc))
    f1=(V1-V0)*(g(0)+g(1))+ib
    vd=V4-V0;iD=junc(vd,DIS,VT)+GMIN*vd
    f4=(V4-V3)*g(4)+iD
    return f1,f4,V0
def solve(V1,V4):
    for k in range(200):
        f1,f4,_=F(V1,V4);h=Dd('1e-30')
        a,b,_=F(V1+h,V4);c,d,_=F(V1,V4+h)
        j11=(a-f1)/h;j21=(b-f4)/h;j12=(c-f1)/h;j22=(d-f4)/h
        det=j11*j22-j12*j21
        d1=(f1*j22-f4*j12)/det;d4=(j11*f4-j21*f1)/det
        # damp
        m=max(abs(d1),abs(d4));s=Dd(1) if m<Dd('0.05') else Dd('0.05')/m
        V1-=s*d1;V4-=s*d4
        if m<Dd('1e-45'):break
    f1,f4,V0=F(V1,V4);return V0,V1,V4,f1,f4,k
for name,(v1,v4) in {'app':('19.975834507714094','19.97603426605927'),'spice':('19.29074866','19.29094078')}.items():
    V0,V1,V4,f1,f4,k=solve(Dd(v1),Dd(v4))
    print(name,'iters',k,'V0=%.15f V1=%.15f V4=%.15f'%(V0,V1,V4),'res %.1e %.1e'%(f1,f4))
