# Independent step-response reference: the descriptor system G x + C x' = b u(t), x(0) = 0, u = unit step,
# integrated with the 3-stage Radau IIA method (order 5, L-stable, stiffly accurate) on a very fine uniform grid.
# Input (stdin): JSON list of {c: circuit (as pzoracle), T, n}; output: y and dy/dt at t_k = k T / n, k = 0..n
import sys, json, numpy as np, scipy.linalg as sl
from pzoracle import pencil
r6 = np.sqrt(6)
A = np.array([[(88 - 7 * r6) / 360, (296 - 169 * r6) / 1800, (-2 + 3 * r6) / 225],
              [(296 + 169 * r6) / 1800, (88 + 7 * r6) / 360, (-2 - 3 * r6) / 225],
              [(16 - r6) / 36, (16 + r6) / 36, 1 / 9]])
def run(job):
    c, T, n = job['c'], job['T'], job['n']; m = job.get('m', 40)
    G, C, b, I = pencil(c, 'v'); N = G.shape[0]
    out = (lambda x: -x[-1]) if c['mode'] == 'Z' else (lambda x: x[I(c['vout'])])
    h = T / (n * m)
    M = np.kron(np.eye(3), C) + h * np.kron(A, G)
    lu = sl.lu_factor(M)
    rhsb = h * np.kron(A @ np.ones(3), b)
    x = np.zeros(N); ys = [0.0]; fine = [0.0]
    Cx3 = lambda v: np.tile(C @ v, 3)
    for k in range(1, n * m + 1):
        X = sl.lu_solve(lu, Cx3(x) + rhsb)
        x = X[2 * N:]
        fine.append(out(x))
    fine = np.array(fine)
    y = fine[::m]
    dy = np.full(n + 1, np.nan)
    for k in range(1, n):
        j = k * m
        dy[k] = (fine[j + 1] - fine[j - 1]) / (2 * h)
    return {'y': y.tolist(), 'dy': [None if not np.isfinite(v) else float(v) for v in dy]}
if __name__ == '__main__':
    print(json.dumps([run(j) for j in json.load(sys.stdin)]))
