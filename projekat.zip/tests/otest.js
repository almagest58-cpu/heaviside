// random circuits with op-amps and potentiometers vs. 72-digit MNA oracle (hpx.js)
const { chromium } = require('playwright');const fs=require('fs');const {hpSolveX}=require('./hpx.js');
const C={abs:a=>Math.hypot(a[0],a[1]),sub:(a,b)=>[a[0]-b[0],a[1]-b[1]]};
let seed=+(process.env.SEED||777);const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
const parOf=k=>k==='C'?{esr:logU(1e-3,1),esl:logU(1e-10,1e-8),rp:rnd()<0.5?1e12:logU(1e5,1e9)}:k==='R'?{ls:logU(1e-10,1e-7),cp:logU(1e-14,1e-11)}:k==='L'?{rdc:logU(1e-2,10),cp:logU(1e-13,1e-10)}
  :k==='P'?{ls:logU(1e-10,1e-6),cp:logU(1e-14,1e-10),rw:logU(1e-2,100)}:{a0:logU(1e3,1e7),gbw:logU(1e5,1e8),rin:logU(1e5,1e12),cin:logU(1e-13,1e-11),lin:logU(1e-10,1e-8),rout:logU(1,500),lout:logU(1e-10,1e-7),cout:logU(1e-14,1e-11)};
const val=k=>k==='R'?logU(10,1e5):k==='L'?logU(1e-6,1e-1):k==='C'?logU(1e-11,1e-5):logU(100,1e6);
function gen(){const zmode=rnd()<0.12;const nInt=1+Math.floor(rnd()*5);const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:nInt},(_,j)=>'n'+j)];
  const order=nodes.slice().sort(()=>rnd()-0.5);const els=[];const E=(a,b,k)=>els.push({k,a,b,v:val(k),par:parOf(k)});
  for(let j=1;j<order.length;j++)if(rnd()<0.8)E(order[j],pick(order.slice(0,j)),pick(['R','R','L','C','C']));
  const nOA=Math.floor(rnd()*3)+(rnd()<0.85?1:0),oas=[];const usedO=new Set();
  for(let j=0;j<nOA;j++){const outs=nodes.filter(x=>x!=='g'&&x!=='i'&&!usedO.has(x));if(!outs.length)break;const o=pick(outs);usedO.add(o);
    const n=pick(nodes.filter(x=>x!==o));const p=pick(nodes.filter(x=>x!==o&&x!==n));oas.push({k:'OA',p,n,o,par:parOf('OA'),real:rnd()<0.5});
    E(o,n,pick(['R','R','C']))} // feedback element
  const nP=rnd()<0.5?1:0;for(let j=0;j<nP;j++){const a=pick(nodes),bb=pick(nodes.filter(x=>x!==a)),w=pick(nodes);els.push({k:'P',a,b:bb,w,v:val('P'),pos:pick([0,1,rnd(),rnd(),rnd()]),par:parOf('P')})}
  while(els.length<4+Math.floor(rnd()*6)){const a=pick(nodes),bb=pick(nodes);if(a!==bb)E(a,bb,pick(['R','L','C']))}
  return{zmode,els,oas,realMode:rnd()<0.5}}

function gen2(){const els=[],oas=[];const E=(a,b,k,v)=>els.push({k,a,b,v:v===undefined?val(k):v,par:parOf(k)});const OA=(p,n,o)=>oas.push({k:'OA',p,n,o,par:parOf('OA'),real:rnd()<0.6});
  const R=()=>logU(500,1e5),Cv=()=>logU(1e-10,1e-6);const typ=Math.floor(rnd()*13);
  switch(typ){
   case 0:E('i','n','R',R());E('n','o','R',R());if(rnd()<0.5)E('n','o','C',Cv());OA('g','n','o');break;// inverting
   case 1:E('n','g','R',R());E('n','o','R',R());if(rnd()<0.5)E('n','o','C',Cv());OA('i','n','o');break;// non-inverting
   case 2:E('i','a','R',R());E('a','g','C',Cv());OA('a','o','o');break;// RC + follower
   case 3:E('i','a','R',R());E('a','b','R',R());E('b','g','C',Cv());E('a','o','C',Cv());OA('b','o','o');break;// Sallen-Key LP
   case 4:E('i','a','C',Cv());E('a','b','C',Cv());E('b','g','R',R());E('a','o','R',R());OA('b','o','o');break;// Sallen-Key HP
   case 5:E('i','a','R',R());E('a','g','R',R());E('a','n','C',Cv());E('a','o','C',Cv());E('n','o','R',R());OA('g','n','o');break;// MFB BP
   case 6:E('i','n','R',R());E('n','o','C',Cv());E('n','o','R',R()*30);OA('g','n','o');break;// lossy integrator
   case 7:E('i','x','C',Cv());E('x','n','R',R()/10);E('n','o','R',R());OA('g','n','o');break;// differentiator
   case 8:E('i','n','R',R());E('n','m','R',R());E('m','n2','R',R());E('n2','o','R',R());E('n2','o','C',Cv());OA('g','n','m');oas[0].o='m';E('n','m','C',Cv());OA('g','n2','o');break;// two inverting stages
   case 9:els.push({k:'P',a:'o',b:'g',w:'n',v:logU(1e3,1e6),pos:rnd(),par:parOf('P')});E('i','a','R',R());E('a','g','C',Cv());OA('a','n','o');break;// pot-controlled gain
   case 10:E('i','a','R',R());E('a','b','R',R());E('b','g','C',Cv());E('a','m','C',Cv());E('m','o','R',R());OA('b','m','m');E('o','g','R',R());break;// SK + load
   case 11:E('i','a','R',R());E('a','b','R',R());E('b','m','C',Cv());E('i','c','C',Cv());E('c','b','C',Cv());E('c','g','R',R()/2);E('a','g','C',Cv()*2);OA('b','m','m');E('m','o','R',R());E('o','g','C',Cv());break;// twin-T-ish + buffer
   case 12:els.push({k:'P',a:'i',b:'g',w:'w',v:logU(1e3,1e6),pos:rnd(),par:parOf('P')});E('w','n','R',R());E('n','o','R',R());OA('g','n','o');break;// pot volume + inverting
  }
  if(process.env.PASSIDEAL){els.forEach(e=>e.real=false);oas.forEach(u=>u.real=true);return{zmode:false,els,oas,realMode:true,typ}}
  return{zmode:false,els,oas,realMode:rnd()<0.5,typ}}
function expand(cir){const edges=[],ctrl=[];let c=0;const m=()=>'x'+(c++);const real=x=>cir.realMode&&x.real!==false;
  for(const e of cir.els){const p=e.par;
    if(e.k==='P'){const al=Math.min(1-1e-6,Math.max(1e-6,e.pos));if(!real(e)){edges.push({a:e.a,b:e.w,k:'R',v:al*e.v},{a:e.w,b:e.b,k:'R',v:(1-al)*e.v});continue}
      const m1=m(),m2=m(),w0=m();edges.push({a:e.a,b:m1,k:'R',v:al*e.v},{a:m1,b:w0,k:'L',v:al*p.ls},{a:w0,b:m2,k:'L',v:(1-al)*p.ls},{a:m2,b:e.b,k:'R',v:(1-al)*e.v},{a:w0,b:e.w,k:'R',v:p.rw},{a:e.a,b:e.b,k:'C',v:p.cp});continue}
    if(!real(e)){edges.push({a:e.a,b:e.b,k:e.k,v:e.v});continue}
    if(e.k==='C'){const m1=m(),m2=m();edges.push({a:e.a,b:m1,k:'R',v:p.esr},{a:m1,b:m2,k:'L',v:p.esl},{a:m2,b:e.b,k:'C',v:e.v});if(p.rp<1e12)edges.push({a:m2,b:e.b,k:'R',v:p.rp})}
    else{const q=m();if(e.k==='R')edges.push({a:e.a,b:q,k:'R',v:e.v},{a:q,b:e.b,k:'L',v:p.ls});else edges.push({a:e.a,b:q,k:'R',v:p.rdc},{a:q,b:e.b,k:'L',v:e.v});edges.push({a:e.a,b:e.b,k:'C',v:p.cp})}}
  for(const u of cir.oas){if(!(cir.realMode&&u.real)){ctrl.push({t:'nullor',p:u.p,n:u.n,o:u.o});continue}const p=u.par;const pi=m(),ni=m(),oi=m(),mm=m();
    edges.push({a:u.p,b:pi,k:'L',v:p.lin},{a:u.n,b:ni,k:'L',v:p.lin},{a:pi,b:ni,k:'R',v:p.rin},{a:pi,b:ni,k:'C',v:p.cin},{a:oi,b:mm,k:'R',v:p.rout},{a:mm,b:u.o,k:'L',v:p.lout},{a:u.o,b:'g',k:'C',v:p.cout});
    ctrl.push({t:'vcvs',p:pi,n:ni,o:oi,A0:p.a0,wp:2*Math.PI*p.gbw/p.a0})}
  return{edges:edges.filter(e=>e.a!==e.b),ctrl}}
const N=+(process.env.N||150);const list=[];for(let i=0;i<N;i++)list.push(process.env.GEN==='2'?gen2():gen());
const FS=Array.from({length:19},(_,i)=>Math.pow(10,i/2));// 1 Hz .. 1 GHz
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(500);
const rows=[];let worst=0,worstF=0,nErr=0,nSing=0,nDer=0,nDerOK=0,nTC=0;
for(const [ci,cir] of list.entries()){if(process.env.ONLY&&+process.env.ONLY!==ci)continue;
  const r=await p.evaluate(({cir,FS})=>{uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};let j=0;const pos=()=>{const q=[(j%6)*240,Math.floor(j/6)*240];j++;return q};
    for(const e of cir.els){const[x,y]=pos();const q=mkP(e.k,x,y,0,e.v);q.par=Object.assign({},e.par);if(e.real===false)q.real=false;if(e.k==='P'){q.pos=e.pos;add(e.w,q,2)}parts.push(q);add(e.a,q,0);add(e.b,q,1)}
    for(const u of cir.oas){const[x,y]=pos();const q=mkP('OA',x,y,0);q.par=Object.assign({},u.par);q.real=u.real;parts.push(q);add(u.p,q,0);add(u.n,q,1);add(u.o,q,2)}
    const vin=mkP('VIN',0,-400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,-400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,-400);parts.push(vo);add('o',vo,0)}
    for(const k in term){const L=term[k];for(let i=1;i<L.length;i++)wires.push(W_(L[i-1][0],L[i-1][1],L[i][0],L[i][1]))}
    state.parts=parts;state.wires=wires;state.realMode=cir.realMode;state.fmin=1;state.fmax=1e9;state.cursor=1000;assignNames();NET=netlist();
    if(!NET.ok)return{net:NET.err};
    update();const app=FS.map(f=>resp(f)),appZ=FS.map(f=>solve(f,'zin'));
    let h='',st='';try{h=derive()}catch(e){st='EXC '+e.message+' '+e.stack}
    let F1=null;if(DER){const w=f=>2*Math.PI*f;F1=FS.map(f=>cx.div(spValJ(DER.FR.N,w(f),DER.vals),spValJ(DER.FR.D,w(f),DER.vals)))}
    let hz='';try{hz=deriveFor('ohm')}catch(e){st+=' EXCZ '+e.message}let FZ=null;if(DER){const w=f=>2*Math.PI*f;FZ=FS.map(f=>cx.div(spValJ(DER.FR.N,w(f),DER.vals),spValJ(DER.FR.D,w(f),DER.vals)))}
    for(const g of['nyq','spec','smith']){try{deriveFor(g)}catch(e){st+=' '+g+':'+e.message}}
    try{renderSchematic();renderSelBar();renderSlList()}catch(e){st+=' UI:'+e.message}
    return{hs:DER?'':h.replace(/<[^>]+>/g,' ').slice(-160),app,appZ,F1,FZ,st,tc:/too complex|složen/i.test(h),zinInf:!!NET.zinInf,mode:NET.mode}},{cir,FS});
  const ex=expand(cir);const ref=FS.map(f=>hpSolveX(ex.edges,ex.ctrl,f,cir.zmode)),refZ=FS.map(f=>hpSolveX(ex.edges,ex.ctrl,f,true));
  const sing=ref.filter(v=>!isFinite(v[0])||C.abs(v)>1e40).length>=ref.length/2;
  if(r.net){if(process.env.ONLY)console.log('NET',r.net,'sing',sing,JSON.stringify(ref.slice(0,4)));rows.push({ci,err:r.net,sing});if(!sing)console.log('NETERR',ci,r.net);if(sing)nSing++;else nErr++;continue}
  const metr=(a,bb)=>{let bad=0;a=a.slice();bb=bb.slice();for(let i=0;i<a.length;i++){const x=a[i],y=bb[i];const ay=C.abs(y);if(x[0]===Infinity){if(!(isNaN(ay)||ay>1e40))bad=Infinity;a[i]=bb[i]=[0,0];continue}if(isNaN(ay)||ay>1e40){bad=Infinity;continue}}
    const mx=Math.max(...bb.map(C.abs).filter(isFinite),1e-300);let rel=bad;if(mx<1e-40){a.forEach(x=>{rel=Math.max(rel,C.abs(x))});return rel/1e-6}a.forEach((x,i)=>{const y=bb[i],ay=C.abs(y);if(!isFinite(ay)){if(isFinite(C.abs(x))&&!isNaN(y[0]))rel=Math.max(rel,Infinity);return}
      const e=C.abs(C.sub(x,y))/Math.max(ay,1e-9*mx);rel=Math.max(rel,isFinite(e)?e:Infinity)});return rel};const fin=v=>isFinite(v)?v:Infinity;
  const g=fin(metr(r.app,ref)),gz=fin(metr(r.appZ,refZ));
  const fm=r.F1?metr(r.F1,ref):null,fz=r.FZ&&!r.zinInf?metr(r.FZ,refZ):null;if(r.F1){nDer++;if(fm<1e-6)nDerOK++}if(r.tc)nTC++;
  worst=Math.max(worst,g,gz);if(fm!==null)worstF=Math.max(worstF,fm);
  if(process.env.ONLY){const fm2=v=>v.map(c=>c[0].toPrecision(6)+(c[1]<0?'':'+')+c[1].toPrecision(6)+'j');console.log('H app',fm2(r.app).join(' '));console.log('H ref',fm2(ref).join(' '));console.log('Z app',fm2(r.appZ).join(' '));console.log('Z ref',fm2(refZ).join(' '))}const row={hs:r.hs,ci,g,gz,fm,fz,st:r.st,tc:r.tc,mode:r.mode,zinInf:r.zinInf,nOA:cir.oas.length,real:cir.realMode};rows.push(row);
  if(g>1e-8||gz>1e-8||(fm!==null&&fm>1e-6)||r.st)console.log('BAD',JSON.stringify(row))}
fs.writeFileSync(__dirname+'/'+(process.env.GEN==='2'?'otest2.json':'otest.json'),JSON.stringify({rows,list},null,0));
console.log('circuits',list.length,'netErr(not singular)',nErr,'netErr(singular, correct)',nSing,'worst graph rel',worst.toExponential(2),'formulas',nDer,'ok',nDerOK,'worst formula',worstF.toExponential(2),'tooComplex',nTC,'pageerrors',errs.length,errs.slice(0,3));await b.close()})();
