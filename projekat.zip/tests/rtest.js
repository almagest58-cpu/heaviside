const { chromium } = require('playwright');const {exactSolve}=require('./exact.js');
// ---- independent complex MNA solver (does NOT use app code) ----
const C={add:(a,b)=>[a[0]+b[0],a[1]+b[1]],sub:(a,b)=>[a[0]-b[0],a[1]-b[1]],mul:(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]],div:(a,b)=>{const d=b[0]*b[0]+b[1]*b[1];return[(a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d]},abs:a=>Math.hypot(a[0],a[1])};
function gauss(A,b){const n=b.length;for(let c=0;c<n;c++){let p=c;for(let r=c+1;r<n;r++)if(C.abs(A[r][c])>C.abs(A[p][c]))p=r;[A[c],A[p]]=[A[p],A[c]];[b[c],b[p]]=[b[p],b[c]];if(C.abs(A[c][c])===0)return null;
  for(let r=c+1;r<n;r++){const f=C.div(A[r][c],A[c][c]);for(let k=c;k<n;k++)A[r][k]=C.sub(A[r][k],C.mul(f,A[c][k]));b[r]=C.sub(b[r],C.mul(f,b[c]))}}
  const x=Array(n);for(let r=n-1;r>=0;r--){let s=b[r];for(let k=r+1;k<n;k++)s=C.sub(s,C.mul(A[r][k],x[k]));x[r]=C.div(s,A[r][r])}return x}
const Y=(e,w)=>e.k==='R'?[1/e.v,0]:e.k==='L'?[0,-1/(w*e.v)]:[0,w*e.v];
function expand(edges,real){if(!real)return edges;const out=[];let c=0;for(const e of edges){const m=()=>'x'+(c++);const p=e.par;
  if(e.k==='C'){const m1=m(),m2=m();out.push({a:e.a,b:m1,k:'R',v:p.esr},{a:m1,b:m2,k:'L',v:p.esl},{a:m2,b:e.b,k:'C',v:e.v});if(p.rp<1e12)out.push({a:m2,b:e.b,k:'R',v:p.rp})}
  else{const q=m();if(e.k==='R')out.push({a:e.a,b:q,k:'R',v:e.v},{a:q,b:e.b,k:'L',v:p.ls});else out.push({a:e.a,b:q,k:'R',v:p.rdc},{a:q,b:e.b,k:'L',v:e.v});out.push({a:e.a,b:e.b,k:'C',v:p.cp})}}return out}
function indep(edges,f,zmode){const w=2*Math.PI*f;const nodes=[...new Set(edges.flatMap(e=>[e.a,e.b]))].filter(n=>n!=='g'&&(zmode||n!=='i'));const ix={};nodes.forEach((n,i)=>ix[n]=i);const n=nodes.length;
  const A=nodes.map(()=>nodes.map(()=>[0,0])),b=nodes.map(()=>[0,0]);
  for(const e of edges){const y=Y(e,w);const ia=ix[e.a],ib=ix[e.b];if(ia!==undefined)A[ia][ia]=C.add(A[ia][ia],y);if(ib!==undefined)A[ib][ib]=C.add(A[ib][ib],y);
    if(ia!==undefined&&ib!==undefined){A[ia][ib]=C.sub(A[ia][ib],y);A[ib][ia]=C.sub(A[ib][ia],y)}
    if(!zmode){if(e.a==='i'&&ib!==undefined)b[ib]=C.add(b[ib],y);if(e.b==='i'&&ia!==undefined)b[ia]=C.add(b[ia],y)}}
  if(zmode)b[ix['i']]=[1,0];const x=gauss(A,b);if(!x)return[NaN,NaN];return zmode?x[ix['i']]:x[ix['o']]}
// ---- random circuits ----
let seed=+(process.env.SEED||12345);const rnd=()=>{seed=(seed*1103515245+12345)%2147483648;return seed/2147483648};const pick=a=>a[Math.floor(rnd()*a.length)];
const logU=(a,b)=>Math.pow(10,Math.log10(a)+rnd()*(Math.log10(b)-Math.log10(a)));
function gen(real){const zmode=rnd()<0.2;const m=Math.floor(rnd()*4);const nodes=['g','i',...(zmode?[]:['o']),...Array.from({length:m},(_,j)=>'n'+j)];
  const edges=[];const mk=(a,b)=>{const k=pick(['R','L','C']);const v=k==='R'?logU(1,1e5):k==='L'?logU(1e-7,1e-1):logU(1e-11,1e-4);
    const par=k==='C'?{esr:logU(1e-3,1),esl:logU(1e-10,1e-8),rp:rnd()<0.5?1e12:logU(1e5,1e9)}:k==='R'?{ls:logU(1e-10,1e-7),cp:logU(1e-14,1e-11)}:{rdc:logU(1e-2,10),cp:logU(1e-13,1e-10)};return{a,b,k,v,par}};
  const order=nodes.slice().sort(()=>rnd()-0.5);for(let j=1;j<order.length;j++)edges.push(mk(order[j],pick(order.slice(0,j))));
  const extra=Math.floor(rnd()*4);for(let j=0;j<extra;j++){let a=pick(nodes),b=pick(nodes);if(a===b)continue;edges.push(mk(a,b))}
  return{zmode,edges,real}}
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{require('fs').appendFileSync('prog.log','  '+m.text()+'\n')});
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html')+'',{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});console.log('loaded');await p.waitForTimeout(500);
const FS=Array.from({length:14},(_,i)=>Math.pow(10,0.3+i*7.4/13));
const stats={total:0,graphFail:0,formulaFail:0,zFormulaFail:0,noDeriv:0,tooLong:0,sectionErr:0,netErr:0};const worst=[];const fails=[];
const N=+process.argv[2]||150;for(let it=0;it<N;it++){const cir=gen(it>=N*2/3);stats.total++;const t0=Date.now();if(process.argv[3]&&it<+process.argv[3])continue;require('fs').appendFileSync('prog.log','start '+it+' '+JSON.stringify(cir)+'\n');
  const r=await p.evaluate(({cir,FS})=>{uid=1;const parts=[],wires=[];const term={};const add=(node,part,end)=>{(term[node]=term[node]||[]).push([part,end])};
    cir.edges.forEach((e,j)=>{const q=mkP(e.k,j*200,0,0,e.v);q.par=Object.assign({},e.par);parts.push(q);add(e.a,q,0);add(e.b,q,1)});
    const vin=mkP('VIN',0,400);parts.push(vin);add('i',vin,0);const g=mkP('GND',200,400);parts.push(g);add('g',g,0);if(!cir.zmode){const vo=mkP('VOUT',400,400);parts.push(vo);add('o',vo,0)}
    for(const k in term){const L=term[k];for(let j=1;j<L.length;j++)wires.push(W_(L[j-1][0],L[j-1][1],L[j][0],L[j][1]))}
    state.parts=parts;state.wires=wires;state.realMode=cir.real;state.fmin=1;state.fmax=1e8;state.cursor=1000;const T0=performance.now();const mk=n=>console.log(n+' '+Math.round(performance.now()-T0));assignNames();NET=netlist();mk('net');update();mk('upd');
    if(!NET.ok)return{net:NET.err};
    const app=FS.map(f=>resp(f)),appZ=FS.map(f=>solve(f,'zin'));
    const ev=(FR,f)=>{const w=2*Math.PI*f;return cx.div(spValJ(FR.N,w,DER.vals),spValJ(FR.D,w,DER.vals))};
    let h1='',h2='',exc='';try{h1=derive()}catch(e){exc+='bode:'+e.message+' ';DER=null}const F1=DER?FS.map(f=>ev(DER.FR,f)):null;mk('bode');const tc=/too complex/.test(h1);const tl=/too long to display/.test(h1+h2);
    try{h2=derive({forceZ:true})}catch(e){exc+='z:'+e.message+' ';DER=null}const F2=DER?FS.map(f=>ev(DER.FR,f)):null;
    mk('z');let secErr='';for(const g of['nyq','spec','smith']){try{const h=deriveFor(g);mk(g);if(/NaN|undefined/.test(h.replace(/<[^>]*>/g,'')))secErr+=g+':nan '}catch(e){secErr+=g+':'+e.message+' '}}
    return{app,appZ,F1,F2,tl,tc,secErr:secErr+exc,mode:NET.mode,desc:exc?JSON.stringify(cir.edges.map(e=>e.a+'-'+e.k+'-'+e.b))+(cir.zmode?' Z':' H'):''}},{cir,FS});
  if(r.net){stats.netErr++;fails.push(['net',it,r.net]);continue}
  const relErr0=(a,bb)=>{const sc=Math.max(...bb.map(C.abs).filter(isFinite));if(sc===0&&Math.max(...a.map(C.abs))<1e-12)return 0;let m=0;a.forEach((x,i)=>{const e=C.abs(C.sub(x,bb[i]))/Math.max(C.abs(bb[i]),1e-9*sc);m=Math.max(m,isFinite(e)?e:Infinity)});return m};
  const ex=expand(cir.edges,cir.real);const ref=FS.map(f=>exactSolve(ex,f,cir.zmode)),refZ=FS.map(f=>exactSolve(ex,f,true));const fl=FS.map(f=>indep(ex,f,cir.zmode));if(relErr0(fl,ref)>1e-6)stats.floatRefOff=(stats.floatRefOff||0)+1;
  const relErr=(a,bb)=>{const sc=Math.max(...bb.map(C.abs).filter(isFinite));if(sc===0&&Math.max(...a.map(C.abs))<1e-12)return 0;let m=0;a.forEach((x,i)=>{const e=C.abs(C.sub(x,bb[i]))/Math.max(C.abs(bb[i]),1e-9*sc);m=Math.max(m,isFinite(e)?e:Infinity)});return m};
  const eG=Math.max(relErr(r.app,ref),relErr(r.appZ,refZ));if(!(eG<1e-6)){stats.graphFail++;fails.push(['graph',it,eG])}
  if(!r.F1)stats.noDeriv++;else{const e=relErr(r.F1,ref);worst.push(e);if(!(e<1e-6)){stats.formulaFail++;fails.push(['formula',it,e,cir.edges.length,cir.real])}}
  if(r.F2){const e=relErr(r.F2,refZ);if(!(e<1e-6)){stats.zFormulaFail++;fails.push(['zformula',it,e,cir.edges.length,cir.real])}}
  if(r.tl)stats.tooLong++;if(r.tc)stats.tooComplex=(stats.tooComplex||0)+1;stats.maxMs=Math.max(stats.maxMs||0,Date.now()-t0);
  if(it%10===0)console.log('#'+it,Date.now()-t0);if(r.secErr){stats.sectionErr++;fails.push(['sec',it,r.secErr,r.desc])}}
worst.sort((a,b)=>b-a);console.log(JSON.stringify(stats));console.log('worst formula rel errors',worst.slice(0,5).map(x=>x.toExponential(2)).join(' '));console.log(JSON.stringify(fails.slice(0,20)));console.log('pageerrors',errs.slice(0,5));await b.close()})();
