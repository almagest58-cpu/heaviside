// exact complex-rational Gaussian elimination (BigInt), oracle for tests
const gcd=(a,b)=>{a=a<0n?-a:a;b=b<0n?-b:b;while(b){[a,b]=[b,a%b]}return a};
const R=(n,d=1n)=>{if(d<0n){n=-n;d=-d}const g=gcd(n,d)||1n;return{n:n/g,d:d/g}};
const fromF=x=>{if(x===0)return R(0n);const buf=new DataView(new ArrayBuffer(8));buf.setFloat64(0,x);const hi=buf.getUint32(0),lo=buf.getUint32(4);
  const sign=hi>>>31?-1n:1n;const e=(hi>>>20)&0x7ff;let m=(BigInt(hi&0xfffff)<<32n)|BigInt(lo);let ex;if(e===0){ex=-1074}else{m|=1n<<52n;ex=e-1075}
  return ex>=0?R(sign*m*(1n<<BigInt(ex))):R(sign*m,1n<<BigInt(-ex))};
const ra=(a,b)=>R(a.n*b.d+b.n*a.d,a.d*b.d),rs=(a,b)=>R(a.n*b.d-b.n*a.d,a.d*b.d),rm=(a,b)=>R(a.n*b.n,a.d*b.d),rdv=(a,b)=>R(a.n*b.d,a.d*b.n);
const toF=a=>{// accurate BigInt ratio to float
  if(a.n===0n)return 0;const neg=a.n<0n;let n=neg?-a.n:a.n,d=a.d;const sh=BigInt(n.toString(2).length-d.toString(2).length-60);let q=sh>=0n?n/(d<<sh):(n<<(-sh))/d;let v=Number(q)*Math.pow(2,Number(sh));return neg?-v:v};
const Z0={re:R(0n),im:R(0n)};
const ca=(a,b)=>({re:ra(a.re,b.re),im:ra(a.im,b.im)}),csb=(a,b)=>({re:rs(a.re,b.re),im:rs(a.im,b.im)}),
cm=(a,b)=>({re:rs(rm(a.re,b.re),rm(a.im,b.im)),im:ra(rm(a.re,b.im),rm(a.im,b.re))}),
cd=(a,b)=>{const den=ra(rm(b.re,b.re),rm(b.im,b.im));const num=cm(a,{re:b.re,im:R(-b.im.n,b.im.d)});return{re:rdv(num.re,den),im:rdv(num.im,den)}};
const isZ=a=>a.re.n===0n&&a.im.n===0n;
function exactSolve(edges,f,zmode){const w=fromF(2*Math.PI*f);
  const Y=e=>{const v=fromF(e.v);if(e.k==='R')return{re:rdv(R(1n),v),im:R(0n)};if(e.k==='L')return{re:R(0n),im:R(-1n*rdv(R(1n),rm(w,v)).n,rdv(R(1n),rm(w,v)).d)};return{re:R(0n),im:rm(w,v)}};
  const nodes=[...new Set(edges.flatMap(e=>[e.a,e.b]))].filter(n=>n!=='g'&&(zmode||n!=='i'));const ix={};nodes.forEach((n,i)=>ix[n]=i);const n=nodes.length;
  const A=nodes.map(()=>nodes.map(()=>Z0)),b=nodes.map(()=>Z0);
  for(const e of edges){const y=Y(e);const ia=ix[e.a],ib=ix[e.b];if(ia!==undefined)A[ia][ia]=ca(A[ia][ia],y);if(ib!==undefined)A[ib][ib]=ca(A[ib][ib],y);
    if(ia!==undefined&&ib!==undefined){A[ia][ib]=csb(A[ia][ib],y);A[ib][ia]=csb(A[ib][ia],y)}
    if(!zmode){if(e.a==='i'&&ib!==undefined)b[ib]=ca(b[ib],y);if(e.b==='i'&&ia!==undefined)b[ia]=ca(b[ia],y)}}
  if(zmode)b[ix['i']]={re:R(1n),im:R(0n)};
  for(let c=0;c<n;c++){let p=c;while(p<n&&isZ(A[p][c]))p++;if(p===n)return[NaN,NaN];[A[c],A[p]]=[A[p],A[c]];[b[c],b[p]]=[b[p],b[c]];
    for(let r=c+1;r<n;r++){if(isZ(A[r][c]))continue;const q=cd(A[r][c],A[c][c]);for(let k=c;k<n;k++)A[r][k]=csb(A[r][k],cm(q,A[c][k]));b[r]=csb(b[r],cm(q,b[c]))}}
  const x=Array(n);for(let r=n-1;r>=0;r--){let s=b[r];for(let k=r+1;k<n;k++)s=csb(s,cm(A[r][k],x[k]));x[r]=cd(s,A[r][r])}
  const out=zmode?x[ix['i']]:x[ix['o']];return[toF(out.re),toF(out.im)]}
module.exports={exactSolve};
