// Thyristors (SCR, triac, diac, quadrac) in the time domain: the app's netlist (trNetlist: the thyristor models expanded into
// transistors, breakdown diodes and resistors) is simulated by the app and, written out unchanged, by ngspice; every node voltage
// is compared over the whole run (with ±1e-3 of the time scale allowed for edge timing, as in ostest).
const { chromium } = require('playwright');const fs=require('fs'),cp=require('child_process');
const NGS=process.env.NGSPICE||'/tmp/claude-0/-home-claude/3126b669-5ac5-5936-b9ef-b8aba5bf071a/scratchpad/ngs/inst/bin/ngspice';
const WD=fs.mkdtempSync(require('os').tmpdir()+'/th-');
const VT=1.380649e-23*300.15/1.602176634e-19,TC=VT*1.6021918e-19/1.3806226e-23-273.15;const p17=v=>(+v).toPrecision(17);
// the app's own waveform definitions (lines 14–26 of tests/tran.js) give every corner, phase included, as one period of PWL
const TRW=(()=>{const src=fs.readFileSync(__dirname+'/tran.js','utf8');const f=n=>{const i=src.indexOf('function '+n+'(');let d=0,j=src.indexOf('{',i);for(;;j++){if(src[j]==='{')d++;else if(src[j]==='}'&&!--d)break}return src.slice(i,j+1)};
  return new Function(['trEdge','trDuty','trWave','trCorners'].map(f).join('\n')+';return{trWave,trCorners}')()})();
function wSpice(w,tEnd){const A=+w.amp||0;if(w.type==='dc')return'DC '+p17(A);const T=1/w.f;
  if(w.type==='sin'&&!w.ph)return`SIN(${p17(+w.off||0)} ${p17(A)} ${p17(w.f)} 0 0)`;if(w.type==='sin')return null;
  const p=(w.ph||0)/360;const ts=new Set([0,T]);for(const c of TRW.trCorners(w)){let u=(c-p)%1;if(u<0)u+=1;ts.add(u*T)}
  /* written out over the whole run (ngspice's r= repeat does not always put breakpoints on the repeated corners) */
  const L=[...ts].sort((x,y)=>x-y).filter(t=>t<T);const pts=[];
  for(let k=0;k*T<=tEnd*1.001+T;k++)for(const t of L)pts.push(p17(k*T+t)+' '+p17(TRW.trWave(w,t)));
  return`PWL(${pts.join(' ')})`}
function spice(C,tag,tEnd,hmax){const nn=i=>i<0?'0':'n'+i;const L=['* '+tag,'OPTS'];
  C.R.forEach((e,j)=>L.push(`R${j} ${nn(e.a)} ${nn(e.b)} ${p17(1/e.g)}`));C.C.forEach((e,j)=>L.push(`C${j} ${nn(e.a)} ${nn(e.b)} ${p17(e.c)}`));(C.L||[]).forEach((e,j)=>L.push(`L${j} ${nn(e.a)} ${nn(e.b)} ${p17(e.l)}`));
  for(const k of ['I','xf','sw','oa'])if((C[k]||[]).length)throw new Error('netlist has '+k);
  C.dev.forEach((d,j)=>{if(d.cbe||d.cbc)throw new Error('fixed caps')});
  C.V.forEach((e,j)=>{if(e.w.type==='sin'&&e.w.ph)L.push(`BV${j} ${nn(e.a)} ${nn(e.b)} V=${p17(e.w.off||0)}+${p17(e.w.amp)}*sin(${p17(2*Math.PI*e.w.f)}*time+${p17(e.w.ph*Math.PI/180)})`);else L.push(`V${j} ${nn(e.a)} ${nn(e.b)} ${wSpice(e.w,tEnd)}`)});
  C.dev.forEach((d,j)=>{const p=d.par;if(d.t==='D')L.push(`D${j} ${nn(d.a)} ${nn(d.k)} DM${j}`,`.model DM${j} D(IS=${p17(p.is)} N=${p17(p.n||1)}${p.bv>0?' BV='+p17(p.bv)+' IBV='+p17(p.ibv):''} CJO=${p17(p.cj||0)} VJ=${p17(p.vj||0.7)} M=${p17(p.m||0.5)} TT=${p17(p.tt||0)})`);
    else if(d.t==='Q'){const q=d.qr||{};L.push(`Q${j} ${nn(d.c)} ${nn(d.b)} ${nn(d.e)} ${d.pol>0?nn(d.c):nn(d.b)} QM${j}`,`.model QM${j} ${d.pol>0?'NPN':'PNP'}(IS=${p17(p.is)} BF=${p17(p.bf)} BR=${p17(p.br)}${isFinite(p.va)&&p.va>0?' VAF='+p17(p.va):''}${p.ikf>0?' IKF='+p17(p.ikf):''} CJE=${p17(q.cje||0)} VJE=${p17(q.vje||0.75)} MJE=${p17(q.mje||0.33)} CJC=${p17(q.cjc||0)} VJC=${p17(q.vjc||0.75)} MJC=${p17(q.mjc||0.33)} TF=${p17(q.tf||0)} TR=${p17(q.tr||0)} CJS=0)`)}
    else if(d.t==='X'){/* diac: V = f(I) + dψ(I)/dt as a current-controlled behavioural source (the same formulas as evalDiac/diacPsi) */
      const I=`i(VX${j})`,u=`(abs(${I})/${p17(p.ibo)})`,f=`(${u}<=1 ? ${p17(p.vbo)}*(1-pwr(1-${u},${p.m})) : ${p17(p.vbo)}-${p17(0.5*p.A)}*ln(1+(${u}-1)*(${u}-1))+${p17(p.ron*p.ibo)}*(${u}-1))`;
      /* dψ/dt as the current of a 1 F capacitor whose voltage is held at ψ(I) (this ngspice has no ddt()). ngspice gives up at the
         breakover of the ideal diac (τ = 1 ns: "timestep too small"); there it gets τ = 100 ns, which shifts the µs-fast edges only
         (the comparison forgives 1e-3 of the time scale) */
      L.push(`VX${j} ${nn(d.a)} nx${j} 0`,`BX${j} nx${j} ${nn(d.b)} V=sgn(${I})*${f}+i(VQ${j})`,`BQ${j} qx${j} 0 V=${p17(p.tau*p.A)}*sgn(${I})*ln(1+abs(${I})/${p17(p.ibo)})`,`VQ${j} qx${j} qc${j} 0`,`CQ${j} qc${j} 0 1`);if(p.cj>0)L.push(`CX${j} ${nn(d.a)} ${nn(d.b)} ${p17(p.cj)}`)}
    else throw new Error('dev '+d.t)});
  L.push('.control','set filetype=ascii',`tran ${p17(hmax/(process.env.SPDIV||10))} ${p17(tEnd)} 0 ${p17(hmax/(process.env.SPDIV||10))}`,`write ${WD}/${tag}.raw `+Array.from({length:C.n},(_,i)=>'v(n'+i+')').join(' '),'.endc','.end');
  /* ngspice gives up ("timestep too small") on some of the sharp latch edges at the tightest tolerances; it is retried looser */
  const file=`${WD}/${tag}.raw`;let txt=null;
  for(const o of ['reltol=1e-6 abstol=1e-12 chgtol=1e-16 method=gear maxord=2','reltol=1e-5 abstol=1e-12 chgtol=1e-16 method=gear maxord=2','reltol=1e-5 abstol=1e-12 chgtol=1e-16','reltol=1e-4 abstol=1e-12 chgtol=1e-14','reltol=1e-3 abstol=1e-12 chgtol=1e-14 gmin=1e-15']){
    L[1]=`.options ${o} vntol=1e-9 itl4=500 itl1=500 temp=${TC.toPrecision(15)} tnom=${TC.toPrecision(15)}`;fs.writeFileSync(`${WD}/${tag}.cir`,L.join('\n'));try{fs.unlinkSync(file)}catch(e){}
    let out='';try{out=cp.execFileSync(NGS,['-b',`${WD}/${tag}.cir`],{encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:600000})}catch(e){out=String(e.stdout||'')+String(e.stderr||'')+(e.signal?' abort':'')}
    if(/too small|aborted/i.test(out)||!fs.existsSync(file))continue;txt=fs.readFileSync(file,'utf8');if(txt.includes('Values:')){spice.opt=o;break}txt=null}
  if(!txt)return null;const nv=+txt.match(/No. Variables:\s*(\d+)/)[1];
  const vals=txt.split('Values:')[1].trim().split(/\s+/);const rows=[];for(let i=0;i<vals.length;){i++;const r=[];for(let v=0;v<nv;v++)r.push(+vals[i++]);rows.push(r)}return rows}
function rangeOn(ts,ys,a,b){let lo=Math.min(interp(ts,ys,a),interp(ts,ys,b)),hi=Math.max(interp(ts,ys,a),interp(ts,ys,b));let i0=0,i1=ts.length;
  {let l=0,h=ts.length;while(l<h){const m=(l+h)>>1;if(ts[m]<=a)l=m+1;else h=m}i0=l}for(let i=i0;i<ts.length&&ts[i]<b;i++){if(ys[i]<lo)lo=ys[i];if(ys[i]>hi)hi=ys[i]}return[lo,hi]}
function interp(ts,ys,t){let lo=0,hi=ts.length-1;if(t<=ts[0])return ys[0];if(t>=ts[hi])return ys[hi];while(hi-lo>1){const m=(lo+hi)>>1;if(ts[m]<=t)lo=m;else hi=m}const a=ts[lo],b=ts[hi];return ys[lo]+(ys[hi]-ys[lo])*(t-a)/(b-a)}
/* test circuits: [name, builder (runs in the page, returns {parts, wires}), real mode, run time, largest step, time scale] */
const CASES=[
 ['scr latch / turn-off (BT151)',`const sa=mkP('SG',0,0,1,12),g0=mkP('GND',0,80),rl=mkP('R',0,0,0,100),s=mkP('SCR',160,0,1),g1=mkP('GND',160,80),sg=mkP('SG',-160,0,1,5),g2=mkP('GND',-160,80),rg=mkP('R',-160,0,0,1e3);
   sa.wf='pul';sa.sg={f:50,off:0,ph:0,duty:60,tr:1e-5};sg.wf='pul';sg.sg={f:50,off:0,ph:0,duty:5,tr:1e-6};s.ty='bt151';s.sc=thyPre('SCR','bt151');
   return{parts:[sa,g0,rl,s,g1,sg,g2,rg],wires:[W_(rl,1,s,0),W_(rg,1,s,2)]}`,0.04,2e-5,0.02],
 ['scr phase control 50 V (2N5064)',`const sa=mkP('SG',0,0,1,50),g0=mkP('GND',0,80),rl=mkP('R',0,0,0,220),s=mkP('SCR',160,0,1),g1=mkP('GND',160,80),sg=mkP('SG',-160,0,1,3),g2=mkP('GND',-160,80),rg=mkP('R',-160,0,0,4.7e3);
   sa.wf='sin';sa.sg={f:50,off:0,ph:0,duty:50,tr:1e-6};sg.wf='pul';sg.sg={f:50,off:0,ph:60,duty:3,tr:1e-6};s.ty='2n5064';s.sc=thyPre('SCR','2n5064');
   return{parts:[sa,g0,rl,s,g1,sg,g2,rg],wires:[W_(rl,1,s,0),W_(rg,1,s,2)]}`,0.04,2e-5,0.02],
 ['scr breakover (real)',`const sa=mkP('SG',0,0,1,350),g0=mkP('GND',0,80),rl=mkP('R',0,0,0,1e4),s=mkP('SCR',160,0,1),g1=mkP('GND',160,80),rg=mkP('R',160,160,1,1e3);
   sa.wf='tri';sa.sg={f:25,off:0,ph:0,duty:50,tr:1e-6};s.sc=thyPre('SCR','gen');
   return{parts:[sa,g0,rl,s,g1,rg],wires:[W_(rl,1,s,0),W_(rg,0,s,2),W_(rg,1,g1,0)]}`,0.04,2e-5,0.04],
 ['triac QI/QIII (BT136)',`const sa=mkP('SG',0,0,1,100),g0=mkP('GND',0,80),rl=mkP('R',0,0,0,100),s=mkP('TRI',160,0,1),g1=mkP('GND',160,80),sg=mkP('SG',-160,0,1,5),g2=mkP('GND',-160,80),rg=mkP('R',-160,0,0,470);
   sa.wf='sin';sa.sg={f:50,off:0,ph:0,duty:50,tr:1e-6};sg.wf='sq';sg.sg={f:50,off:0,ph:30,duty:50,tr:1e-5};s.ty='bt136';s.sc=thyPre('TRI','bt136');
   return{parts:[sa,g0,rl,s,g1,sg,g2,rg],wires:[W_(rl,1,s,0),W_(rg,1,s,2)]}`,0.04,2e-5,0.02],
 ['triac QII/QIII (negative gate pulses)',`const sa=mkP('SG',0,0,1,100),g0=mkP('GND',0,80),rl=mkP('R',0,0,0,100),s=mkP('TRI',160,0,1),g1=mkP('GND',160,80),sg=mkP('SG',-160,0,1,-6),g2=mkP('GND',-160,80),rg=mkP('R',-160,0,0,330);
   sa.wf='sin';sa.sg={f:50,off:0,ph:0,duty:50,tr:1e-6};sg.wf='pul';sg.sg={f:100,off:0,ph:40,duty:5,tr:1e-6};s.sc=thyPre('TRI','gen');
   return{parts:[sa,g0,rl,s,g1,sg,g2,rg],wires:[W_(rl,1,s,0),W_(rg,1,s,2)]}`,0.04,2e-5,0.02],
 ['diac trigger from an RC on 230 V (DB3)',`const v=mkP('SG',0,0,1,325),g0=mkP('GND',0,80),r=mkP('R',0,0,0,4.7e4),c=mkP('C',80,0,1,1e-7),g1=mkP('GND',80,80),d=mkP('DIAC',80,0,0),rl=mkP('R',160,0,1,1e3),g2=mkP('GND',160,80);
   v.wf='sin';v.sg={f:50,off:0,ph:0,duty:50,tr:1e-6};d.ty='db3';d.sc=thyPre('DIAC','db3');return{parts:[v,g0,r,c,g1,d,rl,g2],wires:[]}`,0.04,2e-5,0.02],
 ['diac relaxation oscillator 60 V DC (DB3)',`const v=mkP('SG',0,0,1,60),g0=mkP('GND',0,80),r=mkP('R',0,0,0,1e5),c=mkP('C',80,0,1,1e-7),g1=mkP('GND',80,80),d=mkP('DIAC',80,0,0),rl=mkP('R',160,0,1,100),g2=mkP('GND',160,80);
   v.wf='pul';v.sg={f:10,off:0,ph:0,duty:99,tr:1e-6};/* switched on at t = 0 */d.ty='db3';d.sc=thyPre('DIAC','db3');return{parts:[v,g0,r,c,g1,d,rl,g2],wires:[]}`,0.03,2e-5,0.03/* a free-running oscillator: the edges drift slowly */],
 ['triac QIV (BT136, positive gate pulses, T2 negative)',`const sa=mkP('SG',0,0,1,100),g0=mkP('GND',0,80),rl=mkP('R',0,0,0,100),s=mkP('TRI',160,0,1),g1=mkP('GND',160,80),sg=mkP('SG',-160,0,1,6),g2=mkP('GND',-160,80),rg=mkP('R',-160,0,0,330);
   sa.wf='sin';sa.sg={f:50,off:0,ph:0,duty:50,tr:1e-6};sg.wf='pul';sg.sg={f:100,off:0,ph:40,duty:5,tr:1e-6};s.ty='bt136';s.sc=thyPre('TRI','bt136');
   return{parts:[sa,g0,rl,s,g1,sg,g2,rg],wires:[W_(rl,1,s,0),W_(rg,1,s,2)]}`,0.04,2e-5,0.02],
 ['dimmer: diac + triac',`return EXAMPLES.o_dim.build()`,0.04,2e-5,0.02],
 ['dimmer: quadrac (Q4008LT)',`return EXAMPLES.o_qdr.build()`,0.04,2e-5,0.02],
 ['scr dV/dt (real, 400 V edge 1 µs)',`const sa=mkP('SG',0,0,1,400),g0=mkP('GND',0,80),rl=mkP('R',0,0,0,1e3),s=mkP('SCR',160,0,1),g1=mkP('GND',160,80);
   sa.wf='pul';sa.sg={f:1000,off:0,ph:0,duty:50,tr:1e-6};s.sc=Object.assign(thyPre('SCR','gen'),{cj:2e-9});
   return{parts:[sa,g0,rl,s,g1],wires:[]}`,0.002,1e-6,0.001]];
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:844}})).newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'../app/src/main/assets/index.html'),{waitUntil:'domcontentloaded'});await p.evaluate(()=>localStorage.clear());await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(400);
let worst=0,n=0,fail=0,bad=0;
for(const [nm,src,tEnd,hmax0,per] of CASES)for(const real of [false,true]){if(process.env.ONLY&&!nm.includes(process.env.ONLY))continue;if(nm.includes('(real')&&!real)continue;
  const RT=+(process.env.RTOL||1e-6),TF=/relaxation|quadrac/.test(nm)?1e-6:1e-7;const hmax=+(process.env.HMAX||hmax0);
  const runApp=(RT,hmax,TF)=>p.evaluate(({src,real,tEnd,hmax,RT,TF})=>{uid=1;OSC.run=false;const B=new Function(src)();state.parts=B.parts;state.wires=B.wires;state.realMode=real;state.std=null;
    for(const q of state.parts)if(isThyK(q.kind))q.real=true;assignNames();state.osc={ch:[],win:0};const nl=trNetlist();if(nl.err)return{err:nl.err};
    /* ideal diacs (τ = 1 ns) are too fast for ngspice: for that comparison both simulators get τ = TF */
    let fast=false;for(const d of nl.C.dev)if(d.t==='X'&&d.par.tau<TF){d.par.tau=TF;fast=TF}const hasX=nl.C.dev.some(d=>d.t==='X');
    const C=JSON.parse(JSON.stringify(nl.C,(k,v)=>k==='p'?undefined:v===Infinity?1e308:v));const S=trCreate(nl.C,{rtol:RT});if(!S.dcop(false))return{err:'dcop'};
    const T=[0],Y=[Array.from(S.x.slice(0,nl.C.n))];const ok=S.run(tEnd,hmax,(t,x)=>{T.push(t);Y.push(Array.from(x.slice(0,nl.C.n)))});if(!ok)return{err:'run at '+S.t};return{C,T,Y,steps:S.stats,nExt:nl.nExt,fast,hasX}},{src,real,tEnd,hmax,RT,TF});
  /* largest difference on the pins' nodes and on the internal nodes between the app run r and a reference (times st, rows ys[k]) */
  const cmp=(r,st,yk)=>{let e=0,eAt=null,ei=0,eiAt=null;const nch=r.C.n;
    for(let k=0;k<nch;k++){const ya=r.Y.map(y=>y[k]),ys=yk(k);let mx=-Infinity,mn=Infinity;ys.forEach(v=>{mx=Math.max(mx,v);mn=Math.min(mn,v)});const rng=Math.max(mx-mn,Math.abs(mx),Math.abs(mn),1e-3);
      const tw=1e-3*per;let ek=0,tk=0;for(let i=0;i<=2000;i++){const t=tEnd*i/2000;const bb=interp(st,ys,t);
        /* the smallest |app(t + δ) − reference(t)| over |δ| ≤ tw: the app curve is continuous, so it is the distance to its range on the window */
        const[lo,hi]=rangeOn(r.T,ya,t-tw,t+tw);const d=(bb<lo?lo-bb:bb>hi?bb-hi:0)/rng;if(d>ek){ek=d;tk=t}}
      const at=[k,(tk*1e3).toFixed(3)+' ms'];if(k<r.nExt){if(ek>e){e=ek;eAt=at}}else if(ek>ei){ei=ek;eiAt=at}}return{e,eAt,ei,eiAt}};
  const TH=+(process.env.TH||5e-3);
  const report=(lab,r,c,extra)=>{worst=Math.max(worst,c.e);if(c.e>TH)bad++;
    /* pass/fail is on the pins' nodes; nodes inside the thyristor models are reported too (a junction node with both junctions off is
       held only by ~1e-14 A leakage, so its voltage is not well defined and may differ while nothing outside depends on it) */
    console.log((c.e>TH?'DIFF ':'ok   ')+lab.padEnd(46),real?'real ':'ideal','pins',String(r.nExt).padStart(2),'err',c.e.toExponential(2),'at',JSON.stringify(c.eAt).padEnd(18),'| internal',r.C.n-r.nExt,'err',c.ei.toExponential(2),'| steps',r.steps.steps,extra)};
  let r=await runApp(RT,hmax,TF);const tag=(n++)+'';if(r.err){fail++;console.log('APPFAIL',nm,real,r.err);continue}
  let sp=spice(r.C,tag,tEnd,hmax);
  /* ngspice still gives up with τ = 100 ns: both get τ = 1 µs */
  if((!sp||sp[sp.length-1][0]<tEnd*0.999)&&r.fast&&r.fast<1e-6){const r2=await runApp(RT,hmax,1e-6);if(!r2.err){const sp2=spice(r2.C,tag,tEnd,hmax);if(sp2&&sp2[sp2.length-1][0]>=tEnd*0.999){r=r2;sp=sp2}}}
  if(!sp||sp[sp.length-1][0]<tEnd*0.999){if(!r.fast){fail++;console.log('SPFAIL',nm,real)}else console.log('       '+nm.padEnd(46),'ideal: ngspice gives up on this one ("timestep too small") also with τ = 1 µs; checked against itself below')}
  else{const st=sp.map(q=>q[0]),c=cmp(r,st,k=>sp.map(q=>q[k+1]));report(nm,r,c,'| ngspice '+spice.opt.split(' ')[0]+(r.fast?' | diac τ → '+r.fast*1e9+' ns':''));
    if(process.env.DBG&&c.e>TH){const k=process.env.NODE!=null?+process.env.NODE:c.eAt[0];const t0=+(process.env.T0||0),t1=+(process.env.T1||tEnd);for(let i=0;i<=40;i++){const t=t0+(t1-t0)*i/40;console.log((t*1e3).toFixed(3),interp(r.T,r.Y.map(y=>y[k]),t).toPrecision(6),interp(st,sp.map(q=>q[k+1]),t).toPrecision(6))}}}
  /* the diac with its own τ (1 ns ideal, which ngspice cannot follow): the app against itself with 10× tighter tolerance and 1/5 of the step */
  if(r.fast){const a=await runApp(RT,hmax,0),ref=await runApp(RT/10,hmax/5,0);n++;if(a.err||ref.err){fail++;console.log('APPFAIL',nm,'ideal τ = 1 ns',a.err||ref.err)}
    else report(nm+(real?' (own τ, self)':' (τ = 1 ns, self)'),a,cmp(a,ref.T,k=>ref.Y.map(y=>y[k])),'| app with rtol '+RT/10+', step/5')}}
console.log('cases',n,'not run',fail,'over tolerance',bad,'worst',worst.toExponential(2),'pageerrors',errs.length,errs.slice(0,3).join(' | '));await b.close()})();
