// Most između stranice i Windows programa (window.HV): fajlovi kola, PDF i fajl otvoren duplim klikom.
const { contextBridge, ipcRenderer } = require('electron');

let pending = null, handler = null;
ipcRenderer.on('open-file', (e, f) => { if (handler) handler(f); else pending = f; });

contextBridge.exposeInMainWorld('HV', {
  desktop: true,
  saveFile: (name, text) => ipcRenderer.invoke('save-file', { name, text }),
  openFile: () => ipcRenderer.invoke('open-file'),
  pdf: name => ipcRenderer.invoke('pdf', { name }),
  onOpenFile: fn => { handler = fn; if (pending) { const f = pending; pending = null; fn(f); } }
});
