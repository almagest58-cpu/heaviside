// Pre pakovanja: fontovi (Archivo, IBM Plex Mono) i MathJax idu u app/, da program radi bez interneta.
const fs = require('fs');
const path = require('path');
const nm = p => path.join(__dirname, 'node_modules', p);
const out = p => path.join(__dirname, 'app', p);

function copyDir(a, b) {
  fs.mkdirSync(b, { recursive: true });
  for (const f of fs.readdirSync(a)) {
    const s = path.join(a, f), d = path.join(b, f);
    if (fs.statSync(s).isDirectory()) copyDir(s, d);
    else if (/\.(css|woff2)$/i.test(f)) fs.copyFileSync(s, d);
  }
}

for (const [pkg, dir, weights] of [['@fontsource/archivo', 'archivo', [400, 500, 600, 700]], ['@fontsource/ibm-plex-mono', 'plex', [400, 500, 600]]]) {
  const src = nm(pkg);
  fs.mkdirSync(out('fonts/' + dir + '/files'), { recursive: true });
  for (const w of weights) {
    const css = fs.readFileSync(path.join(src, w + '.css'), 'utf8').replace(/,\s*url\([^)]*\.woff\)\s*format\(['"]woff['"]\)/g, '');
    fs.writeFileSync(out('fonts/' + dir + '/' + w + '.css'), css);
    for (const m of css.matchAll(/url\(\.\/files\/([^)]+\.woff2)\)/g)) fs.copyFileSync(path.join(src, 'files', m[1]), out('fonts/' + dir + '/files/' + m[1]));
  }
}
fs.mkdirSync(out('mathjax'), { recursive: true });
fs.copyFileSync(nm('mathjax/es5/tex-svg.js'), out('mathjax/tex-svg.js'));
const sz = fs.statSync(out('mathjax/tex-svg.js')).size;
if (sz < 500000) throw new Error('MathJax premali: ' + sz);
console.log('prep ok, mathjax', sz, 'B');
