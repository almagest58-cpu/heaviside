// Heaviside za Windows: isti program kao Android aplikacija (app/index.html), u svom prozoru.
// Glavni proces radi samo ono što stranica ne može: dijaloge za fajlove, snimanje PDF-a i otvaranje .hvs fajla duplim klikom.
const { app, BrowserWindow, ipcMain, dialog, Menu, shell } = require('electron');
const path = require('path');
const fs = require('fs');

const SELFTEST = process.argv.indexOf('--selftest');
const selftestOut = SELFTEST >= 0 ? process.argv[SELFTEST + 1] : null;
if (SELFTEST >= 0) app.disableHardwareAcceleration();

let win = null;
const fileArg = argv => argv.slice(1).find(a => /\.(hvs|json)$/i.test(a) && fs.existsSync(a));

function sendFile(f) {
  try {
    win.webContents.send('open-file', { name: path.basename(f), text: fs.readFileSync(f, 'utf8') });
  } catch (e) { /* nečitljiv fajl: stranica ništa ne dobija */ }
}

function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 900, minHeight: 600,
    backgroundColor: '#07090c', title: 'Heaviside', show: false,
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, spellcheck: false }
  });
  Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => { if (SELFTEST < 0) win.maximize(); win.show(); });
  // spoljni linkovi idu u podrazumevani browser, prozor programa ostaje na aplikaciji
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); } });
  // zum prikaza: Ctrl + / Ctrl - / Ctrl 0 (meni je isključen, pa ovo radimo ručno); F12 otvara alatke za razvoj
  win.webContents.on('before-input-event', (e, inp) => {
    if (inp.type !== 'keyDown') return;
    const wc = win.webContents;
    if (inp.control && (inp.key === '+' || inp.key === '=')) { wc.setZoomLevel(Math.min(4, wc.getZoomLevel() + 0.5)); e.preventDefault(); }
    else if (inp.control && inp.key === '-') { wc.setZoomLevel(Math.max(-3, wc.getZoomLevel() - 0.5)); e.preventDefault(); }
    else if (inp.control && inp.key === '0') { wc.setZoomLevel(0); e.preventDefault(); }
    else if (inp.key === 'F12') { wc.toggleDevTools(); e.preventDefault(); }
  });
  win.webContents.on('did-finish-load', () => {
    const f = fileArg(process.argv);
    if (f) sendFile(f);
    if (SELFTEST >= 0) runSelftest();
  });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
}

ipcMain.handle('save-file', async (e, { name, text }) => {
  const r = await dialog.showSaveDialog(win, {
    title: 'Sačuvaj kolo', defaultPath: (name || 'kolo') + '.hvs',
    filters: [{ name: 'Heaviside kolo', extensions: ['hvs'] }]
  });
  if (r.canceled || !r.filePath) return { ok: false };
  fs.writeFileSync(r.filePath, text, 'utf8');
  return { ok: true, name: path.basename(r.filePath) };
});

ipcMain.handle('open-file', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Otvori kolo', properties: ['openFile'],
    filters: [{ name: 'Heaviside kolo', extensions: ['hvs', 'json'] }]
  });
  if (r.canceled || !r.filePaths || !r.filePaths[0]) return { ok: false };
  const f = r.filePaths[0];
  return { ok: true, name: path.basename(f), text: fs.readFileSync(f, 'utf8') };
});

const PDF_OPT = { pageSize: 'A4', printBackground: true, preferCSSPageSize: true };
// boja prozora (tamna) bi se inače videla na marginama PDF stranice, zato je za vreme štampe bela
async function printPdf() {
  win.setBackgroundColor('#ffffff');
  try { return await win.webContents.printToPDF(PDF_OPT); } finally { win.setBackgroundColor('#07090c'); }
}
ipcMain.handle('pdf', async (e, { name }) => {
  const r = await dialog.showSaveDialog(win, {
    title: 'Sačuvaj PDF izveštaj', defaultPath: (name || 'Heaviside') + '.pdf',
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (r.canceled || !r.filePath) return { ok: false };
  const buf = await printPdf();
  fs.writeFileSync(r.filePath, buf);
  shell.openPath(r.filePath);
  return { ok: true, name: path.basename(r.filePath) };
});

// provera posle pravljenja programa (koristi je samo GitHub Actions): učita stranicu, napravi izveštaj i PDF, upiše rezultat i zatvori se
async function runSelftest() {
  const res = { errors: [] };
  win.webContents.on('console-message', (e, level, msg) => { if (level >= 3) res.errors.push(msg); });
  try {
    await new Promise(r => setTimeout(r, 4000));
    Object.assign(res, await win.webContents.executeJavaScript(`(async()=>{
      await document.fonts.load('600 15px Archivo');await document.fonts.load('600 13px "IBM Plex Mono"');
      const r={parts:state.parts.length,html:document.documentElement.className,hv:!!(window.HV&&HV.pdf),
        fontUi:document.fonts.check('600 15px Archivo'),fontMono:document.fonts.check('600 13px "IBM Plex Mono"'),
        uiFamily:getComputedStyle(document.body).fontFamily};
      for(let i=0;i<40&&!(window.MathJax&&MathJax.tex2svgPromise);i++)await new Promise(q=>setTimeout(q,250));
      r.mathjax=!!(window.MathJax&&MathJax.tex2svgPromise);
      try{await makeReport();r.report=document.getElementById('report').innerHTML.length;r.mjx=document.querySelectorAll('#report mjx-container').length}catch(e){r.reportErr=String(e&&e.stack||e)}
      return r})()`));
    const buf = await printPdf();
    res.pdfBytes = buf.length;
    if (selftestOut) fs.writeFileSync(selftestOut.replace(/\.json$/i, '') + '.pdf', buf);
  } catch (e) { res.fatal = String(e && e.stack || e); }
  if (selftestOut) fs.writeFileSync(selftestOut, JSON.stringify(res, null, 2));
  app.exit(res.fatal || res.reportErr ? 1 : 0);
}

if (SELFTEST < 0 && !app.requestSingleInstanceLock()) {
  app.quit();
} else {
  // drugi dupli klik na .hvs fajl dok program već radi: fajl se otvara u postojećem prozoru
  app.on('second-instance', (e, argv) => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    const f = fileArg(argv);
    if (f) sendFile(f);
  });
  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => app.quit());
}
